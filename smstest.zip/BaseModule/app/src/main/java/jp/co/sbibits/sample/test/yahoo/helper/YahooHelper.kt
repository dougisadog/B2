package jp.co.sbibits.sample.test.yahoo.helper

import android.app.Activity
import jp.co.sbibits.base.ContextManager
import jp.co.sbibits.base.util.SPUtils
import jp.co.yahoo.yconnect.YConnectImplicit
import jp.co.yahoo.yconnect.core.api.ApiClientException
import jp.co.yahoo.yconnect.core.oidc.*


object YahooHelper {

    var saver = object : YahooAccessSaver {

        val accessTokenKey = "yahoo_access_token"
        val idTokenStringKey = "yahoo_id_token"
        val expirationKey = "yahoo_expiration"

        override fun loadToken(): YahooToken {
            var accessTokenString = SPUtils.getInstance(ContextManager.getContext()!!).getString(accessTokenKey)
            if (null == accessTokenString) {
                accessTokenString = ""
            }
            var expiration = SPUtils.getInstance(ContextManager.getContext()!!).getLong(expirationKey)
            if (null == expiration) {
                expiration = 0
            }
            var idTokenString = SPUtils.getInstance(ContextManager.getContext()!!).getString(idTokenStringKey)
            if (null == idTokenString) {
                idTokenString = ""
            }

            return YahooToken(accessTokenString, expiration, idTokenString)
        }

        override fun saveToken(yahooToken: YahooToken) {
            SPUtils.getInstance(ContextManager.getContext()!!).putString(accessTokenKey, yahooToken.accessTokenString)
            SPUtils.getInstance(ContextManager.getContext()!!).putString(idTokenStringKey, yahooToken.idTokenString)
            SPUtils.getInstance(ContextManager.getContext()!!).putLong(expirationKey, yahooToken.expiration)

        }


    }

    // Client ID
    var clientId = ""

    //1を指定した場合、同意キャンセル時にredirect_uri設定先へ遷移する
    var BAIL = "1"

    //最大認証経過時間
    var MAX_AGE = "3600"

    // カスタムURIスキーム
    var customUriScheme = ""

    var token: IdTokenObject? = null

    var info: UserInfoObject? = null

    // リクエストとコールバック間の検証用のランダムな文字列を指定してください
    var state = "44GC44Ga44GrWeOCk+ODmuODreODmuODrShez4leKQ=="
    // リプレイアタック対策のランダムな文字列を指定してください
    var nonce = "KOOAjeODu8+J44O7KeOAjVlhaG9vISAo77yP44O7z4njg7sp77yPSkFQQU4="

    fun handleErr(e: ApiClientException, activity: Activity) {
        val yconnect = YConnectImplicit.getInstance()
        // エラーレスポンスが"Invalid_Token"であるかチェック
        if ("invalid_token" == e.error) {

            /*********************
             * Refresh Access Token.
             */

            // ImplicitフローでAccess Tokenの有効期限がきれた場合は
            // 初回と同様に新たにAccess Tokenを取得してください

            val display = OIDCDisplay.TOUCH
            val prompt = arrayOf(OIDCPrompt.DEFAULT)
            val scope = arrayOf(OIDCScope.OPENID, OIDCScope.PROFILE, OIDCScope.EMAIL, OIDCScope.ADDRESS)

            yconnect.init(
                clientId,
                customUriScheme,
                state, display, prompt, scope,
                nonce,
                BAIL,
                MAX_AGE
            )
            yconnect.requestAuthorization(activity)

        }
    }

}

interface YahooAccessSaver {
    fun saveToken(yahooToken: YahooToken)

    fun loadToken(): YahooToken
}