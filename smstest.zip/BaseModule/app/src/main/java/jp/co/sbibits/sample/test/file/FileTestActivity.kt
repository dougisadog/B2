package jp.co.sbibits.sample.test.file

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import jp.co.sbibits.base.util.FileUtils
import jp.co.sbibits.base.util.LogUtils
import jp.co.sbibits.base.util.ToastUtils
import jp.co.sbibits.sample.R
import java.io.File

class FileTestActivity : AppCompatActivity() {

    private val fileName = "file.txt"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_test)
    }

    fun createFile(view: View) {
        FileUtils.createFile(fileName = fileName)
    }

    fun deleteFile(view: View) {
        FileUtils.deleteFile(fileName = fileName)
    }

    fun writeFile(view: View) {
        FileUtils.writeText(File("${FileUtils.getRootDir()}/$fileName"), "this is write content")
    }

    fun readFile(view: View) {
        val msg = FileUtils.readFile(File(FileUtils.getRootDir() +"/"+ fileName))
        if (msg != null) {
            ToastUtils.showLongMessage(this, msg)
            LogUtils.d("FileTestActivity", msg)
        } else {
            ToastUtils.showLongMessage(this, "file does not exist")
        }

    }

    companion object {
        fun start(context: Context) {
            val starter = Intent(context, FileTestActivity::class.java)
            // starter.putExtra()
            context.startActivity(starter)
        }
    }
}
