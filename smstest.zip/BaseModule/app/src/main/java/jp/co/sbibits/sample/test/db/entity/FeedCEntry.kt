package jp.co.sbibits.sample.test.db.entity

open class FeedCEntry {

    var name: String? = null

}