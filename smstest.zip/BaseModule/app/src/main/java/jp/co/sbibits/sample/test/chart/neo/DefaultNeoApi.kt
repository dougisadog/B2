package jp.co.sbibits.sample.test.chart.neo

import jp.co.sbibits.base.chart.neo.model.NeoJsonData
import jp.co.sbibits.sample.test.chart.fx.model.AssetJsonData
import jp.co.sbibits.base.http.JsonHttpTask

class DefaultNeoApi : JsonHttpTask<NeoJsonData>() {

    override val resultClass = NeoJsonData::class

    // 基本通信先URL
    override val baseURL: String
        get() = "https://t-hyperm02.sbisec.co.jp/mtsmobile/kabusp/AppConfig.json"
}

