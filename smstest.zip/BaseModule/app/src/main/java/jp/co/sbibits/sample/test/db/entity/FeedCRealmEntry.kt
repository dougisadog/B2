package jp.co.sbibits.sample.test.db.entity

import io.realm.RealmModel
import io.realm.annotations.Ignore
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

@RealmClass
open class FeedCRealmEntry : RealmModel {

    @PrimaryKey
    var name: String? = null

}