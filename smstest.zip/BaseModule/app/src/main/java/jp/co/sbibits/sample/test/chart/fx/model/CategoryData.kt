package jp.co.sbibits.sample.test.chart.fx.model

data class CategoryData(var name: String, var code: String)