package jp.co.sbibits.sample.test.chart.fx.model

import jp.co.sbibits.base.chart.fx.model.AssetRecord

data class AssetJsonData(var categoryList: ArrayList<CategoryData>, var records: ArrayList<AssetRecord>) {

}


