package jp.co.sbibits.sample.test.banner

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityBannerBinding
import jp.co.sbibits.sample.test.banner.adapter.RecyclePagerAdapter
import jp.co.sbibits.sample.test.banner.entity.Banner

class BannerActivity : AppCompatActivity() {

    lateinit var adapter: RecyclePagerAdapter<String>

    val binding by  lazy {
        ActivityBannerBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        val image =
            "https://img.iplaysoft.com/wp-content/uploads/2019/free-images/free_stock_photo.jpg"
        val image2 = "https://pic.5tu.cn/uploads/allimg/1911/pic_5tu_big_201911122201021011.jpg"
        val banners = mutableListOf(Banner().apply {
            this.image = image
            this.link = "link1"
        }, Banner().apply {
            this.image = image2
            this.link = "link2"
        })
        binding.bannerBv.initBanner(banners, this)
    }
}