package jp.co.sbibits.sample

import android.app.Application
import io.realm.Realm
import jp.co.sbibits.base.ApkInfo
import jp.co.sbibits.base.ContextManager
import jp.co.sbibits.base.db.realm.RealmConfig
import jp.co.sbibits.base.db.sqlite.SQLiteConfig
import jp.co.sbibits.base.db.config.DBConfig
import jp.co.sbibits.base.db.DBManger
import jp.co.sbibits.base.db.config.DBType
import jp.co.sbibits.base.db.config.classloader.PackageScanner


/**
 * アプリケーションクラス
 */
class BaseModuleApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        ContextManager.init(applicationContext)
        initDB()
    }

    fun initDB() {
        val config =
            DBConfig.Builder.create("BaseModule", 1)
//                .appendDefaultDBType(DBType.SQLite)
                .appendDefaultDBType(DBType.Realm)
//                .appendSQLiteConfig(SQLiteConfig())
                .appendRealmConfig(RealmConfig(Realm.getDefaultModule()))
                .classesLoader(
                    PackageScanner(
                        this,
                        ApkInfo.packageName,
                        "${ApkInfo.packageName}.test.db.entity"
                    )
                )
                .build()
        DBManger.init(this, config)
    }
}