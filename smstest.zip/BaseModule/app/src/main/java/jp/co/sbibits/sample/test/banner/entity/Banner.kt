package jp.co.sbibits.sample.test.banner.entity

import java.io.Serializable

class Banner : Serializable {
    var title: String? = null
    var image: String? = null
    var link: String? = null

}