package jp.co.sbibits.sample.test.chart.mts.chart

import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.extension.append
import jp.co.sbibits.base.extension.contains
import jp.co.sbibits.base.extension.removeAll
import jp.co.sbibits.base.http.DefaultSetting
import jp.co.sbibits.base.http.HttpTask
import java.lang.ref.WeakReference

typealias SingleChartDataReceiver = (ChartData?, Int?) -> Unit

/**
 * state drawing process status true: loading  false:finished
 */
typealias ChartProcessTask = (state:Boolean) -> Unit

class ChartDataService {

    // 取得済みデータとデータキーのマップ
    var dataMap: MutableMap<String, ChartData> = mutableMapOf()

    // 読み込み待ちチャートリスト
    var waitingDataIDs: MutableList<String> = mutableListOf()

    // 読み込み待ちチャートリスト（4分割チャート用）
    var waitingDataIDsForMulti: MutableList<String> = mutableListOf()

    private var autoRefresh: Boolean = DefaultSetting.autoRefresh
    // 自動更新間隔
    private var autoRefreshInterval: Int = DefaultSetting.autoRefreshInterval

    fun clear() {
        waitingDataIDs.removeAll()
        waitingDataIDsForMulti.removeAll()
        dataMap.removeAll()

        if (null != currentTask) {
            val api = currentTask!!.get()
            if (api is HttpTask<*>) {
                (api as HttpTask<*>).cancel()
            }
        }
        currentTask = null

    }

    var currentTask : WeakReference<ChartAPI>? = null

    //return if the task can continue run
    private fun getState() :Boolean {
        return currentTask != null
    }

    fun getDataAPI(type:ChartSourceType, isFirst:Int):ChartAPI {
        return ChartApiLoader.apis.getValue(Pair(type, isFirst)).invoke()
    }

    // シングル表示用にチャートデータを取得する

    fun singleLoad(source: ChartSource, ashiType: ChartAshiTypeUnit, chartProcessTask: ChartProcessTask, isComparison: Boolean = false,
        maxRecord: Int? = null, isAutoUpdate: Boolean = false, onUpdate: SingleChartDataReceiver, onRefresh: (() -> Unit)? = null) {
        val api: ChartAPI
        val dataId = source.dataId(ashiType)
        val data = dataMap[dataId]
        if (data != null && source.isMinuteAshiEnabled) {
//            api = source.type.updateAPI
            api = getDataAPI(source.type, 1)
            api.latestTime = data.latestAxis
        } else {
//            api = source.type.firstDataAPI
            api = getDataAPI(source.type, 0)
            if (api is HttpTask<*> && isAutoUpdate) {
                (api as HttpTask<*>).autoRefresh ({
                    getState()
                }, autoRefreshInterval)
            }
        }
        currentTask = WeakReference(api)

        api.chartSource = source
        api.ashiType = ashiType.ashiType
        if (ashiType.ashiType == ChartAshiType.minute) {
            api.ashiUnitNumber = ashiType.unit
        }
        api.maxRecord = maxRecord

        chartProcessTask.invoke(true)

        api.execute(onComplete = { chartData ->
            if (data != null && !isComparison) {
                dataMap[dataId] = chartData
            }
            this.setSingleResponse(chartData, source = source, ashiTypeUnit = ashiType, onUpdate = onUpdate)
        })
        api.onFinish {
            this.waitingDataIDs.remove(element = dataId)
            if (this.waitingDataIDs.size == 0) {
//                chartView.showLoadingLabel(false)
//                if (null != currentTask) {
//                    chartProcessTask.invoke (false)
//                }
                chartProcessTask.invoke (false)

            }
        }
//         if (onRefresh == null || !autoRefresh) {
//             return
//         }
//         val comparisonKey = if (isComparison) "comparison" else ""
//         api.after(delaySec = autoRefreshInterval) {
//             if (this.waitingDataIDs.size == 0) {
//                 onRefresh()
//             }
//         }
    }


    /** チャートデータを取得時の処理 */
    private fun setSingleResponse(chartData: ChartData, source: ChartSource, ashiTypeUnit: ChartAshiTypeUnit, onUpdate: SingleChartDataReceiver) {
        val dataKey = source.dataId(ashiTypeUnit)
        val existingData = dataMap[dataKey]
        if (existingData == null || !source.isMinuteAshiEnabled) {
            // 初回データ取得
//            val data = makeData(response = response, records = response.records)
            onUpdate(chartData, null)
        } else {
            // データ更新
            val addedCount = existingData.update(chartData)
            onUpdate(existingData, addedCount)
        }
    }

    fun synch(source1: ChartSource, source2: ChartSource, ashiType: ChartAshiTypeUnit) {
        waitingDataIDs.removeAll()


        val id1 = source1.dataId(ashiType)
        if (dataMap[id1] == null) {
            waitingDataIDs.append(id1)
        }
        val id2 = source2.dataId(ashiType)
        if (dataMap[id2] == null) {
            waitingDataIDs.append(id2)
        }
    }

    fun getData(source: ChartSource, ashiTypeUnit: ChartAshiTypeUnit): ChartData? {
        val dataKey = source.dataId(ashiTypeUnit)
        return dataMap[dataKey]
    }

    private fun makeData(response: ChartResponseBase, records: List<ChartResponseRecord>): ChartData {
        val data = ChartData()
        data.decimalLength = response.decimalLength
        records.forEach { record ->
            val time = record.dateTime
            if (time != null) {
                data.addAxis(time)
                data[ChartDataType.OPEN].plusAssign(record.fOpen)
                data[ChartDataType.HIGH].plusAssign(record.fHigh)
                data[ChartDataType.LOW].plusAssign(record.fLow)
                data[ChartDataType.CLOSE].plusAssign(record.fClose)
                data[ChartDataType.VOLUME].plusAssign(record.fVolume)
            }
        }
        return data
    }

    private fun isDataReady(source: ChartSource, ashiTypes: List<ChartAshiTypeUnit>): Boolean {
        val dataLacking = ashiTypes.contains { this.dataMap[source.dataId(it)] == null }
        return !dataLacking
    }

}