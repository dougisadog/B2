package jp.co.sbibits.sample.test.scorepair

import android.graphics.DashPathEffect
import android.graphics.Paint

/**
 * 描画パラメーター
 */
class DrawParam {

    val paint = Paint()

    var fillColor: Int? = null
    var strokeColor: Int? = null
    var lineDashPhase: Int? = null
    var lineDashLengths: List<Float>? = null

    var shouldAntialias: Boolean = false
        set(value) {
            field = value
            paint.isAntiAlias = shouldAntialias
            paint.isFilterBitmap = shouldAntialias
        }

    var lineWidth: Float = 1.0f
        set(value) {
            field = value
            paint.strokeWidth = lineWidth
        }

    constructor()

    constructor(fillColor: Int?,
                strokeColor: Int?,
                lineDashPhase: Int?,
                lineDashLengths: List<Float>?,
                shouldAntialias: Boolean) {
        this.fillColor = fillColor
        this.strokeColor = strokeColor
        this.lineDashPhase = lineDashPhase
        this.lineDashLengths = lineDashLengths
        this.shouldAntialias = shouldAntialias
    }

    fun fillMode() {
        paint.style = Paint.Style.FILL
        paint.pathEffect = null
        val color = fillColor
        if (color != null) {
            paint.color = color
        }
    }

    fun strokeMode() {
        paint.style = Paint.Style.STROKE

        val dashLengths = lineDashLengths
        if (dashLengths != null && dashLengths.isNotEmpty()) {
            val phase = lineDashPhase?.toFloat() ?: 0.0f
            val floatArray = dashLengths.map { it.toFloat() }.toFloatArray()
            paint.pathEffect = DashPathEffect(floatArray, phase)
        } else {
            paint.pathEffect = null
        }

        val color = strokeColor
        if (color != null) {
            paint.color = color
        }
    }

    fun clone(): DrawParam {
        return DrawParam(fillColor, strokeColor, lineDashPhase, lineDashLengths, shouldAntialias)
    }
}