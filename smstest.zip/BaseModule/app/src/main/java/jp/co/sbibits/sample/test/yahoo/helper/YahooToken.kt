package jp.co.sbibits.sample.test.yahoo.helper

data class YahooToken(val accessTokenString: String, val expiration: Long, val idTokenString: String)