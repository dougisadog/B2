package jp.co.sbibits.sample.test.sms

import android.Manifest
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.telephony.SmsMessage
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.MutableLiveData
import com.permissionx.guolindev.PermissionX

object SMSUtil {

    val messages =MutableLiveData<MutableList<SmsText>>()

    val SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED"

    fun readSms(activity: FragmentActivity, onRead: ((ArrayList<SmsText>?) -> Unit)?) {
        permissionSms(activity, Manifest.permission.READ_SMS) {
            var cur: Cursor? = null
            val result = arrayListOf<SmsText>()
            try {
                val cr = activity.contentResolver
                val SMS_INBOX = Uri.parse("content://sms/inbox")
                val projectionFields = arrayOf("_id", "address", "person", "body", "date", "type")
                cur = cr.query(SMS_INBOX, projectionFields, null, null, "date desc");
                val readText = { cursor: Cursor, column: String ->
                    val index = cursor.getColumnIndex(column)
                    if (index >= 0) {
                        cursor.getString(index)
                    } else {
                        null
                    }
                }
                while (null != cur) {
                    cur.moveToNext()
                    val number = readText(cur, "address")//手机号
                    val name = readText(cur, "person")//联系人姓名列表
                    val body = readText(cur, "body")//短信内容
                    val date = readText(cur, "date")//短信内容

                    result.add(SmsText(number, body, date?.toLong()))
                    if (cur.isLast) {
                        break
                    }
                }
                onRead?.invoke(result)
            } catch (e: Exception) {
                onRead?.invoke(null)
                Toast.makeText(activity, "read sms failed:${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                cur?.close()
            }
        }
    }

    fun permissionSms(
        activity: FragmentActivity,
        permission: String,
        permit: ((Boolean) -> Unit)? = null
    ) {
        PermissionX.init(activity)
            .permissions(permission)
            .request { allGranted, grantedList, deniedList ->
                permit?.invoke(allGranted)
                if (allGranted) {

                } else {
                    Toast.makeText(
                        activity,
                        "These permissions are denied: $deniedList",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
    }

    fun readByIntent(intent: Intent): MutableList<SmsText>? {
        val content = StringBuilder()
        val bundle = intent.extras
        val format = intent.getStringExtra("format");
        if (bundle != null) {
            try {
                val pdus = bundle.get("pdus") as? Array<ByteArray>

                val result = pdus?.map {
                    val message = SmsMessage.createFromPdu(it, format)
                    val sender = message.originatingAddress
                    content.append(message.messageBody)
                    val millis = message.timestampMillis
                    val status = message.status
                    val smsText = SmsText(sender, message.messageBody, millis)
                    smsText
                }
                return result?.toMutableList()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        return null
    }
}