package jp.co.sbibits.sample.test.db

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jp.co.sbibits.base.db.DBManger
import jp.co.sbibits.base.db.config.DBType
import jp.co.sbibits.base.db.dao.BaseDao
import jp.co.sbibits.base.db.extension.instanceDao
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityDbBinding
import jp.co.sbibits.sample.databinding.ActivityPieChartBinding
import jp.co.sbibits.sample.test.db.entity.FeedCEntry
import jp.co.sbibits.sample.test.db.entity.FeedEntry

class DBActivity : AppCompatActivity() {

    private var adapter = DBAdapter()

    val binding by  lazy {
        ActivityDbBinding.inflate(layoutInflater)
    }
    val feedDao: BaseDao<FeedEntry> by lazy {
        instanceDao(FeedEntry::class)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        adapter.context = this
        adapter.listener = this::delete

        val llm = LinearLayoutManager(this)
        llm.orientation = RecyclerView.VERTICAL
        binding.dataContent.layoutManager = llm
        binding.dataContent.adapter = adapter
        binding.add.setOnClickListener {
            add()
        }
        binding.search.setOnClickListener {
            search()
        }
        binding.deleteAll.setOnClickListener {
            deleteAll()
        }
        binding.move.setOnClickListener {
            move()
        }
        refresh()
    }

    fun move() {
        DBManger.moveData(DBType.SQLite, DBType.Realm)
    }

    fun refresh(feedEntry: FeedEntry? = FeedEntry()) {
        val data = feedDao.query(feedEntry)
        adapter.indexRecords = data.toMutableList()
    }

    fun search() {
        val feedEntry = getInput()
        refresh(feedEntry)
    }

    fun getInput(): FeedEntry? {
        val name = binding.name.text.toString()
        val content = binding.sub.text.toString()
        if (name.isEmpty() && content.isEmpty()) {
            return null
        }
        val feedEntry = FeedEntry().apply {
            if (name.isNotEmpty()) {
                title = name.toLongOrNull()
            }
            if (content.isNotEmpty()) {
                subTitle = content
            }
            if (content.isNotEmpty()) {
                subTitle2 = content
            }
        }
        return feedEntry
    }

    fun add() {
        val feedEntry = getInput()?:return

        for (i in 0..3) {
            feedEntry.subs.add(FeedCEntry().apply {
                name = "sub$i"
            })
        }
        feedDao.async({
            feedDao.save(mutableListOf(feedEntry))
            //测试事务
//            feedDao.runTransaction {
//            val saved1 = feedDao.save(feedEntry)
//            feedEntry.title = (feedEntry.title ?: 0) + 1
//            val saved2 = feedDao.save(feedEntry)

            //测试事务回滚
//                throw Exception("ttt")
//                true
//            }
        }, { refresh() })
    }

    fun delete(id: Any?) {
        val id = id ?: return
        feedDao.async({ feedDao.delete(id) }, { refresh() })
    }

    fun deleteAll() {
        feedDao.async({ feedDao.deleteAll() }, { refresh() })
    }
}
