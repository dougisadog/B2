package jp.co.sbibits.sample.test.chart.mts

import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.chart.ui.utils.Category
import jp.co.sbibits.base.chart.ui.utils.ChartDisplayType
import jp.co.sbibits.base.extension.components
import java.io.Serializable

/**
 *
 * Created by yamamoto on 2018/01/26.
 */
class MajorIndexResponse: MTSResponse() {



    class Record : Serializable{
        var chartEnabledCode: String? = null // チャート表示可否
        val isChartEnabled: Boolean
            get() = category == Category.FX_RATE || chartEnabledCode != "0"
        val chartDisplayType: ChartDisplayType?
            get() {
                val code = chartEnabledCode
                if (code != null) {
                    return ChartDisplayType::class.value(rawValue = code)
                }
                return null
            }
        val isMinuteAshiEnabled: Boolean
            get() = chartDisplayType != ChartDisplayType.MINUTE_DISABLED
        var categoryCode: String? = null // カテゴリコード
        val category: Category?
            get() {
                val categoryCode = categoryCode
                if (categoryCode != null) {
                    return Category::class.value(rawValue = categoryCode)
                }
                return null
            }
        var indexCode: String? = null // 指標コード
        var indexName: String? = null // 指標名
        var tradeDateTime: String? = null // 日付・時刻（表示用）
        var currentPriceString: String? = null // 現在値
        var upDownMark: String? = null // 現在値ティック（表示用）
        var change: String? = null // 前日比
        var changePercentage: String? = null // 前日比率
        var tradeColorFlag: String? = null // 前日比色フラグ
        var prctck1: String? = null // 現在値ティック（表示用）
        var openPrice: String? = null // 始値
        var highPrice: String? = null // 高値
        var lowPrice: String? = null // 安値
        var previousPrice: String? = null // 前日終値
        val currentPrice: String?
            get() {
                if (category == Category.FX_RATE) {
                    return currentPriceString?.components(separatedBy = "-")?.firstOrNull()
                }
                return currentPriceString
            }
        val updateTime: String?
            get() {
                val dateTime = tradeDateTime
                if (dateTime != null) {
                    return dateTime.split(" ").lastOrNull()
                }
                return null
            }
    }

    val records: MutableList<Record> = mutableListOf()
}
