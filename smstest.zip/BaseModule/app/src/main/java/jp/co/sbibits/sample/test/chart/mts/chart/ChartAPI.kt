package jp.co.sbibits.sample.test.chart.mts.chart

import jp.co.sbibits.base.chart.ui.model.ChartAshiType
import jp.co.sbibits.base.chart.ui.model.ChartData
import jp.co.sbibits.base.chart.ui.model.ChartSource
import jp.co.sbibits.base.extension.size

interface ChartAPI {
    var chartSource: ChartSource?
    var ashiType: ChartAshiType?
    var ashiUnitNumber: Int?
    var latestTime: String?
    var maxRecord: Int?
    fun execute(onComplete: (ChartData) -> Unit)
    fun after(delaySec: Int, process: () -> Unit)
    fun onFinish(action: (() -> Unit)?)

    val unitCode: String
        get() {
            var unitCode = ""
            val unit = ashiUnitNumber
            if (unit != null) {
                unitCode = unit.toString()
            }
            return unitCode
        }

    val minutesUnit: Int
        get() {
            if (ashiType == ChartAshiType.minute) {
                return ashiUnitNumber ?: 0
            }
            return 15
        }

    val minutesCode: String
        get() {
            var code = minutesUnit.toString()
            if (code.size == 1) {
                code = "0" + code
            }
            return code
        }

    val startTime: String
        get() {
            val time = latestTime
            if (time != null && 12 <= time.size) {
                return time.substring(8, 8 + 4)
            }
            return "2400"
        }

    val startDate: String
        get() {
            val time = latestTime
            if (time != null && 8 <= time.size) {
                return time.substring(0, 8)
            }
            return ""
        }

}
