package jp.co.sbibits.sample.test.file

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.test.file.adpter.FileAdapter
import jp.co.sbibits.base.util.FileUtils
import jp.co.sbibits.sample.databinding.ActivityFileBinding
import java.io.File

class FileActivity : AppCompatActivity() {

    private var adapter = FileAdapter()

    val binding by  lazy {
        ActivityFileBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        adapter.context = this
        adapter.listener = this::delete

        val llm = LinearLayoutManager(this)
        llm.orientation = RecyclerView.VERTICAL
        binding.dataContent.layoutManager = llm
        binding.dataContent.adapter = adapter
        binding.btnAdd.setOnClickListener {
            add()
        }
    }

    fun refresh() {
        val f = File(FileUtils.defaultDir)
        adapter.indexRecords = f.listFiles().toMutableList()
    }

    fun add() {
        val name = binding.etName.text.toString()
        val content = binding.etContent.text.toString()
        val f = File(FileUtils.defaultDir + File.separator + name)
        if (!f.exists()) {
            f.createNewFile()
        }
        f.appendText(content)
        refresh()
    }

    fun delete(name: String) {
        val f = File(FileUtils.defaultDir + File.separator + name)
        if (f.exists()) {
            f.delete()
        }
        refresh()
    }
}
