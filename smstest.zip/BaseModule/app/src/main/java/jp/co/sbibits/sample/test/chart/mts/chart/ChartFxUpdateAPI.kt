package jp.co.sbibits.sample.test.chart.mts.chart

import jp.co.sbibits.sample.test.chart.mts.MTSAPI
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.model.ChartAshiType
import jp.co.sbibits.base.chart.ui.model.ChartAshiTypeUnit
import jp.co.sbibits.base.chart.ui.model.ChartData
import jp.co.sbibits.base.chart.ui.model.ChartSource
import jp.co.sbibits.base.extension.append

class ChartFxUpdateAPI: MTSAPI<ChartFxUpdateResponse>(),
    ChartAPI {

    override val resultClass = ChartFxUpdateResponse::class

    override val trCode: String
        get() = "F1858"

    override var chartSource: ChartSource? = null
    override var ashiType: ChartAshiType? = null
    override var ashiUnitNumber: Int? = null
    override var latestTime: String? = null
    override var maxRecord: Int? = null

    override fun makeInputParameter() {
        addLeft(chartSource?.code, 4)
        addLeft(startTime, 4)
        addLeft(minutesCode, 2)
        addLeft(startDate, 8)
    }

    override fun parseAPIResponse(result: ChartFxUpdateResponse) {
        result.exrateCode = read(4)
        result.exrateName = read(40)
        result.chartResponseBase.previousClose = read(11)
        result.chartResponseBase.currentPrice = read(11)
        result.chartResponseBase.priceColorCode = read(1)
        result.chartResponseBase.upDownArrow = read(2)
        result.chartResponseBase.upDownCode = read(1)
        result.chartResponseBase.updateTime = read(5)
        result.chartResponseBase.change = read(25)
        result.chartResponseBase.highPrice = read(11)
        result.chartResponseBase.lowPrice = read(11)

        val isSmallPrice = ChartFxAPI.smallPriceCode.contains(result.exrateCode)
        result.chartResponseBase.decimalLength = if (isSmallPrice) 4 else 2
        val rate: CGFloat = if (isSmallPrice) 0.0001 else 0.01

        result.chartResponseBase.updatedData[ChartAshiTypeUnit(
            ashiType = ChartAshiType.minute,
            unit = minutesUnit
        )] = parseRecordList(rate = rate)
        result.chartResponseBase.updatedData[ChartAshiTypeUnit(
            ashiType = ChartAshiType.day,
            unit = 1
        )] = parseRecordList(rate = rate)
        result.chartResponseBase.updatedData[ChartAshiTypeUnit(
            ashiType = ChartAshiType.week,
            unit = 1
        )] = parseRecordList(rate = rate)
        result.chartResponseBase.updatedData[ChartAshiTypeUnit(
            ashiType = ChartAshiType.month,
            unit = 1
        )] = parseRecordList(rate = rate)
    }

    private fun parseRecordList(rate: CGFloat) : List<ChartResponseRecord> {
        var records: MutableList<ChartResponseRecord> = mutableListOf()
        val count = readInt(4)
        for (i in 0 until count) {
            val record = ChartResponseRecord(rate = rate)
            record.dateTime = read(12)
            record.open = read(11)
            record.high = read(11)
            record.low = read(11)
            record.close = read(11)
            record.volume = read(15)
            if ((record.open != "0")) {
                records.append(record)
            }
        }
        records.reverse()
        return records
    }

    override fun execute(onComplete: (ChartData) -> Unit) {
        super.execute { response  ->
            onComplete(response.chartResponseBase.makeData())
        }
    }

}
