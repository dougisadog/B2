package jp.co.sbibits.sample.test.chart

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.chart.ui.model.ChartAshiType
import jp.co.sbibits.base.chart.ui.model.ChartParamSet
import jp.co.sbibits.base.chart.ui.model.item.ChartTechnicalParam
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityChartBinding
import jp.co.sbibits.sample.databinding.ActivityChartSettingBinding

class ChartSettingActivity : AppCompatActivity() {

    private lateinit var ashiType:ChartAshiType

    val binding by  lazy {
        ActivityChartSettingBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        val type = intent.getStringExtra("type")//day
        if (type == null) {
            finish()
            return
        }
        ashiType = ChartAshiType::class.value(rawValue = type)!!

        val params = ChartParamSet.instance[ashiType]!!
        setChartSetting(params)

        binding.btApply.setOnClickListener {
            apply()
            setResult(1)
            finish()
        }
        binding.btCancel.setOnClickListener {
            finish()
        }
    }

    private fun setChartSetting(params: ChartTechnicalParam) {
        binding.apply {

        bbSpan.setText(params.bbSpan.toString())
        bbSmaOn.isChecked = params.bbSmaOn

        bbSigma1On.isChecked = params.bbSigma1On
        bbSigma2On.isChecked = params.bbSigma2On
        bbSigma3On.isChecked = params.bbSigma3On

        ichimokuTenkanSpan.setText(params.ichimokuTenkanSpan.toString())
        ichimokuKijunSpan.setText(params.ichimokuKijunSpan.toString())
        ichimokuSpan.setText(params.ichimokuSpan.toString())

        ichimokuKijunOn.isChecked = params.ichimokuKijunOn
        ichimokuTenkanOn.isChecked = params.ichimokuTenkanOn
        ichimokuSenkoChikoOn.isChecked = params.ichimokuSenkoChikoOn

        sma1Span.setText(params.sma1Span.toString())
        sma2Span.setText(params.sma2Span.toString())
        sma3Span.setText(params.sma3Span.toString())

        sma1On.isChecked = params.sma1On
        sma2On.isChecked = params.sma2On
        sma3On.isChecked = params.sma3On

        dmiAverageSpan.setText(params.dmiAverageSpan.toString())

        dmiDiOn.isChecked = params.dmiDiOn
        dmiAdxOn.isChecked = params.dmiAdxOn
        dmiAdxrOn.isChecked = params.dmiAdxrOn

        macdSignalOn.isChecked = params.macdSignalOn

        macdShortSpan.setText(params.macdShortSpan.toString())
        macdLongSpan.setText(params.macdLongSpan.toString())
        macdSignalSpan.setText(params.macdSignalSpan.toString())

        rsi1Span.setText(params.rsi1Span.toString())
        rsi2Span.setText(params.rsi2Span.toString())
        rsi3Span.setText(params.rsi3Span.toString())

        rsi1On.isChecked = params.rsi1On
        rsi2On.isChecked = params.rsi2On
        rsi3On.isChecked = params.rsi3On

        stochastKSpan.setText(params.stochastKSpan.toString())
        stochastDSpan.setText(params.stochastDSpan.toString())
        stochastSDSpan.setText(params.stochastSDSpan.toString())

        stochastKOn.isChecked = params.stochastKOn
        stochastDOn.isChecked = params.stochastDOn
        stochastSDOn.isChecked = params.stochastSDOn

        }
    }


    private fun apply() {
        binding.apply {

        val params = ChartParamSet.instance[ashiType]!!

        params.bbSpan = bbSpan.text.toString().toInt()
        params.bbSmaOn = bbSmaOn.isChecked

        params.bbSigma1On = bbSigma1On.isChecked
        params.bbSigma2On = bbSigma2On.isChecked
        params.bbSigma3On = bbSigma3On.isChecked


        params.ichimokuTenkanSpan = ichimokuTenkanSpan.text.toString().toInt()
        params.ichimokuKijunSpan = ichimokuKijunSpan.text.toString().toInt()
        params.ichimokuSpan = ichimokuSpan.text.toString().toInt()

        params.ichimokuKijunOn = ichimokuKijunOn.isChecked
        params.ichimokuTenkanOn = ichimokuTenkanOn.isChecked
        params.ichimokuSenkoChikoOn = ichimokuSenkoChikoOn.isChecked


        params.sma1Span = sma1Span.text.toString().toInt()
        params.sma2Span = sma2Span.text.toString().toInt()
        params.sma3Span = sma3Span.text.toString().toInt()

        params.sma1On = sma1On.isChecked
        params.sma2On = sma2On.isChecked
        params.sma3On = sma3On.isChecked


        params.dmiAverageSpan = dmiAverageSpan.text.toString().toInt()

        params.dmiDiOn = dmiDiOn.isChecked
        params.dmiAdxOn = dmiAdxOn.isChecked
        params.dmiAdxrOn = dmiAdxrOn.isChecked


        params.macdSignalOn = macdSignalOn.isChecked

        params.macdShortSpan = macdShortSpan.text.toString().toInt()
        params.macdLongSpan = macdLongSpan.text.toString().toInt()
        params.macdSignalSpan = macdSignalSpan.text.toString().toInt()


        params.rsi1Span = rsi1Span.text.toString().toInt()
        params.rsi2Span = rsi2Span.text.toString().toInt()
        params.rsi3Span = rsi3Span.text.toString().toInt()

        params.rsi1On = rsi1On.isChecked
        params.rsi2On = rsi2On.isChecked
        params.rsi3On = rsi3On.isChecked


        params.stochastKSpan = stochastKSpan.text.toString().toInt()
        params.stochastDSpan = stochastDSpan.text.toString().toInt()
        params.stochastSDSpan = stochastSDSpan.text.toString().toInt()

        params.stochastKOn = stochastKOn.isChecked
        params.stochastDOn = stochastDOn.isChecked
        params.stochastSDOn = stochastSDOn.isChecked

        params.save()
        ChartParamSet.instance.save()

        }
    }

}
