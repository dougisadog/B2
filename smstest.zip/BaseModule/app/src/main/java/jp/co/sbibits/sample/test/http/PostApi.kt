package jp.co.sbibits.sample.test.http

import jp.co.sbibits.base.http.TextHttpTask

class PostApi : TextHttpTask() {

    override var httpMethod: String = "POST"

    // 基本通信先URL
    override val baseURL: String
        get() = "https://ptsv2.com/t/owiya-1551749975/post"
}

