package jp.co.sbibits.sample.test.yahoo.helper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import jp.co.sbibits.base.util.LogUtils

import jp.co.yahoo.yconnect.YConnectImplicit
import jp.co.yahoo.yconnect.core.oauth2.AuthorizationException
import jp.co.yahoo.yconnect.core.oidc.*

/**
 * Implicit Sample Activity
 *
 * @author Copyright (C) 2017 Yahoo Japan Corporation. All Rights Reserved.
 */
abstract class YConnectImplicitActivity : Activity() {

    private val TAG = YConnectImplicitActivity::class.java.simpleName

    abstract val resId: Int

    abstract fun init()

    abstract fun onDataReceived(results :Pair<UserInfoObject, IdTokenObject>)

    abstract fun onTokenReceived(yahooToken: YahooToken)


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(resId)
        init()
        initYahooRequest()
    }

    private fun initYahooRequest() {
        // YConnectインスタンス取得
        val yconnect = YConnectImplicit.getInstance()

        // ログレベル設定（必要に応じてレベルを設定してください）
        //YConnectLogger.setLogLevel(YConnectLogger.DEBUG);

        val intent = intent

        if (Intent.ACTION_VIEW == intent.action) {

            /*************************************************
             * Parse the Response Url and Save the Access Token.
             */

            try {

                Log.i(TAG, "Get Response Url and parse it.")

                // response Url(Authorizationエンドポイントより受け取ったコールバックUrl)から各パラメータを抽出
                val uri = intent.data
                yconnect.parseAuthorizationResponse(uri,
                    YahooHelper.customUriScheme,
                    YahooHelper.state
                )
                // Access Token、ID Tokenを取得

                val accessTokenString = yconnect.accessToken
                val expiration = yconnect.accessTokenExpiration
                val idTokenString = yconnect.idToken

                val  yahooToken =
                    YahooToken(accessTokenString, expiration, idTokenString)
                // Access Tokenを保存
                YahooHelper.saver.saveToken(yahooToken)

                onTokenReceived(yahooToken)

                // 別スレッド(AsynckTask)でID Tokenの検証、UserInfoエンドポイントにリクエスト
                val asyncTask = YConnectImplicitAsyncTask(this, idTokenString)
                val result = asyncTask.execute("Verify ID Token and Request UserInfo.")
                onDataReceived(result.get())

            } catch (e: AuthorizationException) {
                LogUtils.e(TAG, "error=" + e.error + ", error_description=" + e.errorDescription)
            }

        } else {

            /********************************************************
             * Request Authorization Endpoint for getting Access Token.
             */

            // 各パラメーター初期化

            val display = OIDCDisplay.TOUCH
            val prompt = arrayOf(OIDCPrompt.DEFAULT)
            val scope = arrayOf(OIDCScope.OPENID, OIDCScope.PROFILE, OIDCScope.EMAIL, OIDCScope.ADDRESS)

            // 各パラメーターを設定
            yconnect.init(
                YahooHelper.clientId,
                YahooHelper.customUriScheme,
                YahooHelper.state,
                display,
                prompt,
                scope,
                YahooHelper.nonce,
                YahooHelper.BAIL,
                YahooHelper.MAX_AGE
            )
            // Authorizationエンドポイントにリクエスト
            // (CustomTabs、ブラウザーを起動して同意画面を表示)
            yconnect.requestAuthorization(this)

            finish()
        }
    }


}
