package jp.co.sbibits.sample.test.encode

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.base.extension.sha1
import jp.co.sbibits.base.extension.sha256
import jp.co.sbibits.base.util.AESUtils
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityEncodeBinding

class EncodeActivity : AppCompatActivity() {

    var type: Int = 1
    var secretKey = "hnmSQari6hZSh3x3aXJDAXKwMXukLbSe"

    val binding by  lazy {
        ActivityEncodeBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        loadEncodeType()
        initEncode()
        initDecode()
    }

    private fun getSpinnerAdapter(): ArrayAdapter<String> {
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        return adapter
    }

    private fun loadEncodeType() {
        val items: MutableList<String> = mutableListOf("AES", "SHA1", "SHA256")
        val unitAdapter = getSpinnerAdapter()
        binding.btnEncodeType.adapter = unitAdapter
        unitAdapter.addAll(items)
        binding.btnEncodeType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (type != position) {
                    reset()
                    type = position
                    binding.etDecode.visibility = if (type == 0) View.VISIBLE else View.GONE
                    binding.tvDecode.visibility = if (type == 0) View.VISIBLE else View.GONE
                }
            }
        }
    }

    fun encrypt(text: String): String? {
        var result: String? = null
        if (type == 0) {
            result = AESUtils.convenientEncrypt(text, secretKey)
        }
        if (type == 1) {
            result = text.sha1()
        }
        if (type == 2) {
            result = text.sha256()
        }
        return result
    }

    private fun initEncode() {
        binding.etEncode.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s.toString().isEmpty()) return
                var encodedText = encrypt(s.toString())
                binding.tvEncode.text = encodedText
                binding.etDecode.setText(encodedText)
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })
    }

    private fun initDecode() {
        binding.btnDecode.setOnClickListener {
            val result = AESUtils.convenientDecrypt(binding.etDecode.text.toString(), secretKey)
            binding.tvDecode.text = result ?: "illegal"
        }
    }

    fun reset() {
        binding.etDecode.text = null
        binding.tvDecode.text = null
        binding.etEncode.text = null
        binding.tvEncode.text = null
    }
}
