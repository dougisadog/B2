package jp.co.sbibits.sample.test.banner.view

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.widget.ViewPager2
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.test.banner.BannerFragment
import jp.co.sbibits.sample.test.banner.adapter.RecyclePagerAdapter
import jp.co.sbibits.sample.test.banner.adapter.registerRecycleOnPageChangeCallback
import jp.co.sbibits.sample.test.banner.adapter.setRecycleAdapter
import jp.co.sbibits.sample.test.banner.adapter.starAuto
import jp.co.sbibits.sample.test.banner.entity.Banner

/**
 * common banner
 */
class BannerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet, defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    init {
        initView(context, attrs)
    }

    private var container: LinearLayout? = null
    private var viewPager: ViewPager2? = null

    private fun initView(context: Context, attrs: AttributeSet) {
        val view = LayoutInflater.from(context).inflate(R.layout.view_banner2, this, true)
        viewPager = view.findViewById(R.id.bannerVp)
        container = view.findViewById(R.id.indicatorContainer)
        attrs(attrs)
    }

    private fun attrs(attrs: AttributeSet) {
//        val attributes = context.obtainStyledAttributes(attrs, R.styleable.Banner)
//        if (attributes != null) {
//        }
    }

    fun initBanner(banners: MutableList<Banner>, context: Any) {
        visibility = VISIBLE
        val bannerVp = viewPager ?: return
        val container = container ?: return
        val fragmentList = mutableListOf<Fragment>()
        banners.forEach {
            //https://docs.google.com/spreadsheets/d/1MtgPWSnVuM99HCVb3gBj7SS1MnOx_Np8/edit#gid=854754748 Q&A 8-2
            if (!it.image.isNullOrEmpty() && !it.link.isNullOrEmpty())
                fragmentList.add(BannerFragment.newInstance(it))
        }
        if (fragmentList.isEmpty()) {
            visibility = GONE
            return
        }
        val adapter: RecyclePagerAdapter<Banner>
        if (context is Fragment) {
            adapter = RecyclePagerAdapter(context, banners) {
                BannerFragment.newInstance(it)
            }
        } else if (context is FragmentActivity) {
            adapter = RecyclePagerAdapter(context, banners) {
                BannerFragment.newInstance(it)
            }
        } else {
            return
        }
        bannerVp.offscreenPageLimit = fragmentList.size
        bannerVp.setRecycleAdapter(adapter)
        bindIndicatorToViewPager(container, bannerVp)
        bannerVp.starAuto()
    }

    fun bindIndicatorToViewPager(
        indicatorContainer: LinearLayout,
        viewPager2: ViewPager2,
        selectorRes: Int = R.drawable.select_vp_indicator
    ) {
        val a = viewPager2.adapter as? RecyclePagerAdapter<*> ?: return
        val size = a.data.size
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(15, 0, 15, 0)
        for (i in 0 until size) {
            val indicator = ImageView(context)
            indicator.setImageResource(selectorRes)
            indicator.layoutParams = params
            indicatorContainer.addView(indicator)
        }
        viewPager2.registerRecycleOnPageChangeCallback { position ->
            for (i in 0 until size) {
                indicatorContainer.getChildAt(i).isSelected = i == position
            }
        }
    }
}
