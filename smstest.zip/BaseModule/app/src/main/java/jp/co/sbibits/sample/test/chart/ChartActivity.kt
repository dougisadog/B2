package jp.co.sbibits.sample.test.chart

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.test.chart.mts.MajorIndexAPI
import jp.co.sbibits.sample.test.chart.mts.chart.*
import jp.co.sbibits.sample.test.chart.mts.chart.ChartApiLoader
import jp.co.sbibits.base.chart.ui.*
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.util.LogUtils
import jp.co.sbibits.sample.databinding.ActivityChartBinding
import jp.co.sbibits.sample.test.chart.mts.MajorIndexResponse

class ChartActivity : AppCompatActivity() {

    lateinit var chartManager: ChartManager

    val binding by  lazy {
        ActivityChartBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.btnSetting.setOnClickListener {
            val i = Intent(this, ChartSettingActivity::class.java)
            val type = binding.chartFrame.chartView.setting.ashiType.rawValue
            i.putExtra("type", type)
            startActivityForResult(i, 10000)
        }

        initChartConfig()
        loadChartBaseData()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == 1) {
            val setting = binding.chartFrame.chartView.setting
            val paramSet = ChartParamSet.instance.copy
            chartManager.onTechnicalSettingChanged(paramSet, setting)
        }
    }

    private fun initChartConfig() {
        ChartBaseConfig.priceMarkerPurple = R.drawable.price_marker_purple
        ChartBaseConfig.priceMarkerOrange = R.drawable.price_marker_orange
        ChartBaseConfig.priceMarkerGray = R.drawable.price_marker_gray
        ChartBaseConfig.timeMarkerPurple = R.drawable.time_marker_purple
        ChartBaseConfig.timeMarkerOrange = R.drawable.time_marker_orange
        ChartBaseConfig.timeMarkerGray = R.drawable.time_marker_gray

        initChartApi()
    }

    private fun initChartApi() {
        ChartApiLoader.registApi(ChartSourceType.STOCK, 0) { ChartStockAPI() }
        ChartApiLoader.registApi(ChartSourceType.INDEX, 0) { ChartIndexAPI() }
        ChartApiLoader.registApi(ChartSourceType.FX, 0) { ChartFxAPI() }

        ChartApiLoader.registApi(ChartSourceType.STOCK, 1) { ChartStockUpdateAPI() }
        ChartApiLoader.registApi(ChartSourceType.INDEX, 1) { ChartIndexUpdateAPI() }
        ChartApiLoader.registApi(ChartSourceType.FX, 1) { ChartFxUpdateAPI() }
    }

    private fun loadChartBaseData() {
        val api = MajorIndexAPI()
        api.indicator = binding.indicator
        api.execute {
            if (it.records.size == 0) return@execute
            val record = it.records[0]
            val name = record.indexName
            val code = record.indexCode
            if (name != null && code != null) {
                val type = ChartSourceType.lookupForMarket(category = record.category)
                val source = ChartSource(
                    type = type,
                    code = code,
                    isMinuteAshiEnabled = record.isMinuteAshiEnabled
                )
                initChartData(source, name)
                initComparisonBtn(it.records)
            } else {
                finish()
            }
        }
    }

    private fun initChartData(source: ChartSource, name: String) {
        chartManager = ChartManager(
            this,
            binding.chartFrame.chartView,
            source,
            name
        )
        chartManager.loadAshiPullDownParams(this::loadUnit)
        chartManager.loadCustomLinePullDownParams(this::loadCustomLine)
        chartManager.loadMainTechnicalPullDownParams(this::loadMainTech)
        chartManager.loadSubTechnicalPullDownParams(this::loadSubTech)

        chartManager.loadVolumeGraph(this::loadVolumeGraph)
        chartManager.loadTurningPointGraph(this::loadTurningPointGraph)
        chartManager.onUpdateRecordSelectedLabelNames = { openLabel,
            highLabel,
            lowLabel,
            closeLabel,
            headerVolumeLabel,
            headerTimeLabel ->
            val result = StringBuilder().append("openLabel: $openLabel \n")
                .append("highLabel: $highLabel \n")
                .append("lowLabel: $lowLabel \n")
                .append("closeLabel: $closeLabel \n")
                .append("headerVolumeLabel: $headerVolumeLabel \n")
                .append("headerTimeLabel: $headerTimeLabel \n")
                .toString()
            LogUtils.d("chart labels", result)
        }
        chartManager.start()
    }

    private fun getSpinnerAdapter(): ArrayAdapter<String> {
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        return adapter
    }

    private fun loadVolumeGraph(current: Boolean, itemClick: (Boolean) -> Unit) {
        binding.btnVolunm.isChecked = current
        binding.btnVolunm.setOnCheckedChangeListener { buttonView, isChecked ->
            itemClick.invoke(isChecked)
        }
    }

    private fun loadTurningPointGraph(current: Boolean, itemClick: (Boolean) -> Unit) {
        binding.btnTurnPoint.isChecked = current
        binding.btnTurnPoint.setOnCheckedChangeListener { buttonView, isChecked ->
            itemClick.invoke(isChecked)
        }
    }

    private fun initComparisonBtn(records: List<MajorIndexResponse.Record>) {
        val names = records.map { it.indexName }

        val comparisonAdapter = getSpinnerAdapter()
        binding.btnComparison.adapter = comparisonAdapter
        comparisonAdapter.addAll(names)
        binding.btnComparison.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {
                }

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    chartManager.setComparisonSetting(
                        records[position],
                        ComparisonTargetType.DOMESTIC_INDEX
                    )
                }
            }
    }

    private fun loadUnit(items: MutableList<String>, current: String, itemClick: (String) -> Unit) {
        val unitAdapter = getSpinnerAdapter()
        binding.btn.adapter = unitAdapter
        unitAdapter.addAll(items)
        binding.btn.setSelection(items.indexOf(current))
        binding.btn.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position != items.indexOf(current)) {
                    itemClick.invoke(items[position])
                }
            }
        }
    }

    private fun loadMainTech(
        items: MutableList<String>,
        currents: MutableList<String>,
        itemClick: (String) -> Unit
    ) {
        val mainTechAdapter = getSpinnerAdapter()
        items.add("null")
        binding.btnMainTech.adapter = mainTechAdapter
        mainTechAdapter.addAll(items)
        val index = items.indexOf(currents.firstOrNull())
        binding.btnMainTech.setSelection(if (index == -1) (items.size - 1) else index)

        binding.btnMainTech.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                itemClick.invoke(items[position])
            }
        }
    }

    private fun loadSubTech(
        items: MutableList<String>,
        currents: MutableList<String>,
        itemClick: (MutableList<String>) -> Unit
    ) {
        val subTech1Adapter = getSpinnerAdapter()
        items.add("null")
        binding.btnSubTech1.adapter = subTech1Adapter
        subTech1Adapter.addAll(items)
        val index1 = items.indexOf(currents.firstOrNull())
        binding.btnSubTech1.setSelection(if (index1 == -1) (items.size - 1) else index1)
        binding.btnSubTech1.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val datas = mutableListOf<String>()
                datas.add(items[position])
                datas.add(binding.btnSubTech2.selectedItem.toString())
                itemClick.invoke(datas)
            }
        }
        val subTech2Adapter = getSpinnerAdapter()
        binding.btnSubTech2.adapter = subTech2Adapter
        subTech2Adapter.addAll(items)
        var index2 = 0
        if (currents.size > 1) {
            index2 = items.indexOf(currents[1])
        }
        binding.btnSubTech2.setSelection(if (index2 == -1) (items.size - 1) else index2)
        binding.btnSubTech2.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val datas = mutableListOf<String>()
                datas.add(binding.btnSubTech1.selectedItem.toString())
                datas.add(items[position])
                itemClick.invoke(datas)
            }
        }
    }

    private fun loadCustomLine(items: MutableList<DrawingMode>, itemClick: (DrawingMode?) -> Unit) {
        val customLineAdapter = getSpinnerAdapter()
        binding.btnCustomLine.adapter = customLineAdapter
        customLineAdapter.addAll(items.map { it.name })
        customLineAdapter.add("all delete")
        binding.btnCustomLine.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                itemClick.invoke(if (position == items.size) null else items[position])
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        chartManager.dataService.clear()
    }

    class ChartManager(
        activity: Activity,
        charView: ChartView,
        override var chartSource: ChartSource,
        name: String
    ) : ChartAction(activity, charView, chartSource, SettingType.index, name) {

        val dataService = ChartDataService()
        private val ashiType = chartView.ashiTypeUnit
        private var chartProcessTask: ChartProcessTask = { state ->
            //            var loadingView = (activity as ChartActivity).indicator
//            loadingView.visibility = if (state) View.VISIBLE else View.INVISIBLE

//             chartFrame.chartView.loadingBitmap = BitmapFactory.decodeResource(
//                 ContextManager.getContext()?.resources,
//                 R.drawable.price_marker_orange
//             )
            chartView.showLoadingLabel(state)
        }
//        val setting = ChartSetting(fileName = settingType.rawValue)

        fun setComparisonSetting(
            index: MajorIndexResponse.Record,
            targetType: ComparisonTargetType
        ) {
            chartView.setting.comparisonTargetMarket = null
            chartView.setting.comparisonTargetCode = index.indexCode ?: ""
            chartView.setting.comparisonTargetName = index.indexName ?: ""
            chartView.setting.comparisonTargetType = targetType

            val setting = chartView.setting.copy
            val paramSet = ChartParamSet.instance.copy
            onTechnicalSettingChanged(paramSet, setting)
        }

        fun start() {
            dataService.singleLoad(chartSource,
                ashiType,
                chartProcessTask = chartProcessTask,
                isAutoUpdate = true,
                onUpdate = { data: ChartData?, count: Int? ->
                    data?.let { refresh(it) }
                })
        }

        override fun loadChartData(source:ChartSource, receiver: ChartDataReceiver) {
            dataService.singleLoad(source,
                ashiType,
                chartProcessTask = chartProcessTask,
                isAutoUpdate = false,
                onUpdate = { data: ChartData?,  count: Int? ->
                    receiver.invoke(data)
                    this.fCurrentPrice =  0.0
                })
        }

        override fun loadChartComparisonData(comparisonSource:ChartSource , receiver: ChartDataReceiver) {
            dataService.singleLoad(comparisonSource,
                ashiType,
                chartProcessTask = chartProcessTask,
                isComparison = true,
                onUpdate = { data: ChartData?, count: Int? ->
                    val copy = ValueArray()
                    data?.get(ChartDataType.CLOSE)?.forEach {
                        copy.append(it!! + 200)
                    }
                    data?.set(ChartDataType.CLOSE, copy)
                    receiver.invoke(data)
                })
            dataService.synch(
                chartSource,
                chartView.setting.comparisonSource,
                ashiType = chartView.ashiTypeUnit
            )
        }

//        init {
//            // 分足不可で分足選択している場合日足に変更
//            if (!chartSource.isMinuteAshiEnabled && chartView.setting.ashiType == ChartAshiType.minute) {
//                chartView.setting.ashiType = ChartAshiType.day
//                chartView.setting.ashiUnit = 1
//                chartView.setting.save()
//            }
//        }
    }
}
