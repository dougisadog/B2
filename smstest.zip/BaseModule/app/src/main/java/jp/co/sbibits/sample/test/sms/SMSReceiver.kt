package jp.co.sbibits.sample.test.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import jp.co.sbibits.base.util.LogUtils

class SMSReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        LogUtils.e("tttt", "onReceive:$action")
        if (action == SMSUtil.SMS_RECEIVED) {
            val smsTexts = SMSUtil.readByIntent(intent)
            SMSUtil.messages.value = smsTexts
        }
    }
}