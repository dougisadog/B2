package jp.co.sbibits.sample.test.chart.mts.chart

import jp.co.sbibits.base.CGFloat

class ChartResponseRecord {

    var dateTime: String? = null        //DATE
    var open: String? = null            //始値（計算用）
    var high: String? = null            //高値（計算用）
    var low: String? = null             //安値（計算用）
    var close: String? = null           //終値（計算用）
    var volume: String? = null          //出来高（計算用）
    // 価格のレート。各APIレスポンスにこのレートをかけた値が実際の価格になる
    var rate: CGFloat = 0.01

    val fOpen: CGFloat?
        get() = floatValue(str = open, rate = rate)

    val fHigh: CGFloat?
        get() = floatValue(str = high, rate = rate)

    val fLow: CGFloat?
        get() = floatValue(str = low, rate = rate)

    val fClose: CGFloat?
        get() = floatValue(str = close, rate = rate)

    val fVolume: CGFloat?
        get() = floatValue(str = volume)

    constructor() {}

    constructor(rate: CGFloat) {
        this.rate = rate
    }

    fun floatValue(str: String?, rate: CGFloat = 1.0) : CGFloat? {
        try {
            val d = str?.toDouble()
            if (str != null && d != null) {
                return d * rate
            }
        } catch (e: NumberFormatException) {
            // 変換不能な場合はnullを返す
        }
        return null
    }
}