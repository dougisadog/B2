package jp.co.sbibits.sample.test.db

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.test.db.entity.FeedEntry
import java.io.File

typealias ItemClick = (name:Any?) -> Unit

class DBAdapter : RecyclerView.Adapter<DBAdapter.MyViewHolder>() {

    var indexRecords: MutableList<FeedEntry> = mutableListOf()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    var listener: ItemClick? = null

    var context: Activity? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflatedView =
            LayoutInflater.from(context).inflate(R.layout.item_db, parent, false)
        return MyViewHolder(inflatedView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        var record = indexRecords.get(position)
        holder.bind(record, listener = listener)
    }

    override fun getItemCount(): Int {
        return indexRecords.size
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var name: TextView? = null
        var content: TextView? = null
        var content2: TextView? = null
        var delete: Button? = null

        init {
            name = itemView.findViewById(R.id.tvName)
            content = itemView.findViewById(R.id.tvSub)
            content2 = itemView.findViewById(R.id.tvSub2)
            delete = itemView.findViewById(R.id.btnDelete)
        }

        fun bind(item: FeedEntry, listener: ItemClick?) {
            name?.text = item.title.toString()
            content?.text = item.subTitle
            content2?.text = item.subTitle2
            delete?.setOnClickListener { listener?.invoke(item.title) }
        }
    }
}
