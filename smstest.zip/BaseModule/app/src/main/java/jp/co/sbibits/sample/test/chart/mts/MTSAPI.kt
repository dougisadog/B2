package jp.co.sbibits.sample.test.chart.mts

import jp.co.sbibits.base.chart.ios.StringEnum
import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.extension.*
import jp.co.sbibits.base.http.HttpTask
import jp.co.sbibits.base.http.HttpTaskError
import jp.co.sbibits.base.http.PostType
import jp.co.sbibits.base.http.util.QueryUtils
import jp.co.sbibits.base.util.LogUtils
import okhttp3.ResponseBody
import java.net.URLEncoder
import java.nio.charset.Charset
import kotlin.reflect.KClass

/**
 * MTS APIの通信基盤
 * Created by yamamoto on 2018/01/26.
 */

typealias MtsErrorHandler = (ErrorType) -> Unit

abstract class MTSAPI<DataType : MTSResponse> : HttpTask<DataType>() {

    val mtsBaseURL = "https://sbi-toshin-stub.cross-dev.net/kabustub/yamamoto"

    enum class ParamAlign {
        LEFT,
        RIGHT
    }

    open val responseEncoding: Charset
        get() = Charset.forName("Shift_JIS")
    var readOffset = 0
    var responseData: ByteArray? = null
    var apiParams: MutableList<String> = mutableListOf()

    var mtsErrorHandler: MtsErrorHandler? = null

    private var sessionId: String = ""

    open val trCode: String = ""

    override val baseURL: String
        get() = mtsBaseURL
    override val path: String
        get() = "/mtsmobile/commgate"
    override var httpMethod: String = "POST"
    
    override val headers: Map<String, String>
        get() = mapOf("Content-type" to "application/x-www-form-urlencoded")
    override val requestEncoding: Charset
        get() = Charset.forName("Shift_JIS")

    private fun reset() {
        readOffset = 0
        responseData = null
        apiParams = mutableListOf()
        mtsErrorHandler = null

        queryItems.clear()
    }

    override fun prepareRequest() {
        reset()
        makeInputParameter()
//         addQuery(key = "SID", value = sessionId)
//         addQuery(key = "TRCODE", value = trCode)
//         addQuery(key = "FSTIME", value = "         ")
//         addQuery(key = "TRIN", value = apiParams.joined())
        val  SID = URLEncoder.encode(sessionId, responseEncoding.name())
        val  TRCODE = URLEncoder.encode(trCode, responseEncoding.name())
        val  FSTIME = URLEncoder.encode("         ", responseEncoding.name())
        val  TRIN = URLEncoder.encode(apiParams.joined(), responseEncoding.name())

        addQuery(key = "SID", value = SID)
        addQuery(key = "TRCODE", value = TRCODE)
        addQuery(key = "FSTIME", value = FSTIME)
        addQuery(key = "TRIN", value = TRIN)

        post(PostType.FORM)
    }

//     override fun customizeBody(): RequestBody? {
//         var body: RequestBody? = null
//         val query = makeQueryString()
//         if (query != null) {
//             val data = query.data(using = requestEncoding)
//             body = RequestBody.create(MediaType.parse(headers["Content-type"]), data)
//         }
//         return body
//     }

    open fun makeInputParameter() {
        // override this
    }

    override fun convert(data: ResponseBody): DataType {
        return parseResponse(data.bytes())
    }

    fun parseResponse(data: ByteArray): DataType {
        responseData = data
        if (data.size < 70) {
            throw HttpTaskError.Parse
        }

        val result = resultClass.java.newInstance()

        parseCommonHeader(result = result)

        if (result.result == MTSResponse.ResultStatus.SUCCESS) {
            parseAPIResponse(result = result)
        }

        return result
    }

    override fun isValidResponse(response: DataType): Boolean {
        val isValid = response.result == MTSResponse.ResultStatus.SUCCESS
        val responseData = this.responseData

        if (!isValid && responseData != null) {
            val responseText = String(bytes = responseData, charset = responseEncoding)
            LogUtils.i(javaClass.simpleName, "  InvalidResponse:$responseText")
        }
        return isValid
    }

    private fun parseCommonHeader(result: DataType) {
        skip(6)                         // レスポンスサイズ
        sessionId = read(28).toString() // セッションID
        result.trCode = read(5)         // トランザクションコード
        skip(6)                         // サーバー時間(hhmmss)
        result.resultCode = read(6)     // 処理結果コード
        result.notificationFlag =
            readEnum(1, type = MTSResponse.NotificationFlag::class) // 通知メッセージ有無
        result.lastExecutionTime = read(9)  // 最終約定通知受信時間　　'hhmmssMMM'
        result.maintenanceFlag = read(5)    // メンテナンスフラグ
        skip(4)                             // 予備エリア
    }

//     override fun postProcess(result: DataType) {
//         if (result.result == MTSResponse.ResultStatus.SUCCESS) {
//             startAfterProcessTimer()
//         }
//     }

    @Suppress("NAME_SHADOWING")
    override fun errorProcess(type: HttpTaskError, result: DataType?, info: ResponseInfo) {
        val result = result
        var errorType: ErrorType = ErrorType.unknown

        when {
            result == null ->
                errorType = ErrorType.noResult
            result.hasServerError ->
                errorType = ErrorType.server
            result.result == MTSResponse.ResultStatus.LENGTH_ERROR ->
                errorType = ErrorType.connection
            result.result == MTSResponse.ResultStatus.NO_SESSION || result.result == MTSResponse.ResultStatus.MOIRA_NO_SESSION ->
                errorType = ErrorType.sessionTimeOut
        }
        mtsErrorHandler?.invoke(errorType)
    }

    // APIレスポンスを取得する
    open fun parseAPIResponse(result: DataType) {}

    fun addRight(value: String?, len: Int) {
        addParam(param = value, size = len, align = ParamAlign.RIGHT)
    }

    fun addLeft(value: String?, len: Int) {
        addParam(param = value, size = len, align = ParamAlign.LEFT)
    }

    fun addParam(param: String?, size: Int, align: ParamAlign) {
        var value = param ?: ""
        var data = value.data(using = requestEncoding)
        while ((size < data.size)) {
            value = value.prefix(value.length - 1)
            data = value.data(using = requestEncoding)
        }
        val additionalSize = size - data.size
        for (i in 0 until additionalSize) {
            when (align) {
                ParamAlign.LEFT -> value = value + " "
                ParamAlign.RIGHT -> value = " " + value
            }
        }
        apiParams.append(value)
    }

    fun skip(size: Int) {
        readOffset += size
    }

    fun read(size: Int): String? {
        val data = readData(size) ?: return null
        var result = String(bytes = data, charset = responseEncoding)
        result = result.replacingOccurrences(of = "\u0000", with = "")
        result = result.trim()
        return result
    }

    fun readData(size: Int): ByteArray? {
        val responseData = responseData ?: return null
        if (responseData.size < readOffset + size) {
            return null
        }
        val result = responseData.copyOfRange(fromIndex = readOffset, toIndex = readOffset + size)

        readOffset += size
        return result
    }

    fun readRest(): String? {
        val responseData = responseData ?: return null
        val len = responseData.size - readOffset
        return read(len)
    }

    fun readRestData(): ByteArray? {
        val responseData = responseData ?: return null
        val len = responseData.size - readOffset
        return readData(len)
    }

    fun readInt(size: Int): Int {
        try {
            val i = read(size)?.toInt()
            return i ?: 0
        } catch (e: NumberFormatException) {
            return 0
        }
    }

    inline fun <reified T> readEnum(size: Int, type: KClass<T>): T? where T : Enum<T>,
                                                                          T : StringEnum {
        val code = read(size)
        return T::class.value(code)
    }

    override fun makeQueryString(): String? {
        return QueryUtils.makeQueryString(items = queryItems, encoder = { value ->
            URLEncoder.encode(value, responseEncoding.name())
        })
    }

    // Androidの場合は円マークをバックスラッシュにエスケープする
    fun escapePassword(password: String?): String? {
        return password?.replace("¥", "\\")
    }
}

sealed class ErrorType {
    object server : ErrorType()
    object connection : ErrorType()
    object sessionTimeOut : ErrorType()
    object noResult : ErrorType()
    object unknown : ErrorType()

    val stringValue: String
        get() {
            return when (this) {
                server -> "オフライン、タイムアウトなどの通信エラー"
                connection -> "HTTPステータスコードが既定ではないエラー"
                sessionTimeOut -> "レスポンスデータのパースに失敗"
                unknown -> "レスポンスデータの内容が不正"
                noResult -> "no result"
            }
        }
}



