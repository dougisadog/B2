package jp.co.sbibits.sample.test.yahoo

import jp.co.sbibits.sample.test.yahoo.helper.YConnectImplicitActivity
import jp.co.sbibits.sample.test.yahoo.helper.YahooHelper
import jp.co.sbibits.sample.test.yahoo.helper.YahooToken
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ImplicitBinding
import jp.co.yahoo.yconnect.core.oidc.IdTokenObject
import jp.co.yahoo.yconnect.core.oidc.UserInfoObject


class YahooActivity : YConnectImplicitActivity() {

    val binding by  lazy {
        ImplicitBinding.inflate(layoutInflater)
    }
    override fun onTokenReceived(yahooToken: YahooToken) {
        binding.accessToken.text = yahooToken.accessTokenString
        binding.expiration.text = yahooToken.expiration.toString()
        binding.idToken.text = yahooToken.idTokenString
    }

    override fun onDataReceived(results: Pair<UserInfoObject, IdTokenObject>) {
        binding.userInfo.text = results.first.toString()
        binding.idTokenObject.text = results.second.toString()

    }

    override fun init() {
        YahooHelper.clientId = "dj00aiZpPU9kOFo1WGRWN25CWiZzPWNvbnN1bWVyc2VjcmV0Jng9YmY-"
        YahooHelper.customUriScheme = getString(R.string.scheme) + "://" + getString(R.string.host)
    }

    override val resId: Int
        get() = R.layout.implicit
}