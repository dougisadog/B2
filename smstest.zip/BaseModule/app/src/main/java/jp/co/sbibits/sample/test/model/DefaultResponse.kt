package jp.co.sbibits.sample.test.model

data class DefaultResponse
    (
    var maintenance: MaintenanceConfig?,
    var maintenanceMulti: MaintenanceConfig?,
    var serviceStop: ServiceStopConfig?
) {

    class AppConfig {
        var mtsURL: Map<String, String>? = null
        var minVersion: String? = null
        var storeURL: String? = null
        var hideAccountOpenButton: List<String>? = null

    }

    class MaintenanceConfig {
        var trigger: String? = null
        var message: String? = null
    }

    class ServiceStopConfig {
        var trigger: Boolean? = null
        var message: String? = null
    }

    private var iOS: AppConfig? = null
    private var android: AppConfig? = null
    val appConfig: AppConfig? // OS間の差異をここで吸収する(iOS、andoridのpropertyは外部で直接参照しない)
        get() = android
//    var maintenance: MaintenanceConfig? = null
//    var maintenanceMulti: MaintenanceConfig? = null
//    var serviceStop: ServiceStopConfig? = null
}
