package jp.co.sbibits.sample.test.versioncheck

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.base.versioncheck.ChannelGoogle
import jp.co.sbibits.base.versioncheck.VersionCheckManager
import jp.co.sbibits.base.versioncheck.VersionInfo
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityVersionCheckBinding

class VersionCheckActivity : AppCompatActivity() {

    val binding by  lazy {
        ActivityVersionCheckBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        binding.btnVersionCheck.setOnClickListener {
            checkVersion()
        }
    }

    private fun checkVersion() {
        val versionInfo: VersionInfo
        val packageName = binding.etPackageName.text.toString()
        versionInfo = if (!packageName.isEmpty()) {
            VersionInfo(packageName, "0", 0)
        } else {
            VersionInfo.getDefault()
        }
        val channel = ChannelGoogle(versionInfo)
        val callBack = object : VersionCheckManager.UpdateCallback {
            override fun onNoUpdate() {
                Toast.makeText(this@VersionCheckActivity, "no update", Toast.LENGTH_LONG).show()
            }

            override fun needUpdate(info: VersionInfo) {
                Toast.makeText(
                    this@VersionCheckActivity,
                    "need update version to ${info.versionName}",
                    Toast.LENGTH_LONG
                ).show()
                channel.showGoogleForceUpdateDialog(this@VersionCheckActivity)
            }
        }
        VersionCheckManager.checkVersion(callBack, channel)
    }
}
