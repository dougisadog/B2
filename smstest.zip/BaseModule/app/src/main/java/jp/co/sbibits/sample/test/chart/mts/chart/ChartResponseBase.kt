package jp.co.sbibits.sample.test.chart.mts.chart

import jp.co.sbibits.base.chart.ui.model.ChartAshiTypeUnit
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.model.ChartData
import jp.co.sbibits.base.chart.ui.model.ChartDataType

open class ChartResponseBase {

    var currentPrice: String? = null    // 現在値
    var previousClose: String? = null   // 前日終値
    var change: String? = null          // 前日比
    var highPrice: String? = null       // 最高値
    var lowPrice: String? = null        // 最安値
    var priceColorCode: String? = null  // 現在値色フラグ
    var upDownArrow: String? = null     // 現在値ティック（表示用）
    var upDownCode: String? = null      // 現在値ティック
    var updateTime: String? = null      // 現在値更新時刻

    var records: MutableList<ChartResponseRecord> = mutableListOf()

    var updatedData: MutableMap<ChartAshiTypeUnit, List<ChartResponseRecord>> = mutableMapOf()

    // 小数点以下の長さ
    var decimalLength: Int = 2

    fun supply() {

        // 先頭の0データは未定義とする
        for (i in records.indices) {
            val record = records[i]
            if (record.fOpen == 0.0 || record.fHigh == 0.0 || record.fLow == 0.0 || record.fClose == 0.0) {
                record.open = null
                record.high = null
                record.low = null
                record.close = null
            } else {
                break
            }
        }

        // 0の箇所は前の値を引き継ぐ
        var preRecord: ChartResponseRecord? = null
        for (i in records.indices) {
            val record = records[i]
            // 終値がなければ前日終値を引き継ぐ
            if (record.fClose == 0.0) {
                record.close = preRecord?.close
            }

            // 始値がなければ終値と同じ
            if (record.fOpen == 0.0) {
                record.open = record.close
            }

            // 高値、安値もなければ終値と同じ（本当は終値と安値の高い方、低い方にした方がよいが）
            if (record.fHigh == 0.0) {
                record.high = record.close
            }
            if (record.fLow == 0.0) {
                record.low = record.close
            }
            preRecord = record
        }
    }

    val fCurrentPrice: CGFloat?
        get() = currentPrice?.toDoubleOrNull()

    fun makeData(): ChartData {
        val data = ChartData()
        data.decimalLength = decimalLength
        records.forEach { record ->
            val time = record.dateTime
            if (time != null) {
                data.addAxis(time)
                data[ChartDataType.OPEN].plusAssign(record.fOpen)
                data[ChartDataType.HIGH].plusAssign(record.fHigh)
                data[ChartDataType.LOW].plusAssign(record.fLow)
                data[ChartDataType.CLOSE].plusAssign(record.fClose)
                data[ChartDataType.VOLUME].plusAssign(record.fVolume)
            }
        }
        return data
    }
}