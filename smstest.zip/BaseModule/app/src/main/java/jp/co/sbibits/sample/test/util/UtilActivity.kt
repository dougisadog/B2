package jp.co.sbibits.sample.test.util

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import jp.co.sbibits.base.ApkInfo
import jp.co.sbibits.base.util.AlertUtils
import jp.co.sbibits.base.util.DeviceUtils
import jp.co.sbibits.base.util.ToastUtils
import jp.co.sbibits.sample.R
import jp.co.sbibits.sample.databinding.ActivityUtliBinding

class UtilActivity : AppCompatActivity() {

    val binding by  lazy {
        ActivityUtliBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
    }

    fun getPhoneMessage(view: View) {
        binding.message.text = " PackageName::${ApkInfo.packageName} \n" +
            " DeviceUtils.version::${DeviceUtils.version} \n" +
            " DeviceUtils.model::${DeviceUtils.model} \n" +
            " DeviceUtils.brand::${DeviceUtils.brand} \n"
    }

    fun getNetWork(view: View) {
//        getNetWork.text = " isWifiEnabled::${NetworkUtils.isWifiEnabled(this)}  \n\"" +
//            " is2G::${NetworkUtils.is2G(this)}  \n\"" +
//            " is3G::${NetworkUtils.is3G(this)}  \n\"" +
//            " isWifi::${NetworkUtils.isWifi(this)}  \n\"" +
//            " checkNet::${NetworkUtils.checkNet(this)}"
    }

    fun showDialog1(view: View) {
        val dialog = AlertUtils(this)
        dialog.showOperateMessage("one button test")
        dialog.show()
    }

    fun showDialog2(view: View) {
        val dialog = AlertUtils(this)
        dialog.setPositiveButton("confirm", View.OnClickListener {
            ToastUtils.showMessage("confirmed!")
        })
        dialog.showOperateMessage("one button test")
        dialog.show()
    }

    fun showDialog3(view: View) {
        val dialog = AlertUtils(this)
        dialog.setPositiveButton("confirm1", View.OnClickListener {
            ToastUtils.showMessage("confirmed1!")
        })
        dialog.setPositiveButton("confirm2", View.OnClickListener {
            ToastUtils.showMessage("confirmed2!")
        })
        dialog.showOperateMessage("one button test")
        dialog.show()
    }

    companion object {
        fun start(context: Context) {
            val starter = Intent(context, UtilActivity::class.java)
            // starter.putExtra()
            context.startActivity(starter)
        }
    }
}
