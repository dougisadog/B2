package jp.co.sbibits.sample.test.yahoo.helper

import android.app.Activity
import android.os.AsyncTask
import android.os.Handler
import android.util.Log
import jp.co.yahoo.yconnect.YConnectImplicit
import jp.co.yahoo.yconnect.core.api.ApiClientException
import jp.co.yahoo.yconnect.core.oidc.IdTokenObject
import jp.co.yahoo.yconnect.core.oidc.UserInfoObject
import jp.co.yahoo.yconnect.core.util.YConnectLogger

/**
 * Implicit Sample Class
 *
 * @author Copyright (C) 2017 Yahoo Japan Corporation. All Rights Reserved.
 */
class YConnectImplicitAsyncTask(private val activity: Activity, private val idTokenString: String) :
    AsyncTask<String, Int, Pair<UserInfoObject, IdTokenObject>>() {
    private val handler: Handler = Handler()

    private val clientId: String = YahooHelper.clientId

    //同意キャンセル時の挙動を指定
    private val bail: String = YahooHelper.BAIL
    //最大認証経過時間
    private val maxAge: String = YahooHelper.MAX_AGE

    private val nonce: String = YahooHelper.nonce


    override fun doInBackground(vararg params: String): Pair<UserInfoObject, IdTokenObject>? {

        Log.d(TAG, params[0])

        // YConnectインスタンス取得
        val yconnect = YConnectImplicit.getInstance()

        try {

            // Access Tokenの読み込み
            val storedAccessToken = YahooHelper.saver.loadToken().accessTokenString

            /***************
             * Verify ID Token.
             */

            Log.i(TAG, "Verify ID Token.")


            // ID Tokenの検証
            yconnect.verifyIdToken(idTokenString, clientId, nonce, storedAccessToken, maxAge)

            // 復号化されたID Token情報を取得
            YahooHelper.token = yconnect.idTokenObject

            /*****************
             * Request UserInfo.
             */

            Log.i(TAG, "Request UserInfo.")

            YConnectLogger.setLogLevel(YConnectLogger.DEBUG)

            // UserInfoエンドポイントにリクエスト
            yconnect.requestUserInfo(storedAccessToken)
            // UserInfo情報を取得
            YahooHelper.info = yconnect.userInfoObject

        } catch (e: ApiClientException) {

            YahooHelper.handleErr(e, activity)

            Log.e(TAG, "error=" + e.error + ", error_description=" + e.errorDescription)
        } catch (e: Exception) {
            Log.e(TAG, "error=" + e.message)
        }

        return Pair(yconnect.userInfoObject, yconnect.idTokenObject)
    }

    companion object {

        private val TAG = YConnectImplicitAsyncTask::class.java.simpleName
    }

}