package jp.co.sbibits.sample.test.chart.mts.chart

import jp.co.sbibits.base.chart.ui.model.ChartSourceType

object ChartApiLoader {

    /**
     * @ChartSourceType api type  Int 0 -> first  1->update
     * @ChartAPI target api
     */
    val apis :MutableMap<Pair<ChartSourceType, Int>, () -> ChartAPI> = mutableMapOf()

    fun registApi(type:ChartSourceType, first:Int, apiCreator: () -> ChartAPI) {
        apis[Pair(type, first)] = apiCreator
    }


}