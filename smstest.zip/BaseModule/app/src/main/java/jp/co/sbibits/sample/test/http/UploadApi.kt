package jp.co.sbibits.sample.test.http

import jp.co.sbibits.base.http.FileHttpTask
import java.io.File
import java.nio.charset.Charset

class UploadApi : FileHttpTask<String>() {
    override var fileParams: List<Pair<String, File>> = listOf()

    var encoding = Charset.forName("utf-8")!!

    override val resultClass = String::class

    // 基本通信先URL
    override val baseURL: String
        get() = "https://ptsv2.com/t/owiya-1551749975/post"

    override fun parseResponse(data: String): String {
        return data
    }
}
