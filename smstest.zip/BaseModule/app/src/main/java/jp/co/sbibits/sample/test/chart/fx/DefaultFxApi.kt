package jp.co.sbibits.sample.test.chart.fx

import jp.co.sbibits.sample.test.chart.fx.model.AssetJsonData
import jp.co.sbibits.base.http.JsonHttpTask

class DefaultFxApi : JsonHttpTask<AssetJsonData>() {

    override val resultClass = AssetJsonData::class

    // 基本通信先URL
    override val baseURL: String
        get() = "https://t-hyperm02.sbisec.co.jp/mtsmobile/kabusp/AppConfig.json"
}

