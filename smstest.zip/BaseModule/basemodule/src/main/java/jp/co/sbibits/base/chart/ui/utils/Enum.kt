package jp.co.sbibits.base.chart.ui.utils

import jp.co.sbibits.base.chart.ios.StringEnum

enum class Category(override val rawValue: String): StringEnum {
    OTHERS("0"), // その他
    DOMESTIC_INDEX("1"), // 国内指標
    FOREIGN_INDEX("2"),  // 海外指標
    FX_RATE("3")         // 為替
}

enum class ChartDisplayType(override val rawValue: String): StringEnum {
    DISABLED("0"),          // チャート表示不可
    ENABLED("1"),           // チャート表示可能
    MINUTE_DISABLED("2");   // 日中足表示不可
}

