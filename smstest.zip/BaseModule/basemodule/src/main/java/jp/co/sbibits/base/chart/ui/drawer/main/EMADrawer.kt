package jp.co.sbibits.base.chart.ui.drawer.main

import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil

/**
 * 指数平滑移動平均線
 */
class EMADrawer : ChartDrawer() {

    private val ema1Color = UIColor(rgbValue = 0xe5e645)
    private val ema2Color = UIColor(rgbValue = 0xe66d45)
    private val ema3Color = UIColor(rgbValue = 0x17e693)

    override fun calculate() {
        val chartData = chartData ?: return
        val closeList = chartData[ChartDataType.CLOSE]

        if (technicalParam.ema1On) {
            val span = technicalParam.ema1Span
            val emaList = ChartMathUtil.calcEMA(src = closeList, span = span)
            chartData[ChartDataType.EMA1] = emaList
        }
        if (technicalParam.ema2On) {
            val span = technicalParam.ema2Span
            val emaList = ChartMathUtil.calcEMA(src = closeList, span = span)
            chartData[ChartDataType.EMA2] = emaList
        }
        if (technicalParam.ema3On) {
            val span = technicalParam.ema3Span
            val emaList = ChartMathUtil.calcEMA(src = closeList, span = span)
            chartData[ChartDataType.EMA3] = emaList
        }
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        val chartData = chartData ?: return
        val ema1On = technicalParam.ema1On
        val ema2On = technicalParam.ema2On
        val ema3On = technicalParam.ema3On
        for (i in state.indices) {
            if (ema1On) {
                range.update(chartData[ChartDataType.EMA1][i])
            }
            if (ema2On) {
                range.update(chartData[ChartDataType.EMA2][i])
            }
            if (ema3On) {
                range.update(chartData[ChartDataType.EMA3][i])
            }
        }
    }

    override fun draw() {
        if (technicalParam.ema1On) {
            drawLineChart(dataType = ChartDataType.EMA1, color = ema1Color)
        }
        if (technicalParam.ema2On) {
            drawLineChart(dataType = ChartDataType.EMA2, color = ema2Color)
        }
        if (technicalParam.ema3On) {
            drawLineChart(dataType = ChartDataType.EMA3, color = ema3Color)
        }
    }

    override fun addLegend() {
        if (technicalParam.ema1On) {
            addLegendValue(title = "短期", dataType = ChartDataType.EMA1, color = ema1Color)
        }
        if (technicalParam.ema2On) {
            addLegendValue(title = "中期", dataType = ChartDataType.EMA2, color = ema2Color)
        }
        if (technicalParam.ema3On) {
            addLegendValue(title = "長期", dataType = ChartDataType.EMA3, color = ema3Color)
        }
    }
}