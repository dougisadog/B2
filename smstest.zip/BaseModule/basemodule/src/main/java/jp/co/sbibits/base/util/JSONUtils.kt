package jp.co.sbibits.base.util

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import kotlin.reflect.KClass

/**
 * Json変換ツール
 */
object JSONUtils {

    /**
     * JSON文字列からオブジェクトに変換
     *
     * @param jsonString JSON文字列
     * @param classOfT オブジェクト
     * @return T オブジェクト(オブジェクト)
     */
    fun <T : Any> parseJsonToObj(jsonString: String, classOfT: KClass<T>): T {
        return Gson().fromJson(jsonString, classOfT.java)
    }

    /**
     * JSON文字列からリスト、MAPに変換
     *
     * @param jsonString JSON文字列
     * @return T オブジェクト(リスト、MAP)
     */
    fun <T> parseJsonToListOrMap(jsonString: String): T {
        val jsonType = object : TypeToken<T>() {}.type
        return Gson().fromJson(jsonString, jsonType)
    }

    /**
     * オブジェクトからJSON文字列に変換
     *
     * @param obj オブジェクト(リスト、MAP、オブジェクトなど)
     * @param pretty 整形フラグ
     * @return JSON文字列
     */
    fun toJson(obj: Any, pretty: Boolean = false): String {
        if (pretty) {
            return GsonBuilder().setPrettyPrinting().create().toJson(obj)
        }
        return Gson().toJson(obj)
    }

}