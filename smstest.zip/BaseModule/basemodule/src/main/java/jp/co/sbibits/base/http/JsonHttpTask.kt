package jp.co.sbibits.base.http


import jp.co.sbibits.base.util.JSONUtils

/**
 * JSON形式の文字列を取得するHTTP処理
 */
abstract class JsonHttpTask<DataType : Any> : HttpTask<DataType>() {

    override fun parseResponse(data: String): DataType {
        return JSONUtils.parseJsonToObj(data, resultClass)
    }
}
