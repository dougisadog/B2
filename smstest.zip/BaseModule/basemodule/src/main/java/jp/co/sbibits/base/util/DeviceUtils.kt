package jp.co.sbibits.base.util

import android.app.Activity
import android.content.Context
import android.graphics.Point
import android.os.Build
import android.view.WindowManager
import jp.co.sbibits.base.ContextManager

/**
 * 端末のシステム情報
 */
object DeviceUtils {

    /**
     * モデル名
     */
    val model: String
        get() = android.os.Build.MODEL

    /**
     * ブランド名
     */
    val brand: String
        get() = android.os.Build.BRAND

    /**
     * ユーザーに表示するバージョン番号
     */
    val version: String
        get() = android.os.Build.VERSION.RELEASE

    fun getScreenShortLength(): Int {
        val windowManager =
            ContextManager.getContext()!!.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = windowManager.defaultDisplay
        val pxSize: Int
        pxSize = if (17 <= Build.VERSION.SDK_INT) {
            val size = Point()
            display.getRealSize(size)
            Math.min(size.x, size.y)
        } else {
            Math.min(display.width, display.height)
        }

        return pxSize
    }

    fun setOrientation(activity: Activity, orientation: Int) {
        activity.requestedOrientation = orientation
    }

    fun getOrientation(activity: Activity): Int {
        return activity.requestedOrientation
    }

    var width: Int = 0
    var height: Int = 0
    var dpi: Int = 0
    var screenWidth: Float = 0f
    var screenHeight: Float = 0f
    var density: Float = 0f

    init {
        val context: Context = ContextManager.getContext()!!
        val displayMetrics = context.resources.displayMetrics
        width = displayMetrics.widthPixels
        height = displayMetrics.heightPixels
        dpi = displayMetrics.densityDpi
        density = displayMetrics.density
        screenWidth = width /
            density
        screenHeight = height /
            density
    }

    fun toPx(dp: Int): Int {
        return (dp * density).toInt()
    }

    fun toPx(dp: Double): Int {
        return (dp * density).toInt()
    }

    fun toDp(px: Int): Int {
        return (px / density).toInt()
    }
}
