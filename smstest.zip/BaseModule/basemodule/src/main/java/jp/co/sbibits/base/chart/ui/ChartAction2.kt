package jp.co.sbibits.base.chart.ui

import Formatter
import jp.co.sbibits.base.chart.ios.StringEnum
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.chart.ui.model.item.MainChartItem
import jp.co.sbibits.base.chart.ui.model.item.SubChartItem
import jp.co.sbibits.base.chart.ui.utils.ChartUtil
import jp.co.sbibits.base.extension.append

/**
 * class for chart control
 * @property activity Activity
 * @property chartView ChartView
 * @property chartSource ChartSource
 * @property settingType SettingType
 * @property name chart name
 * @constructor
 */
abstract class ChartAction2<T : ChartSourceData>(
    val chartView: ChartView,
    val csd: T,
    //compare source data
    private val compareCsd: T?,
    val chartId: String,
    var name: String
) {

    open val chartSettingId = chartId

    /**
     * update main labels text
     */
    var onUpdateRecordSelectedLabelNames: ((
        openLabel: String,
        highLabel: String,
        lowLabel: String,
        closeLabel: String,
        headerVolumeLabel: String,
        headerTimeLabel: String
    ) -> Unit)? = null

    init {
        viewLoaded()
    }

    fun getCompareCsd():T? {
        compareCsd?.chartSource = chartView.setting.comparisonSource
        return compareCsd
    }

    /**
     * do refresh
     * @param data ChartData
     * @param fCurrentPrice Double  current Price
     */
    fun refresh(data: ChartData, fCurrentPrice: Double = 0.0) {
        this.chartView.currentPrice = fCurrentPrice
        updateBaseChart(data)
    }

    /**
     * initial base chart setting
     */
    open fun viewLoaded() {
        val chartSetting = ChartSetting(fileName = chartSettingId)
        chartView.setting = chartSetting
        chartView.onRecordSelected = this::onRecordSelected
        chartView.customLineHandler.drawingDataKey = this::chartDataId
        chartView.customLineHandler.onDrawingFinished = this::onDrawingFinished
        chartView.dataName = { name }
    }

    /**
     * select record action, update all the labels
     * @param selectedIndex Int?
     */
    open fun onRecordSelected(selectedIndex: Int?) {
        val data = chartView.chartData
        val index = selectedIndex ?: chartView.chartData?.lastIndex
        if (data == null || index == null) {
            return
        }

        var openLabel: String = Formatter.emptyMark
        var highLabel: String = Formatter.emptyMark
        var lowLabel: String = Formatter.emptyMark
        var closeLabel: String = Formatter.emptyMark
        val headerVolumeLabel: String
        val headerTimeLabel: String
        if (!chartView.setting.isComparisonEnabled) {
            openLabel = Formatter.number(
                data[ChartDataType.OPEN][index],
                decimalLength = chartView.decimalLength
            )
            highLabel = Formatter.number(
                data[ChartDataType.HIGH][index],
                decimalLength = chartView.decimalLength
            )
            lowLabel = Formatter.number(
                data[ChartDataType.LOW][index],
                decimalLength = chartView.decimalLength
            )
            closeLabel = Formatter.number(
                data[ChartDataType.CLOSE][index],
                decimalLength = chartView.decimalLength
            )
        }
        val volumeText =
            if (chartView.setting.isComparisonEnabled) Formatter.emptyMark else Formatter.number(
                data[ChartDataType.VOLUME][index]
            )
        var timeText =
            ChartUtil.detailedTimeString(data.axisValue(index), ashi = chartView.setting.ashiType)
        if (chartView.setting.isComparisonEnabled && selectedIndex == null) {
            timeText = Formatter.emptyMark
        }
        headerVolumeLabel = volumeText
        headerTimeLabel = timeText
        onUpdateRecordSelectedLabelNames?.invoke(
            openLabel,
            highLabel,
            lowLabel,
            closeLabel,
            headerVolumeLabel,
            headerTimeLabel
        )
    }

    /**
     * refresh chartView UI
     * @param data ChartData
     */
    private fun updateBaseChart(data: ChartData) {
        val addedCount = chartView.chartData?.update(data)
        chartView.setChartData(data, addedCount = addedCount)
    }

    /**
     * refresh chartView Comparison UI
     * @param data ChartData
     */
    private fun updateComparisonChart(data: ChartData) {
        chartView.comparisonData = data
    }

    fun clear() {
        clearData()
    }

    fun clearData() {
        chartView.clear()
    }

    /**
     * load  Ashi data & itemClick callback
     */
    fun loadAshiPullDownParams(loaded: (MutableList<String>, String, (String) -> Unit) -> Unit) {
        val ashiList = ChartAshiType.values().toList()
        val items = mutableListOf<String>()

        ashiList.forEach { ashiType ->
            items.append(contentsOf = ashiType.units.map { ashiType.text(unit = it) })
        }
        val current = chartView.setting.ashiType.text(unit = chartView.setting.ashiUnit)

        loaded.invoke(items, current) { value ->
            setAshiTypeUnit(ChartAshiType.lookup(text = value))
        }
    }

    /**
     * update chart by AshiTypeUnit
     * @param ashiTypeUnit ChartAshiTypeUnit
     */
    fun setAshiTypeUnit(ashiTypeUnit: ChartAshiTypeUnit?) {
        if (null == ashiTypeUnit) return
        chartView.setting.write {
            it.ashiType = ashiTypeUnit.ashiType
            it.ashiUnit = ashiTypeUnit.unit
        }
        // データをクリア
        clearData()
        loadChartData(csd) { chartData ->
            if (null != chartData) {
                updateBaseChart(chartData)
            }
        }
        val setting = chartView.setting
        if (setting.isComparisonEnabled) {
            compareCsd?.let {
                it.ashiTypeUnit =ashiTypeUnit
                val compare =
                    loadChartComparisonData(it) { chartData ->
                        if (null != chartData) {
                            updateComparisonChart(chartData)
                        }
                    }
            }

        }
    }

    /**
     * update volume Graph show status
     */
    fun updateVolumeGraph(enable: Boolean) {
        chartView.setting.write { it.isVolumePerPriceEnabled = enable }
        chartView.onSettingChanged()
    }

    /**
     * update volume Graph show status
     */
    fun updateTurningPointGraph(enable: Boolean) {
        chartView.setting.write { it.isTurningPointEnabled = enable }
        chartView.onSettingChanged()
    }

    /**
     * do updating
     * @param before MainChartItem? the state of main chart views before
     * @param after MainChartItem? the state of main chart views after
     * @param beforeSubCount the real subChart count that before the setting updated
     */
    fun onSettingChanged(
        setting: ChartSetting
    ) {
        val chartView = chartView
        val before =
            chartView.setting.mainTechnicals.firstOrNull { it == MainChartItem.COMPARISON }
        val after = setting.mainTechnicals.firstOrNull { it == MainChartItem.COMPARISON }
        val oldCompareSource = chartView.setting.comparisonSource
        val oldSubCount = chartView.setting.subTechnicalCount
        chartView.setting = setting
        //compare state changed to COMPARISON or compare target changed to another
        //or current comparisonData is null
        val needCompare = after == MainChartItem.COMPARISON
                && (null == before
                || setting.comparisonSource.id != oldCompareSource.id
                || null == chartView.comparisonData)

        var resetScroll = false
        val compareCsd = getCompareCsd()?:return
        if (needCompare) {
            // 比較チャート、通常チャートの切替時はスクロール位置をリセット just when the compareData need to reload
            resetScroll = (before == MainChartItem.COMPARISON || after == MainChartItem.COMPARISON)
            loadChartComparisonData(compareCsd) {
                it?.let { it1 -> updateComparisonChart(it1) }
            }

            // 価格帯別出来高OFF
            setting.isVolumePerPriceEnabled = false

            chartView.customLineHandler.enableDrawing = false

            // 転換点OFF
            setting.isTurningPointEnabled = false
        }

        setting.save()
        chartView.onSettingChanged(resetScroll = resetScroll)
        chartView.onTechnicalParamUpdated()

//        val beforeSubCount =
//            if (before == MainChartItem.COMPARISON) 0 else oldSubCount
//        val afterSubCount = if (after == MainChartItem.COMPARISON) 0 else setting.subTechnicalCount
//        chartView.resetHeight(afterSubCount, beforeSubCount)
    }

    fun onTechnicalSettingChanged(paramSet: ChartParamSet) {
        ChartParamSet.instance.overwrite(paramSet)
        ChartParamSet.instance.save()
        chartView.onTechnicalParamUpdated()
    }

    /**
     * チャートデータを一意に識別するコード
     * ex. stock_8411.TKY.minute15
     * ex. index_001.day1
     */
    fun chartDataId(): String {
        val chartSource = csd.chartSource
        return chartSource.dataId(chartView.setting.ashiTypeUnit)
    }

    open fun onDrawingFinished() {
    }

    abstract fun loadChartData(source: T, receiver: (ChartData?) -> Unit)

    abstract fun loadChartComparisonData(comparisonSource: T, receiver: (ChartData?) -> Unit)
}



