package jp.co.sbibits.base.db.config

enum class DBType {
    SQLite, Realm
}