package jp.co.sbibits.base.chart.ios

import android.graphics.Color

/**
 * 色を表す
 */
class UIColor {

    companion object {
        val white = UIColor(rgbValue = 0xFFFFFF)
        val black = UIColor(rgbValue = 0x000000)
        val red = UIColor(rgbValue = 0xFF0000)
        val green = UIColor(rgbValue = 0x00FF00)
        val blue = UIColor(rgbValue = 0x0000FF)
        val clear = UIColor(rgbValue = 0xFFFFFF, alpha = 0.0)
        val orange = UIColor(rgbValue = 0xFFA500)
        val gray = UIColor(rgbValue = 0x808080)
        val yellow = UIColor(rgbValue = 0xFFFF00)
        val cyan = UIColor(rgbValue = 0x00FFFF)
    }

    private var argbInt = 0xFFFFFFFF.toInt()

    val intValue: Int
        get() = argbInt

    constructor(argbInt: Int) {
        this.argbInt = argbInt
    }

    constructor(rgbValue: Int, alpha: Double = 1.0) {
        var iAlpha = to255(alpha)   // 0x 00 00 00 FF
        iAlpha = iAlpha shl (8 * 3) // 0x FF 00 00 00

        argbInt = iAlpha or rgbValue
    }

    constructor(rgbValue: Long, alpha: Double = 1.0) : this(rgbValue.toInt(), alpha)

    constructor(white: Double = 1.0, alpha: Double = 1.0) {
        val iWhite = to255(white)
        argbInt = Color.argb(to255(alpha), iWhite, iWhite, iWhite)
    }

    constructor(red: Double, green: Double, blue: Double, alpha: Double) {
        argbInt = Color.argb(to255(alpha), to255(red), to255(green), to255(blue))
    }

    private fun to255(d: Double): Int {
        return (d * 255.0).toInt()
    }

    override fun equals(other: Any?): Boolean {
        val rhs = (other as? UIColor) ?: return false
        return this.intValue == rhs.intValue
    }
}