package jp.co.sbibits.base.chart.fx.drawer

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.fx.model.PieChartData
import java.math.BigDecimal
import java.math.RoundingMode

class PieChartDrawer(var canvas: Canvas) {

    var r = Math.min(canvas.width, canvas.height)/2

    var center = CGPoint(canvas.width.toDouble()/2 , canvas.height.toDouble()/2)

    var defaultStartAngle = -90F

    fun draw(pieChartData: PieChartData) {
        val paint = Paint()

        var sum = 0.0
        pieChartData.dataList.forEach {
            sum += it.first
        }
        val rect = RectF((center.x - r).toFloat(), (center.y - r).toFloat(), (center.x + r).toFloat(), (center.y + r).toFloat())
        var lastAngle = defaultStartAngle
        pieChartData.dataList.forEach {
            val currentPercent = BigDecimal(it.first/sum).setScale(2, RoundingMode.HALF_UP)
            val sweepAngle = currentPercent.multiply(BigDecimal(360)).toFloat()
            paint.color = it.second
            canvas.drawArc(rect, lastAngle, sweepAngle, true, paint)
            lastAngle += sweepAngle
        }
    }

}