package jp.co.sbibits.base.db.realm

import io.realm.RealmModel
import jp.co.sbibits.base.db.entity.BaseEntity
import jp.co.sbibits.base.db.extension.getSQLColumn
import kotlin.reflect.KClass
import kotlin.reflect.KMutableProperty1
import kotlin.reflect.full.createInstance
import kotlin.reflect.jvm.isAccessible

/**
 * RealmEntity class
 * @param RE RealmModel class match this class
 */
abstract class RealmEntity<RE : RealmModel> : BaseEntity {

    /**
     * init this by the matched RealmModel
     */
    open fun initByRealmObject(source: RE) {
        val sourceProps = getRealmClass().getRealmColumns()
        val sourceMaps = hashMapOf<String, Any?>()
        sourceProps.forEach {
            it.isAccessible = true
            sourceMaps.put(it.name, it.getter.call(source))
        }
        val props = this::class.getSQLColumn()
        props.forEach {
            val currentPropName = it.name
            val prop = it as KMutableProperty1<RealmEntity<RE>, Any?>
            if (sourceMaps.containsKey(currentPropName)) {
                prop.set(this, sourceMaps[currentPropName])
            }
        }
    }

    /**
     * create the matched RealmModel by this
     */
    open fun generateRealmObject(): RE {
        val result = getRealmClass().createInstance()
        val sourceProps = this::class.getSQLColumn()
        val sourceMaps = hashMapOf<String, Any?>()
        sourceProps.forEach {
            it.isAccessible = true
            sourceMaps.put(it.name, it.getter.call(this))
        }


        val props = getRealmClass().getRealmColumns()
        props.forEach {
            val currentPropName = it.name
            val prop = it as KMutableProperty1<RE, Any?>
            if (sourceMaps.containsKey(currentPropName)) {
                prop.set(result, sourceMaps[currentPropName])
            }
        }
        return result
    }

    /**
     * get the RealmModel KClass
     */
    abstract fun getRealmClass(): KClass<RE>

}