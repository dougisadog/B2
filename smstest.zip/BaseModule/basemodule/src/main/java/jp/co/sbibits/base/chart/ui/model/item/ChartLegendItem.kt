package jp.co.sbibits.base.chart.ui.model.item

import jp.co.sbibits.base.chart.ios.UIColor

class ChartLegendItem {
    val text: String
    val color: UIColor

    constructor(text: String, color: UIColor) {
        this.text = text
        this.color = color
    }
}
