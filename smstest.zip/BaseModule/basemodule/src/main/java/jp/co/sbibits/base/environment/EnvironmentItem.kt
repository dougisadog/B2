package jp.co.sbibits.base.environment

class EnvironmentItem(label: String, name: String, items: LinkedHashMap<String, String>) {
    var settingLabel: String = label
    var settingName: String = name
    var settingItemKeys: MutableList<String> = mutableListOf()
    var settingItems: LinkedHashMap<String, String> = items

    init {
        items.forEach { (key, _) ->
            settingItemKeys.add(key)
        }
    }
}