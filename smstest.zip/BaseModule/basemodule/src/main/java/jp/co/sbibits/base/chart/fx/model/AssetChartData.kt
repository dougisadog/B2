package jp.co.sbibits.base.chart.fx.model

import java.util.ArrayList

class AssetChartData (var categoryName:String, var color:Int?, var dataArray:ArrayList<Double>)