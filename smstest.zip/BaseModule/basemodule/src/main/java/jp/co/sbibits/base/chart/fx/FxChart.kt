package jp.co.sbibits.base.chart.fx

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.View
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.CGContext
import jp.co.sbibits.base.chart.ios.CGRect
import jp.co.sbibits.base.chart.fx.drawer.FxChartDrawer
import jp.co.sbibits.base.chart.fx.model.FxChartData
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.extension.frame


abstract class FxChart : View {

    constructor(context: Context) : super(context) {
        setup()
    }
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        setup()
    }
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        setup()
    }

    fun setup() {

    }


    fun resize() {

        val chartWidth = frame.size.width - config.leftMargin - config.rightMargin
        val chartHeight = frame.size.height - config.topMargin - config.bottomMargin
        fullGraphArea = CGRect(x = config.leftMargin + config.yScaleAreaWidth, y = config.topMargin, width = chartWidth, height = chartHeight)
        if (config.isScaleAreaEnabled) {
            fullGraphArea.width -= config.yScaleAreaWidth
        }
        if (config.isTimeAreaEnabled) {
            fullGraphArea.height -= config.xScaleAreaHeight
        }
        mainGraphArea = fullGraphArea.copy()
        calcIndexRange()
    }

    // チャートコンフィグ
    var config = FxChartConfig()

    var state = FxChartState()


    var allDrawers: MutableList<FxChartDrawer> = mutableListOf()

    var mainAreaRect = CGRect.zero


    var chartData:FxChartData = FxChartData()
        set(value) {
            field = value
            allDrawers.forEach {
                it.chartData = value
            }
        }
    // 未来に拡張するレコード数
    var extendCount = 0
    // スクロール位置
    var scrollOffset = 0.0


    // メインチャート価格幅
    var mainRange = ValueRange()
    // 描画オブジェクト（全て）

    var fullGraphArea: CGRect = CGRect.zero
    var mainGraphArea: CGRect = CGRect.zero

    var decimalLength = 1
        set(value) {
            field = value
            allDrawers.forEach { it.decimalLength = decimalLength }
        }

    val chartFullWidth: CGFloat
        get() {
            return state.recordInterval * (recordCount + extendCount)
        }

    val chartWidth: CGFloat
        get() {
            var width = frame.size.width
            if (this.config.isScaleAreaEnabled) {
                width -= this.config.yScaleAreaWidth
            }
            width -= this.config.rightMargin
            if (width <= 0) {
                width = 0.0
            }
            return width
        }

    init {
        // レコード間隔
        state.recordInterval = config.defaultRecordInterval
    }

    fun setAxisData(dataKey:String, valueList:List<Double>) {
        this.setData(dataKey, valueList, true)
    }

    fun setData(dataKey:String, valueList:List<Double>, axis:Boolean = false) {
        if (axis) {
            chartData.axisDataKey = dataKey
            chartData.recordTable[dataKey] = valueList
        } else {
            chartData.recordTable[dataKey] = valueList
        }
    }

    fun fixRecordCount(pointCount:Int) {
        val intervalNum = pointCount - 1 // 区間の数は点の数より一つ少ない

        var interval = chartWidth
        if (0 < intervalNum) {
            interval = chartWidth / intervalNum
        }
        config.defaultRecordInterval = interval
        config.scrollMargin = -interval/2
        state.recordInterval = interval
        scrollOffset = 0.0
    }

    fun calcIndexRange() {
        val offset = chartFullWidth - scrollOffset - mainAreaRect.width
        val lastIndex = recordCount - 1 + extendCount
        val scrollIndex = offset / state.recordInterval
        val backIndex = (chartWidth + offset) / state.recordInterval
        state.startX = -(Math.ceil(backIndex) - backIndex) * state.recordInterval
        state.startIndex = Math.floor(lastIndex - backIndex + 1).toInt()
        state.endIndex = Math.ceil(lastIndex - scrollIndex).toInt()
    }

    val recordCount: Int
        get() {
            return chartData.recordTable.size
        }


    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        if (null == canvas) return

        val rect = CGRect(0.0, 0.0, width.toDouble(), height.toDouble())
        val context = CGContext(canvas)
        context.setFill(config.backgroundColor)
        context.fill(rect)

        context.setFill(config.graphAreaBackgroundColor)
        context.fill(fullGraphArea)

        val fullHeight = rect.height

        // 描画エリアを決める
        // 横幅の決定
        val mainWidth = chartWidth

        mainAreaRect = CGRect(config.yScaleAreaWidth, config.topMargin, mainWidth, fullHeight - config.topMargin)
        if (this.config.isTimeAreaEnabled) {
            this.mainAreaRect.size.height -= this.config.xScaleAreaHeight
            context.setFill(config.graphAreaBackgroundColor)
            context.fill(mainAreaRect)
        }



        val range = ValueRange()
        if (allDrawers.size > 0) {
            val defaultDrawer = allDrawers[0]
            defaultDrawer.updateRange(range)
        }

        resize()
//        calcIndexRange()

        allDrawers.forEach {
            it.config = config
            it.context = context
            it.range = range
            it.rect = mainGraphArea
            it.chartData = chartData
            it.state = state
            it.draw()
        }
    }

    fun setNeedsDisplay() {
        invalidate()
    }
}