package jp.co.sbibits.base.chart.neo.drawer

import Formatter
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.*
import jp.co.sbibits.base.chart.neo.NeoChartConfig
import jp.co.sbibits.base.chart.neo.NeoChartState
import jp.co.sbibits.base.chart.neo.NeoCoordinateService
import jp.co.sbibits.base.chart.neo.model.DragData
import jp.co.sbibits.base.chart.neo.model.NeoData
import jp.co.sbibits.base.chart.ui.model.ChartAshiType
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil
import jp.co.sbibits.base.chart.ui.utils.ChartUtil
import jp.co.sbibits.base.extension.append
import jp.co.sbibits.base.extension.removeAll
import jp.co.sbibits.base.extension.safeGet
import jp.co.sbibits.base.extension.size
import java.math.BigDecimal


abstract class NeoChartDrawer {

    var selectedRecordIndex: Int? = null

    // チャートコンフィグ
    var config = NeoChartConfig()

    var state = NeoChartState()

    open var chartData: NeoData = NeoData()

    lateinit var context: CGContext
    lateinit var coordinate: NeoCoordinateService

    lateinit var range: ValueRange

    lateinit var rect: CGRect
    lateinit var fullGraphArea: CGRect

    var needsCalculation = true
    var decimalLength = 0

    open fun calculate() {}

    open fun updateRange(range: ValueRange) {}

    open fun draw() {}

    abstract fun updateAnimateData(size: Int)

    abstract fun linesData():ArrayList<DragData>

    abstract fun valueFormat(value:Double):String


    var axisNameArray = listOf<String>()
    var axisIndexFilter = listOf<Int>()


    fun setAxisArray(axisNameArray: List<String>, axisIndexFilter: List<Int>) {
        this.axisNameArray = axisNameArray
        this.axisIndexFilter = axisIndexFilter
    }

    fun drawLineChart(dataList: ValueArray, color: UIColor) {
        val valueToHeight = rect.height / range.width
        context.saveGState()
        context.setShouldAntialias(true)
        context.clip(to = rect)
        context.setLineWidth(config.lineChartWidth)
        context.setStroke(color)
        context.beginPath()
        var x = state.startX + state.recordInterval / 2.0
        val points: MutableList<CGPoint> = mutableListOf()
        for (i in state.startIndex..Math.min(dataList.size - 1, state.endIndex + 1) ) {
            val value = dataList[i]
            if (value != null && !value.isNaN()) {
                val y = rect.maxY - (value - range.min) * valueToHeight
                points += listOf(CGPoint(x = x, y = y))
            } else if (0 < points.size) {
                context.addLines(between = points)
                points.removeAll()
            }
            x += state.recordInterval
        }
        if (2 <= points.size) {
            context.addLines(between = points)
        }
        context.strokePath()
        context.restoreGState()
    }


    fun drawXScales(timeList: List<String>?, axisIndexes: List<Int> = listOf(), adjustBottom: Boolean = false) {
        if (null == timeList) return
        context.saveGState()
        context.setShouldAntialias(true)
        context.setLineWidth(config.gridLineWidth)
        context.beginPath()
        var preDate: String? = timeList.safeGet(state.startIndex - 1)
        val indexList = (state.startIndex..state.endIndex).map { index ->
            var result: Int? = null
            var time: String? = null
            if (0 <= index && index < timeList.size) {
                time = timeList[index]
            }
            if (time != null && ChartUtil.isEnableAxis(ashiType = ChartAshiType.day, date = time, preDate = preDate)) {
                result = index
            }
            preDate = time
            return@map result
        }.filterNotNull()

        val baseX = state.startX + state.recordInterval / 2
        var preIndex: Int? = null
        indexList.reversed().forEach { index ->
            val x = baseX + (index - state.startIndex) * state.recordInterval

            if (x <= rect.maxX) {
                val points = listOf(CGPoint(x = x, y = rect.minY), CGPoint(x = x, y = rect.maxY))
//                context.addLines(between = points)
                var time: String? = null
                if (0 <= index && index < timeList.size) {
                    time = timeList[index]
                }
                val timeText = ChartUtil.timeToString(time, ashi = ChartAshiType.day)
                val textSize = timeText.size(config.xScaleFont)
                if (preIndex == null || textSize.width < (rect.width / (axisIndexes.size + 1))) {
                    val fontX = x - textSize.width / 2.0
                    var fontY = rect.maxY + (config.xScaleAreaHeight - textSize.height) / 2
                    if (adjustBottom) {
                        fontY = rect.maxY + textSize.height / 2
                    }
                    if (axisIndexes.indexOf(index) != -1) {
                        context.drawText(
                            timeText,
                            CGPoint(x = fontX, y = fontY),
                            font = config.xScaleFont,
                            color = config.scaleFontColor
                        )
                    }
                    preIndex = index
                }
            }
        }
        context.setStroke(config.gridColor)
        context.strokePath()
        context.restoreGState()
    }

    open fun drawYScales(minLineNumber: Int, adjustTopFont: Boolean = false, adjustBottomFont: Boolean = false): Int {
        if (!range.isValid) return 0

        context.saveGState()
        context.setShouldAntialias(true)
        context.setLineWidth(config.gridLineWidth)

        // 目盛間隔を計算
        val interval = ChartMathUtil.calcScaleInterval(range = range, minLineNumber = minLineNumber)
        // 一番下のライン位置を計算
        val minRemainder = BigDecimal.valueOf(range.min).remainder(BigDecimal.valueOf(interval))
        var gridMin = BigDecimal(range.min) - minRemainder
        if (BigDecimal.ZERO < minRemainder) {
            gridMin += BigDecimal.valueOf(interval)
        }

        val decimalLength = ChartMathUtil.scaleDecimalLength(interval = interval)
        val valToHeight = rect.height / range.width

        context.setFill(config.scaleFontColor)
        context.beginPath()

        var max = gridMin.toDouble()
        while (max <= range.max) {
            max += interval
        }
        val maxText = Formatter.number(max, decimalLength = decimalLength)
        var font = config.yScaleFont
        var width = maxText.size(font).width
        while (config.yScaleAreaWidth - config.yScaleFontPadding < width) {
            font = font.withSize(font.size - 1.0)
            width = maxText.size(font).width
            if (font.size <= 5) {
                break
            }
        }

        val points: MutableList<CGPoint> = mutableListOf()
        var value = gridMin.toDouble()
        var isBottom = true
        while (value <= range.max) {
            val isTop = (range.max < value + interval)
            val y = rect.maxY - (value - range.min) * valToHeight
            points.append(CGPoint(x = rect.minX, y = y))
            points.append(CGPoint(x = rect.maxX, y = y))
            context.addLines(between = points)

            if (rect.minY <= y && y <= rect.maxY) {
                val text = valueFormat(value)
                val fontSize = text.size(font)
                val fontY: CGFloat
                if (isTop && adjustTopFont) {
                    fontY = y
                } else if (isBottom && adjustBottomFont) {
                    fontY = y - fontSize.height
                } else {
                    fontY = y - fontSize.height / 2
                }

                context.drawText(
                    text = text,
                    point = CGPoint(x = rect.maxX + config.yScaleFontPadding , y = fontY),
                    font = font,
                    color = config.scaleFontColor
                )
            }
            points.removeAll()
            value += interval
            isBottom = false
        }

        context.setStroke(config.gridColor)
        context.strokePath()
        context.restoreGState()
        return decimalLength
    }

    /**
     * @brief 枠を描画する
     */
    fun drawFrame() {

        context.saveGState()
        context.setLineWidth(config.lineWidth)
        context.setShouldAntialias(false)
        context.beginPath()
        context.setStroke(config.frameBorderColor)
        val points: MutableList<CGPoint> = mutableListOf()
        points.append(CGPoint(x = rect.minX, y = rect.minY))
        points.append(CGPoint(x = rect.maxX, y = rect.minY))
        points.append(CGPoint(x = rect.maxX, y = rect.maxY))
        points.append(CGPoint(x = rect.minX, y = rect.maxY))
        context.addLines(between = points)
        context.strokePath()
        context.restoreGState()
    }

    fun drawSelectedTimeLine(index: Int?, dragging: Boolean, timeList: List<String?>) {
        drawTimeLine(originIndex = index, color = config.indicatorLineColor, dragging = dragging, timeList = timeList)
    }

    fun drawTimeLine(originIndex: Int?, color: UIColor, dragging: Boolean = false, timeList: List<String?>, adjustBottom: Boolean = true) {
        var index = originIndex
        if (index == null) {
            return
        }
        if (index < state.startIndex) {
            index = state.startIndex
        }
        if (state.endIndex < index) {
            index = state.endIndex
        }
        val x = coordinate.xPosition(index = index) ?: return

        if (x < rect.minX || rect.maxX < x) {
            return
        }
        context.beginPath()
        context.move(to = CGPoint(x = x, y = rect.minY))
        context.addLine(to = CGPoint(x = x, y = rect.maxY))
        context.setStroke(color)
        context.strokePath()
        var timeString: String? = null
        if (0 <= index && index < timeList.size) {
            timeString = timeList[index]
        }
        if (timeString != null) {
            val timeText = timeString
            val font = config.xScaleFont
            val textSize = timeText.size(font)

            //cloud start
            context.saveGState()

            val padding = if (adjustBottom) textSize.height/2 else config.dragBottomCloudHeightPadding
            val cloudHeight = textSize.height + padding * 2
            val cloudWidth = textSize.width + config.dragBottomCloudWidthPadding * 2
            val startPoint = CGPoint(x - cloudWidth/2, rect.maxY)
            val curveOffset = Math.min(cloudHeight, cloudWidth) * 0.3

            val fukiR = (cloudWidth/config.fukiPercent) /2
            val cloudPoint = CGPoint(x, rect.maxY - fukiR)
            if (x < rect.minX + cloudWidth/2) {
                startPoint.x = 0.0
            }
            else if (x > rect.maxX - cloudWidth/2) {
                startPoint.x = rect.maxX - cloudWidth
            }
            drawCloud(startPoint, cloudWidth,cloudHeight,curveOffset, cloudPoint)

            //cloud end
            context.drawText(timeText, point = CGPoint(x = startPoint.x + config.dragBottomCloudWidthPadding, y = startPoint.y + padding), font = font, color = config.scaleFontColor)

            if (dragging) {
//                val dragTimeText = timeString
//                val dragFont = config.draggingNumberFont
//                val dragTextSize = dragTimeText.size(dragFont)
//                context.drawText(dragTimeText, point = CGPoint(x = x - (dragTextSize.width / 2), y = rect.maxY / 2), font = dragFont, color = config.scaleFontColor)
                drawDragArea(selectIndex = index)
            }
        }
        context.restoreGState()
    }

    //cloud dot and text
    fun drawDragArea(selectIndex:Int) {
        //the max length range of all dragDatas ,we can check the cloud direction with its max value
        val maxLength = ValueRange()
        val datas = linesData()
        val x = coordinate.xPosition(index = selectIndex) ?: return

        //init dragData information
        datas.forEach {
            val yValue = it.data[selectIndex]
            if (null != yValue) {
                val y = coordinate.yPosition(yValue) ?: return@forEach
                it.position = CGPoint(x, y)
                it.value = yValue
                val dragFont = config.draggingNumberFont
                val dragText =  it.label + valueFormat(yValue)
                val dragTextSize = dragText.size(dragFont)

                it.height = dragTextSize.height + config.dragCloudPadding * 2
                val r = dragTextSize.height/2
                it.r = r
                it.width = r * 2 + config.dragCloudPadding + dragTextSize.width + config.dragCloudPadding * 2
                maxLength.update(it.width + config.dragFontMargin)

            }
        }
        //sort by position.y
        datas.sort()
        //the cloud direction
        var directionRight = true
        if (maxLength.max + x > rect.maxX) {
            directionRight = false
        }

        val combineListDatas = arrayListOf<ArrayList<DragData>>() //points that combined
        val independentDatas = arrayListOf<DragData>()//points that not combined
        val cacheDatas = arrayListOf<DragData>() //cache which can be moved to combineListDatas or independentDatas
        datas.forEachIndexed { index, dragData ->
            if (cacheDatas.size == 0) {
                cacheDatas.add(dragData)
            }
            else {
                var totalY = 0.0
                var totalHeight = 0.0
                cacheDatas.forEach {
                    totalY += it.position.y
                    totalHeight += it.height
                }
                val centerY = totalY/cacheDatas.size //calculate the center y position
                if (centerY + totalHeight/2 > dragData.position.y - dragData.height/2) {
                    //combine
                    cacheDatas.add(dragData)
                }
                else if (cacheDatas.size == 1){
                    //cacheDatas was confirmed to be independent data
                    independentDatas.add(cacheDatas[0])
                    cacheDatas.add(dragData)
                }
                else {
                    //cacheDatas was combine datas and refresh to get the current dragData
                    val combines = arrayListOf<DragData>().apply { addAll(cacheDatas) }
                    combineListDatas.add(combines)
                    cacheDatas.clear()
                    cacheDatas.add(dragData)
                }
            }
        }
        //find out which type the left cacheDatas is
        if (cacheDatas.size == 1){
            independentDatas.add(cacheDatas[0])
        }
        else {
            val combines = arrayListOf<DragData>().apply { addAll(cacheDatas) }
            combineListDatas.add(combines)
            cacheDatas.clear()
        }
        //draw independentDatas
        independentDatas.forEach {
            var iX = it.position.x + config.dragFontMargin
            if (!directionRight) {
                iX = it.position.x - config.dragFontMargin
            }
            it.cloudConnectPosition = CGPoint(iX, it.position.y)
            drawDragMiddleDot(it)
            drawDragCloud(it, directionRight)
        }
        combineListDatas.forEach {
            val combineList = it
            var totalY = 0.0
            var totalHeight = 0.0
            combineList.forEach { dragData ->
                totalHeight += dragData.height
                totalY += dragData.position.y
            }
            val startY = totalY/combineList.size - totalHeight/2 //the first cloud's start y position of this combine datas
            val averageHeight = totalHeight/combineList.size
            combineList.forEachIndexed { index, dragData ->
                var iX = dragData.position.x + config.dragFontMargin
                if (!directionRight) {
                    iX = dragData.position.x - config.dragFontMargin
                }
                dragData.cloudConnectPosition = CGPoint(iX, startY + averageHeight/2 + index * averageHeight)
                drawDragMiddleDot(dragData)
                drawDragCloud(dragData, directionRight)
            }

        }
    }

    /**
     * draw drag cloud
     */
    private fun drawDragCloud(it:DragData, directionRight:Boolean, curveOffset:Double = Math.min(it.width, it.height) * 0.3) {

        /**
         * line its position to the cloud
         */
        context.saveGState()
        context.setLineWidth(config.lineChartWidth)
        context.setStroke(UIColor(rgbValue = it.color))
        context.beginPath()
        context.move(to = it.position)
        context.addLine(to = it.cloudConnectPosition)
        context.strokePath()
        context.restoreGState()


        var x = it.position.x + config.dragFontMargin
        if (!directionRight) {
            x = it.position.x - config.dragFontMargin - it.width
        }
        val cloudPosition = CGPoint(x, it.cloudConnectPosition.y - it.height/2)
         //draw drag outer cloud(just round rect)
        drawCloud(cloudPosition, it.width, it.height, curveOffset,null,
            UIColor(rgbValue = it.color),UIColor.white)

        //draw drag inner dot that start of the text
        drawDot(CGPoint(cloudPosition.x +  config.dragCloudPadding + it.r, cloudPosition.y + it.height/2), it.r, UIColor(rgbValue = it.color))
        //draw text
        context.beginPath()
        val dragFont = config.draggingNumberFont
        val dragText =  it.label + valueFormat(it.value)
        context.drawText(dragText, CGPoint(cloudPosition.x +  config.dragCloudPadding + it.r * 2 + config.dragCloudPadding, cloudPosition.y + config.dragCloudPadding), dragFont, UIColor.black)


    }

    /**
     * draw dot
     */
    fun drawDot(position:CGPoint, r:CGFloat, color:UIColor) {
        if (r == 0.0) return
        context.saveGState()
        context.clip(to = rect)
        context.beginPath()
        val colors = arrayListOf<UIColor>()
        colors.append(color)
        context.drawRadialGradient(colors, center = position, radius = r)
        context.restoreGState()
    }

    /**
     * draw drag dot which located in its position
     */
    private fun drawDragMiddleDot(it:DragData, outerAlpha:Double = 0.2) {
        if (it.r == 0.0) return
        context.saveGState()
        context.clip(to = rect)
        context.beginPath()
        val colors = arrayListOf<UIColor>()
        colors.append(UIColor(rgbValue = it.color, alpha = 1.0))
        colors.append(UIColor(rgbValue = it.color, alpha = outerAlpha))
        context.drawRadialGradient(colors, center = it.position, radius = it.r)
        context.restoreGState()
    }

    /** 吹き出し */ //only support up cloud __Λ__
    fun drawCloud(point:CGPoint, width:CGFloat, height:CGFloat, curveOffset:CGFloat,cloudPoint:CGPoint? = null,
                  lineColor: UIColor = config.cloudLineColor,
                  fillColor: UIColor = config.cloudBackgroundColor) {
        // 左辺上部の丸みの終わる部分から反時計回り
        context.beginPath()
        context.move(CGPoint(point.x, point.y + curveOffset))
        context.addLine(CGPoint(point.x, point.y + height - curveOffset))
        context.quadraticCurveTo(CGPoint(point.x, point.y + height), CGPoint(point.x + curveOffset, point.y + height))

        context.addLine(CGPoint(point.x + width - curveOffset, point.y + height))
        context.quadraticCurveTo(CGPoint(point.x+ width, point.y + height), CGPoint(point.x+ width, point.y + height - curveOffset))

        context.addLine(CGPoint(point.x + width , point.y + curveOffset))
        context.quadraticCurveTo(CGPoint(point.x+ width, point.y), CGPoint(point.x+ width- curveOffset, point.y))

        //吹き出しの矢 start
        if (null != cloudPoint) {
            val fukiR = (width/config.fukiPercent) /2

            val firstStepX: Double //form right to left the first x position which have the same Y
            val secondStepX: Double //form cloudPoint to left the second x position which have the same Y

            if (cloudPoint.x < curveOffset) {
                cloudPoint.x = curveOffset
            }
            if (cloudPoint.x > point.x + width - curveOffset) {
                cloudPoint.x = point.x + width - curveOffset
            }

            //cloud left  Λ____
            if (cloudPoint.x < fukiR) {
                firstStepX = cloudPoint.x + fukiR
                secondStepX = curveOffset
            }
            //cloud normal __Λ__
            else if (cloudPoint.x < point.x + width - fukiR) {
                firstStepX = cloudPoint.x + fukiR
                secondStepX = cloudPoint.x - fukiR
            }
            //cloud right  ____Λ
            else {
                firstStepX = point.x + width - curveOffset
                secondStepX = cloudPoint.x - fukiR
            }

            context.addLine(CGPoint(firstStepX, point.y))
            context.addLine(cloudPoint)
            context.addLine(CGPoint(secondStepX, point.y))
            //吹き出しの矢 end
        }

        context.addLine(CGPoint(point.x + curveOffset , point.y ))
        context.quadraticCurveTo(CGPoint(point.x, point.y), CGPoint(point.x, point.y+ curveOffset))


        context.setLineWidth(config.lineChartWidth)
        //line color
        context.setStroke(lineColor)
        context.strokePath()
        context.setFill(fillColor)
        context.fillPath()

    }



}