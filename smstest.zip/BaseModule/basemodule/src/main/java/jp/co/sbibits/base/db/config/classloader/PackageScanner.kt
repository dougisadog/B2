package jp.co.sbibits.base.db.config.classloader

import android.content.Context
import jp.co.sbibits.base.db.annotations.Entity
import jp.co.sbibits.base.db.entity.BaseEntity
import jp.co.sbibits.base.db.util.PackageUtil
import kotlin.reflect.KClass

class PackageScanner(
    val context: Context,
    val applicationId: String,
    val packageNameList: String
) : BaseEntityClassLoader {
    override fun <T : KClass<out BaseEntity>> load(): MutableList<T> {
        val classes = mutableListOf<T>()
        val targets = PackageUtil.scanAllClass(
            context,
            Entity::class.java,
            applicationId,
            packageNameList
        )
        targets?.forEach {
            (it.kotlin as? T)?.let {
                classes.add(it)
            }
        }
        return classes
    }
}