package jp.co.sbibits.base.chart.ui.drawer.custom_line

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.IntEnumDefault
import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.chart.ui.model.ChartPoint

class FibonacciRetracement: CustomLine() {

    enum class FibonacciState: IntEnumDefault {
        moveStartPoint,
        waitEndPoint,
        moveEndPoint,
        moveStartPointOnly,
        ;
    }

    var startValue: CGFloat = 0.0
    var endValue: CGFloat? = null
    var fibonacciState: FibonacciState?
        get() {
            val stateCode = stateCode
            if (stateCode != null) {
                return FibonacciState::class.value(rawValue = stateCode)
            }
            return null
        }
        set(value) {
            stateCode = value?.rawValue
        }

    override fun touchesBegan(point: ChartPoint) {
        if (isInitialState) {
            startValue = point.value
            fibonacciState = FibonacciState.moveStartPoint
        } else if (fibonacciState == FibonacciState.waitEndPoint) {
            endValue = point.value
            fibonacciState = FibonacciState.moveEndPoint
        }
    }

    override fun touchesMoved(point: ChartPoint) {
        super.touchesMoved(point)
        if (fibonacciState == FibonacciState.moveStartPoint
                || fibonacciState == FibonacciState.moveStartPointOnly) {
            startValue = point.value
        } else if (fibonacciState == FibonacciState.moveEndPoint) {
            endValue = point.value
        }
    }

    override fun touchesEnded(point: ChartPoint) {
        if (fibonacciState == FibonacciState.moveStartPoint) {
            fibonacciState = FibonacciState.waitEndPoint
        } else if (fibonacciState == FibonacciState.moveEndPoint
                || fibonacciState == FibonacciState.moveStartPointOnly) {
            fibonacciState = null
        }
    }

    override fun draw() {
        val color = if (isSelected) config.selectedCustomLineColor else config.customLineColor
        drawHorizontalLine(price = startValue, color = color, caption = "100.0%")
        val endValue = endValue
        if (endValue != null) {
            drawHorizontalLine(price = endValue, color = color, caption = "0.0%")
            val range = endValue - startValue
            val value2 = endValue - (range * 0.236)
            drawHorizontalLine(price = value2, color = color, caption = "23.6%")
            val value3 = endValue - (range * 0.382)
            drawHorizontalLine(price = value3, color = color, caption = "38.2%")
            val value4 = endValue - (range * 0.50)
            drawHorizontalLine(price = value4, color = color, caption = "50.0%")
            val value5 = endValue - (range * 0.618)
            drawHorizontalLine(price = value5, color = color, caption = "61.8%")
        }
    }

    override fun selectItem(point: ChartPoint) : Boolean {
        val touchPos = coordinate.location(chartPoint = point)
        val startY = coordinate.yPosition(price = startValue)
        if (touchPos == null || startY == null) {
            return false
        }
        if (Math.abs(touchPos.y - startY) < config.horizontalLineTouchRange) {
            fibonacciState = FibonacciState.moveStartPointOnly
                    return true
        }

        val endValue = endValue
        if (endValue != null) {
            val endY = coordinate.yPosition(price = endValue)
            if (endY != null) {
                if (Math.abs(touchPos.y - endY) < config.horizontalLineTouchRange) {
                    fibonacciState = FibonacciState.moveEndPoint
                    return true
                }
            }
        }
        return false
    }
    override val paramDictionary: MutableMap<String, String>
        get() {
            val endValue = endValue ?: return mutableMapOf()
            return mutableMapOf("startValue" to "${startValue}", "endValue" to "${endValue}")
        }

    override fun importParam(param: Map<String, String>) {
        startValue = param["startValue"]?.toDouble() ?: 0.0
        endValue = param["endValue"]?.toDouble()
    }


    override fun importHybridParam(param: Map<String, *>) {
        val startValue = param["startValue"] as? Double
        val endValue = param["endValue"] as? Double
        if (startValue != null && endValue != null) {
            this.startValue = startValue
            this.endValue = endValue
        }
    }

    override val isCompleted: Boolean
        get() {
            return endValue != null
        }
}
