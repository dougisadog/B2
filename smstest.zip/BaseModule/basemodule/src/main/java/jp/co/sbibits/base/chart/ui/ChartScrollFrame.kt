package jp.co.sbibits.base.chart.ui

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.RelativeLayout
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.UITouch
import jp.co.sbibits.base.util.DeviceUtils
import kotlin.math.absoluteValue


class ChartScrollFrame : FrameLayout, ChartScrollViewDelegate {

    private val mHandler = Handler()

    var chartView = ChartView(context)
    set(value) {
        field = value
        removeAllViews()
        chartScrollView.removeAllViews()
        scrollFrame.removeAllViews()
        afterConstruct()
    }

    val chartScrollView = ChartScrollView(context, chartView)

    // FrameLayoutの幅を伸ばすための支えのView
    private val horizontalSupportView = View(context)

    private var scrollFrame = FrameLayout(context)

    var isScrollEnabled: Boolean
        get() {
            return chartScrollView.isScrollEnabled
        }
        set(value) {
            chartScrollView.isScrollEnabled = value
            chartScrollView.isHorizontalScrollBarEnabled = value
        }

    constructor(context: Context) : super(context) { afterConstruct() }
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) { afterConstruct() }
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) { afterConstruct() }

    private fun afterConstruct() {

        chartView.scrollFrame = this
        chartScrollView.delegate = this

        // Add ScrollView
        addView(chartScrollView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        scrollFrame.addView(horizontalSupportView, FrameLayout.LayoutParams(DeviceUtils.getScreenShortLength(), 0))

        // Add ChartView
        val layoutParams = FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        scrollFrame.addView(chartView, layoutParams)

        chartScrollView.addView(scrollFrame, RelativeLayout.LayoutParams(WRAP_CONTENT, MATCH_PARENT))
    }

    override fun onSizeChanged(width: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(width, h, oldw, oldh)

        mHandler.post {
            chartView.layoutParams = FrameLayout.LayoutParams(width, MATCH_PARENT)
            updateContentsSize()
            chartView.initScrollPosition(resetTimeSelection = false)
        }
    }

    fun onParentTouchEvent(event: MotionEvent?): Boolean {
        if (null == event) return false

        val touches = (0 until event.pointerCount).map {
            UITouch(x = event.getX(it).toDouble(), y = event.getY(it).toDouble())
        }

        return false
    }

    fun updateContentsSize() {
        val width = Math.max(chartView.contentsWidth.toInt(), width)
        horizontalSupportView.layoutParams = FrameLayout.LayoutParams(width, 0)
        chartView.x = chartScrollView.scrollX.toFloat()
    }

    override fun scrollViewDidScroll(scrollView: ChartScrollView) {
        chartView.x = scrollView.scrollX.toFloat()
        chartView.updateDrawingRange()
    }

    fun initPosition() {
        chartView.x = 0.0f
    }

}

class ChartScrollView(context: Context, private val chartView: ChartView): HorizontalScrollView(context) {

    var isScrollEnabled: Boolean = true

    var delegate: ChartScrollViewDelegate? = null

    // AndroidのScrollViewはマイナスのスクロールができないため、マイナスのスクロールが発生した場合この変数で調整する
    var scrollMargin: CGFloat = 0.0

    init {
        isFillViewport = true
    }

    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean {
        // ChartViewには常にEventを伝播する
        return false
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        if (null == event) return false

        val touches = (0 until event.pointerCount).map {
            UITouch(x = event.getX(it).toDouble(), y = event.getY(it).toDouble())
        }

        when (event.action and MotionEvent.ACTION_MASK) {
            MotionEvent.ACTION_POINTER_DOWN -> {
                chartView.touchesBegan(touches, event)
            }
            MotionEvent.ACTION_MOVE -> {
                chartView.touchesMoved(touches, event)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (chartView.canSwipe()) {
                    chartView.changeSwipeability?.invoke(true)
                }
            }
        }

        if (isScrollEnabled) {
            return super.onTouchEvent(event)
        }

        return false
    }

    override fun canScrollHorizontally(direction: Int): Boolean {
        return isScrollEnabled
    }

    var contentOffsetX: CGFloat
        get() = scrollX.toDouble() - scrollMargin
        set(value) {
            scrollMargin = Math.min(0.0, value).absoluteValue
            val scrollOffset = Math.max(0.0, value)
            scrollX = scrollOffset.toInt()
        }

    override fun onScrollChanged(x: Int, y: Int, oldX: Int, oldY: Int) {
        super.onScrollChanged(x, y, oldX, oldY)
        scrollMargin = 0.0
        delegate?.scrollViewDidScroll(this)
    }
}

interface ChartScrollViewDelegate {
    fun scrollViewDidScroll(scrollView: ChartScrollView)
}