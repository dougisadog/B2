package jp.co.sbibits.base.chart.ios

import jp.co.sbibits.base.CGFloat

class UIFont(val name: String, val size: CGFloat) {

    fun withSize(size: Double): UIFont {
        return UIFont(name = name, size = size)
    }
}