package jp.co.sbibits.base.db.extension

import jp.co.sbibits.base.db.DBManger
import jp.co.sbibits.base.db.dao.BaseDao
import jp.co.sbibits.base.db.dao.DaoCache
import jp.co.sbibits.base.db.entity.BaseEntity
import kotlin.reflect.KClass

inline fun <reified T : BaseEntity> instanceDao(clazz: KClass<T>): BaseDao<T> {
    return DaoCache.get(DBManger.DB_TYPE, clazz)
}