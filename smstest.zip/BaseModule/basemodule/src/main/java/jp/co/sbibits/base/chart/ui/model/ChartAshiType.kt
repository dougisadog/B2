package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.extension.append
import jp.co.sbibits.base.extension.integerValue
import jp.co.sbibits.base.extension.lowercased
import jp.co.sbibits.base.chart.ios.StringEnumDefault
import jp.co.sbibits.base.chart.ios.value

class ChartAshiTypeUnit(var ashiType: ChartAshiType, var unit: Int) {

    val text: String
        get() = ashiType.text(unit = unit)

    // ex. minute15
    val id: String
        get() = ashiType.rawValue + unit

    override fun hashCode(): Int {
        return text.hashCode()
    }

    override fun equals(other: Any?): Boolean {
        val rhs = (other as? ChartAshiTypeUnit) ?: return false
        return (ashiType == rhs.ashiType && unit == rhs.unit)
    }

    companion object {

        fun createFromHybridKey(key: String) : ChartAshiTypeUnit? {
            val items = key.split("_")

            // ハイブリッド版は "minute" だが、ネイティブ版は "minutes" なのでsを取り除く
            val type = items.firstOrNull()?.lowercased()?.removeSuffix("s") ?: return null
            val unitString = if ((2 <= items.size)) items[1] else "1"

            val ashiType = ChartAshiType::class.value(rawValue = type) ?: return null
            return ChartAshiTypeUnit(ashiType = ashiType, unit = unitString.integerValue)
        }
    }
}

enum class ChartAshiType : StringEnumDefault {
    minute, day, week, month;

    val mtsCode: String
        get() {
            return when (this) {
                minute -> "1"
                day -> "2"
                week -> "3"
                month -> "4"
            }
        }

    companion object {
        @Suppress("NAME_SHADOWING")
        fun lookup(text: String?): ChartAshiTypeUnit? {
            val text = text ?: return null
            for (ashiType in values()) {
                for (unit in ashiType.units) {
                    if (text == ashiType.text(unit = unit)) {
                        return ChartAshiTypeUnit(ashiType = ashiType, unit = unit)
                    }
                }
            }
            return null
        }
    }

    val allItems: List<String>
        get() {
            val results: MutableList<String> = mutableListOf()
            values().forEach { ashiType ->
                results.append(contentsOf = ashiType.units.map { ashiType.text(unit = it) })
            }
            return results
        }
    val units: List<Int>
        get() {
            return when (this) {
                minute -> listOf(1, 5, 10, 15)
                day -> listOf(1)
                week -> listOf(1)
                month -> listOf(1)
            }
        }
    val displayName: String
        get() {
            return when (this) {
                minute -> "分足"
                day -> "日足"
                week -> "週足"
                month -> "月足"
            }
        }

    fun text(unit: Int): String {
        var prefix = ""
        if (this == minute) {
            prefix = unit.toString()
        }
        return prefix + displayName
    }
}
