package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.chart.ios.StringEnumDefault
import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.chart.ui.utils.Category
import java.io.Serializable

/**
 * チャートの取得対象（銘柄、指標、為替レートなど）
 */
data class ChartSource(var type: ChartSourceType,
                       var code: String,
                       var market: String? = null,
                       var isMinuteAshiEnabled:Boolean = true) : Serializable {

    val id: String
        get() {
            var suffix = ""
            val market = market
            if (market != null) {
                suffix = "." + market
            }
            return "${type.rawValue}_${code}${suffix}"
        }

    fun dataId(ashiTypeUnit: ChartAshiTypeUnit) : String {
        return "${id}.${ashiTypeUnit.id}"
    }
}

/**
 * チャートデータ取得タイプ
 */
enum class ChartSourceType: StringEnumDefault {
    STOCK,
    INDEX,
    FX;

    companion object {
        fun lookupForMarket(category: Category?) : ChartSourceType {
            if (category == Category.FX_RATE) {
                return FX
            } else {
                return INDEX
            }
        }


        fun create(rawValue: String?) : ChartSourceType? {
            if (rawValue != null) {
                return ChartSourceType::class.value(rawValue = rawValue)
            }
            return null
        }

    }
}
