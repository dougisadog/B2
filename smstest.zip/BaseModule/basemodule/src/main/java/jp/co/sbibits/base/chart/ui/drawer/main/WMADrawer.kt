package jp.co.sbibits.base.chart.ui.drawer.main

import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil

/**
 * 加重移動平均
 */
class WMADrawer : ChartDrawer() {

    private val wma1Color = UIColor(rgbValue = 0xe5e645)
    private val wma2Color = UIColor(rgbValue = 0xe66d45)
    private val wma3Color = UIColor(rgbValue = 0x17e693)


    override fun calculate() {
        val chartData = chartData ?: return
        val closeList = chartData[ChartDataType.CLOSE]

        if (technicalParam.wma1On) {
            val span = technicalParam.wma1Span
            val wmaList = ChartMathUtil.calcWMA(src = closeList, span = span)
            chartData[ChartDataType.WMA1] = wmaList
        }
        if (technicalParam.wma2On) {
            val span = technicalParam.wma2Span
            val wmaList = ChartMathUtil.calcWMA(src = closeList, span = span)
            chartData[ChartDataType.WMA2] = wmaList
        }
        if (technicalParam.wma3On) {
            val span = technicalParam.wma3Span
            val wmaList = ChartMathUtil.calcWMA(src = closeList, span = span)
            chartData[ChartDataType.WMA3] = wmaList
        }
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        val chartData = chartData ?: return
        val wma1On = technicalParam.wma1On
        val wma2On = technicalParam.wma2On
        val wma3On = technicalParam.wma3On
        for (i in state.indices) {
            if (wma1On) {
                range.update(chartData[ChartDataType.WMA1][i])
            }
            if (wma2On) {
                range.update(chartData[ChartDataType.WMA2][i])
            }
            if (wma3On) {
                range.update(chartData[ChartDataType.WMA3][i])
            }
        }
    }

    override fun draw() {
        if (technicalParam.wma1On) {
            drawLineChart(dataType = ChartDataType.WMA1, color = wma1Color)
        }
        if (technicalParam.wma2On) {
            drawLineChart(dataType = ChartDataType.WMA2, color = wma2Color)
        }
        if (technicalParam.wma3On) {
            drawLineChart(dataType = ChartDataType.WMA3, color = wma3Color)
        }
    }

    override fun addLegend() {
        if (technicalParam.wma1On) {
            addLegendValue(title = "短期", dataType = ChartDataType.WMA1, color = wma1Color)
        }
        if (technicalParam.wma2On) {
            addLegendValue(title = "中期", dataType = ChartDataType.WMA2, color = wma2Color)
        }
        if (technicalParam.wma3On) {
            addLegendValue(title = "長期", dataType = ChartDataType.WMA3, color = wma3Color)
        }
    }
}