package jp.co.sbibits.base.chart.ui.drawer.sub

import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.ChartDataType
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange

/**
 * 出来高
 */
class VolumeDrawer: ChartDrawer() {
    private val barColor = ChartBaseConfig.volunmeBarColor

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        val chartData = chartData ?: return
        val volumeList = chartData[ChartDataType.VOLUME]
        range.update(0.0)
        volumeList.forEach { range.update(it) }
        range.max *= 1.05
    }

    override fun draw() {
        val chartData = chartData ?: return
        val volumeList = chartData[ChartDataType.VOLUME]
        val zeroList = ValueArray(array = volumeList.indicies.map { _  ->
            0.0
        })
        drawBar(baseValues = zeroList, endValues = volumeList, color = barColor, widthScale = 0.6)
    }

    override fun addLegend() {
        addLegendValue(title = "出来高", dataType = ChartDataType.VOLUME, color = barColor, decimalLength = 0)
    }
}
