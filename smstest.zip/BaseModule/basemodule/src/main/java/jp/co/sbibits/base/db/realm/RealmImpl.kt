package jp.co.sbibits.base.db.realm

import io.realm.Realm
import io.realm.RealmModel
import jp.co.sbibits.base.db.DBManger
import jp.co.sbibits.base.db.dao.BaseDao
import jp.co.sbibits.base.db.extension.getPrimary
import jp.co.sbibits.base.db.extension.getSQLColumn
import jp.co.sbibits.base.db.tryBlock
import kotlin.reflect.KClass
import kotlin.reflect.full.createInstance
import kotlin.reflect.jvm.javaField

/**
 * Realm DAO impl
 * @param T RealmEntity class
 * @param RE RealmModel class match the T
 */
class RealmImpl<T : RealmEntity<RE>, RE : RealmModel>(
    private val clazz: KClass<T>,
    private val realmClazz: KClass<RE>
) : BaseDao<T> {
    override fun find(id: Any): T? {
        val mRealm = RealmManager.getInstance()
        val primaryP = tryBlock("find failed") {
            clazz.getPrimary()
        } ?: return null
        val helper = RealmTypeHelper<RE>(primaryP)
        val dbData = helper.equalTo(mRealm.where(realmClazz.java), id)?.findFirst() ?: return null
        val source = clazz.createInstance()
        source.initByRealmObject(dbData)
        return source
    }

    override fun save(entity: T): Boolean {
        return tryBlock("Realm save failed") {
            // the primary key can't be null when do saving
            entity.getPrimaryId() ?: throw RuntimeException("primary key can't be null")
            val mRealm = RealmManager.getInstance()
            mRealm.runTransaction {
                it.copyToRealmOrUpdate(entity.generateRealmObject())
                true
            }
            true
        } ?: false
    }

    override fun save(entities: Collection<T>) {
        val source = entities.map {
            it.generateRealmObject()
        }
        val mRealm = RealmManager.getInstance()
        tryBlock("Realm save failed") {
            mRealm.runTransaction {
                it.copyToRealmOrUpdate(source)
                true
            }
        }
    }

    override fun delete(id: Any): Boolean {
        val mRealm = RealmManager.getInstance()

        return tryBlock("Realm delete failed") {
            val primaryP = clazz.getPrimary()
            val helper = RealmTypeHelper<RE>(primaryP)
            val target = helper.equalTo(mRealm.where(realmClazz.java), id)?.findAll()
            mRealm.runTransaction {
                target?.deleteAllFromRealm()
                true
            }
            true
        } ?: false

    }

    override fun deleteAll() {
        val mRealm = RealmManager.getInstance()
        tryBlock("Realm delete all failed") {
            mRealm.runTransaction {
                it.delete(realmClazz.java)
                true
            }
        }
    }

    override fun query(entity: T?): MutableList<T> {
        val mRealm = RealmManager.getInstance()
        val results = mutableListOf<T>()
        val columns = clazz.getSQLColumn()
        return tryBlock("Realm Query failed") {
            val searchQuery = mRealm.where(realmClazz.java)
            if (null != entity) {
                columns.forEachIndexed { index, c ->
                    val field = c.javaField ?: return@forEachIndexed
                    field.isAccessible = true
                    val value = field.get(entity) ?: return@forEachIndexed

                    val helper = RealmTypeHelper<RE>(c)
                    helper.equalTo(searchQuery, value)
                }
            }
            results.addAll(searchQuery.findAll().map {
                val resultEntity = clazz.createInstance()
                resultEntity.initByRealmObject(it)
                resultEntity
            })
            results
        } ?: results
    }

    private fun Realm.runTransaction(block: (Realm) -> Boolean) {
        val blockTask = {
            if (!block.invoke(this)) {
                DBManger.log("Realm transaction failed by result")
            }
        }
        if (isInTransaction) {
            blockTask.invoke()
        } else {
            executeTransaction {
                blockTask.invoke()
            }
        }
    }

    override fun runTransaction(block: () -> Boolean) {
        val mRealm = RealmManager.getInstance()
        tryBlock("Realm transaction failed by exception") {
            mRealm.runTransaction {
                block.invoke()
            }
        }
    }

}