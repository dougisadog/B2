package jp.co.sbibits.base.chart.fx

class FxChartState {
    var startX = 0.0
    // 描画開始（左端）インデックス
    var startIndex = 0
    // 描画終了（右端）インデックス
    var endIndex = 0

    var recordInterval = 0.0
}