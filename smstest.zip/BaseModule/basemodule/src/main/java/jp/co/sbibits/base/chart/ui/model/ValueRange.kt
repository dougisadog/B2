package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.CGFloat


class ValueRange {
    var min: CGFloat = CGFloat.NaN
    var max: CGFloat = CGFloat.NaN
    val width: CGFloat
        get() {
            return max - min
        }
    val center: CGFloat
        get() {
            return (max + min) / 2
        }

    val isValid: Boolean
        get() = !min.isNaN() && !max.isNaN() && (min < max)

    fun clear() {
        min = CGFloat.NaN
        max = CGFloat.NaN
    }

    fun update(value: CGFloat?) {
        val d = value
        if (d != null) {
            if ((min.isNaN() || d < min)) {
                min = d
            }
            if ((max.isNaN() || max < d)) {
                max = d
            }
        }
    }

    fun update(valueRange: ValueRange?) {
        if (valueRange != null) {
            update(valueRange.min)
            update(valueRange.max)
        }
    }

    fun updateAll(array: ValueArray) {
        array.forEach { this.update(it) }
    }

    fun scale(rate: CGFloat) {
        val expand = width * (rate - 1) / 2
        max += expand
        min -= expand
    }

    fun limited(value: CGFloat) : CGFloat {
        var result = value
        result = Math.min(result, max)
        result = Math.max(result, min)
        return result
    }

    fun contains(value: CGFloat?): Boolean {
        if (null == value) return false
        return !(min > value || value > max)
    }

    fun copy() : ValueRange {
        val result = ValueRange()
        result.min = min
        result.max = max
        return result
    }
}
