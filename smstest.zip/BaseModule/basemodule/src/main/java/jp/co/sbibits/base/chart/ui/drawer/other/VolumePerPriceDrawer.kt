package jp.co.sbibits.base.chart.ui.drawer.other

import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.ChartDataType
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.extension.removeAll

class VolumePerPriceDrawer: ChartDrawer() {

    data class Item(
            var volume: CGFloat,
            var price: CGFloat
    ) {}
    val barNumber = ChartBaseConfig.volunmePerPriceBarAmount
    val barColor = ChartBaseConfig.volunmePerPriceBarColor
    val items: MutableList<Item> = mutableListOf()
    var priceRange = ValueRange()

    override fun calculate() {
        val chartData = chartData ?: return
        priceRange.clear()
        val closeList = chartData[ChartDataType.CLOSE]
        closeList.forEach { priceRange.update(it) }
        val interval = priceRange.width / barNumber
        items.removeAll()

        var price = priceRange.min
        (0 .. barNumber).forEach { i  ->
            val targetPrice = if(i == barNumber) priceRange.max else price // 浮動小数点誤差を考慮して末端のみ最高価格をいれる
            items += listOf(Item(volume = 0.0, price = targetPrice))
            price += interval
        }

        // 出来高の集計
        val volumeList = chartData[ChartDataType.VOLUME]

        for (i in closeList.indicies) {
            val volume = volumeList[i]
            val close = closeList[i]
            if (volume == null || close == null) {
                continue
            }

            for (j in 0 until barNumber) {
                val min = items[j].price
                val max = items[j + 1].price

                if (j == barNumber - 1) {
                    // 最上部範囲のみ上端も含める
                    if (min <= close && close <= max) {
                        items[j].volume += volume
                        break
                    }
                } else {
                    if (min <= close && close < max) {
                        items[j].volume += volume
                        break
                    }
                }
            }
        }
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        val chartData = chartData ?: return
        val highList = chartData[ChartDataType.HIGH]
        val lowList = chartData[ChartDataType.LOW]
        for (i in highList.indicies) {
            range.update(highList[i])
            range.update(lowList[i])
        }
    }

    override fun draw() {
        val valToHeight = rect.size.height / range.width
        val bottomY = rect.maxY - (priceRange.min - range.min) * valToHeight
        val topY = rect.maxY - (priceRange.max - range.min) * valToHeight
        var maxVolume: CGFloat = 0.0
        items.forEach { maxVolume = Math.max(maxVolume, it.volume) }
        val VOLUME_TO_HEIGHT = rect.size.width * 0.98 / maxVolume
        context.saveGState()
        context.setFill(barColor)
        context.beginPath()
        val intervalH = (bottomY - topY) / barNumber
        val barMargin = intervalH * 0.18
        var y = bottomY
        for (i in 0 until barNumber) {
            val barW = items[i].volume * VOLUME_TO_HEIGHT
            val bottom = y - barMargin
            val top = y - intervalH + barMargin
            context.move(to = CGPoint(x = rect.minX, y = top))
            context.addLine(to = CGPoint(x = rect.minX + barW, y = top))
            context.addLine(to = CGPoint(x = rect.minX + barW, y = bottom))
            context.addLine(to = CGPoint(x = rect.minX, y = bottom))
            context.closePath()
            y -= intervalH
        }
        context.fillPath()
        context.restoreGState()
    }
}
