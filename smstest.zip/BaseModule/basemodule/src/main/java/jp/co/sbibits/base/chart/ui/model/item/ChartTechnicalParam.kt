package jp.co.sbibits.base.chart.ui.model.item

import jp.co.sbibits.base.chart.ui.model.ChartAshiType
import jp.co.sbibits.base.util.LocalSetting
import kotlin.reflect.full.declaredMemberProperties

/**
 * テクニカル指標のパラメーター
 */
class ChartTechnicalParam : LocalSetting {
    var ashiType: ChartAshiType

    constructor(ashiType: ChartAshiType) : super(fileName = "ChartTechnicalParam_" + ashiType.rawValue) {
        this.ashiType = ashiType
        val cacheItems = this.copy().items
        // except ashiType  size -1
        //init extra fields
        val props = this::class.declaredMemberProperties
        if (props.size - 1 > items.size) {
            //set extra fields default value with toDefault
            MainChartItem.values().forEach { this.toDefault(type = it, ashi = ashiType) }
            SubChartItem.values().forEach { this.toDefault(type = it, ashi = ashiType) }
            //set the old fields with old round_corner which are overwrited by toDefault
            props.forEach {
                if (null != cacheItems[it.name]) {
                    items[it.name] = cacheItems[it.name]
                }
            }
        }
    }


    constructor(param: ChartTechnicalParam) : super(other = param) {
        this.ashiType = param.ashiType
    }

    fun copy(): ChartTechnicalParam =
        ChartTechnicalParam(this)

    // region -> SMA(移動平均線)

    var sma1Span: Int
        get() {
            return getInt("sma1Span")
        }
        set(value) {
            setInt("sma1Span", value = value)
        }
    var sma2Span: Int
        get() {
            return getInt("sma2Span")
        }
        set(value) {
            setInt("sma2Span", value = value)
        }
    var sma3Span: Int
        get() {
            return getInt("sma3Span")
        }
        set(value) {
            setInt("sma3Span", value = value)
        }
    var sma1On: Boolean
        get() {
            return getBool("sma1On")
        }
        set(value) {
            setBool("sma1On", value = value)
        }
    var sma2On: Boolean
        get() {
            return getBool("sma2On")
        }
        set(value) {
            setBool("sma2On", value = value)
        }
    var sma3On: Boolean
        get() {
            return getBool("sma3On")
        }
        set(value) {
            setBool("sma3On", value = value)
        }

    // endregion

    // region -> EMA(指数平滑移動平均線)

    var ema1Span: Int
        get() {
            return getInt("ema1Span")
        }
        set(value) {
            setInt("ema1Span", value = value)
        }
    var ema2Span: Int
        get() {
            return getInt("ema2Span")
        }
        set(value) {
            setInt("ema2Span", value = value)
        }
    var ema3Span: Int
        get() {
            return getInt("ema3Span")
        }
        set(value) {
            setInt("ema3Span", value = value)
        }
    var ema1On: Boolean
        get() {
            return getBool("ema1On")
        }
        set(value) {
            setBool("ema1On", value = value)
        }
    var ema2On: Boolean
        get() {
            return getBool("ema2On")
        }
        set(value) {
            setBool("ema2On", value = value)
        }
    var ema3On: Boolean
        get() {
            return getBool("ema3On")
        }
        set(value) {
            setBool("ema3On", value = value)
        }

    // endregion

    // region -> WMA(加重移動平均)

    var wma1Span: Int
        get() {
            return getInt("wma1Span")
        }
        set(value) {
            setInt("wma1Span", value = value)
        }
    var wma2Span: Int
        get() {
            return getInt("wma2Span")
        }
        set(value) {
            setInt("wma2Span", value = value)
        }
    var wma3Span: Int
        get() {
            return getInt("wma3Span")
        }
        set(value) {
            setInt("wma3Span", value = value)
        }
    var wma1On: Boolean
        get() {
            return getBool("wma1On")
        }
        set(value) {
            setBool("wma1On", value = value)
        }
    var wma2On: Boolean
        get() {
            return getBool("wma2On")
        }
        set(value) {
            setBool("wma2On", value = value)
        }
    var wma3On: Boolean
        get() {
            return getBool("wma3On")
        }
        set(value) {
            setBool("wma3On", value = value)
        }

    // endregion

    // region -> ボリンジャーバンド

    var bbSpan: Int
        get() {
            return getInt("bbSpan")
        }
        set(value) {
            setInt("bbSpan", value = value)
        }
    var bbSmaOn: Boolean
        get() {
            return getBool("bbSmaOn")
        }
        set(value) {
            setBool("bbSmaOn", value = value)
        }
    var bbSigma1On: Boolean
        get() {
            return getBool("bbSigma1On")
        }
        set(value) {
            setBool("bbSigma1On", value = value)
        }
    var bbSigma2On: Boolean
        get() {
            return getBool("bbSigma2On")
        }
        set(value) {
            setBool("bbSigma2On", value = value)
        }
    var bbSigma3On: Boolean
        get() {
            return getBool("bbSigma3On")
        }
        set(value) {
            setBool("bbSigma3On", value = value)
        }

    // endregion

    // region -> 一目均衡表

    var ichimokuTenkanSpan: Int
        get() {
            return getInt("ichimokuTenkanSpan")
        }
        set(value) {
            setInt("ichimokuTenkanSpan", value = value)
        }
    var ichimokuKijunSpan: Int
        get() {
            return getInt("ichimokuKijunSpan")
        }
        set(value) {
            setInt("ichimokuKijunSpan", value = value)
        }
    var ichimokuSpan: Int
        get() {
            return getInt("ichimokuSpan")
        }
        set(value) {
            setInt("ichimokuSpan", value = value)
        }
    var ichimokuTenkanOn: Boolean
        get() {
            return getBool("ichimokuTenkanOn")
        }
        set(value) {
            setBool("ichimokuTenkanOn", value = value)
        }
    var ichimokuKijunOn: Boolean
        get() {
            return getBool("ichimokuKijunOn")
        }
        set(value) {
            setBool("ichimokuKijunOn", value = value)
        }
    var ichimokuSenkoChikoOn: Boolean
        get() {
            return getBool("ichimokuSenkoChikoOn")
        }
        set(value) {
            setBool("ichimokuSenkoChikoOn", value = value)
        }

    // endregion

    // region -> エンベロープ

//    var envelopeSpan: Int
//        get() {
//            return getInt("envelopeSpan")
//        }
//        set(value) {
//            setInt("envelopeSpan", value = value)
//        }
//    var envelopeUpperRate: CGFloat
//        get() {
//            return getFloat("envelopeUpperRate")
//        }
//        set(value) {
//            setFloat("envelopeUpperRate", value = value)
//        }
//    var envelopLowerRate: CGFloat
//        get() {
//            return getFloat("envelopLowerRate")
//        }
//        set(value) {
//            setFloat("envelopLowerRate", value = value)
//        }
//    var envelopSpanOn: Boolean
//        get() {
//            return getBool("envelopSpanOn")
//        }
//        set(value) {
//            setBool("envelopSpanOn", value = value)
//        }

    // endregion

    // region -> パラボリックSAR

//    var parabolicAccelerationFactor: CGFloat
//        get() {
//            return getFloat("parabolicAccelerationFactor")
//        }
//        set(value) {
//            setFloat("parabolicAccelerationFactor", value = value)
//        }
//    var parabolicAccelerationFactorMax: CGFloat
//        get() {
//            return getFloat("parabolicAccelerationFactorMax")
//        }
//        set(value) {
//            setFloat("parabolicAccelerationFactorMax", value = value)
//        }
//
//    // endregion
//
//    // region -> 平均足
//
//    var averageBarSpan: Int
//        get() {
//            return getInt("averageBarSpan")
//        }
//        set(value) {
//            setInt("averageBarSpan", value = value)
//        }

    // endregion

    // region -> MACD

    var macdShortSpan: Int
        get() {
            return getInt("macdShortSpan")
        }
        set(value) {
            setInt("macdShortSpan", value = value)
        }
    var macdLongSpan: Int
        get() {
            return getInt("macdLongSpan")
        }
        set(value) {
            setInt("macdLongSpan", value = value)
        }
    var macdSignalSpan: Int
        get() {
            return getInt("macdSignalSpan")
        }
        set(value) {
            setInt("macdSignalSpan", value = value)
        }
    var macdSignalOn: Boolean
        get() {
            return getBool("macdSignalOn")
        }
        set(value) {
            setBool("macdSignalOn", value = value)
        }

    // endregion

    // region -> RSI

    var rsi1Span: Int
        get() {
            return getInt("rsi1Span")
        }
        set(value) {
            setInt("rsi1Span", value = value)
        }
    var rsi2Span: Int
        get() {
            return getInt("rsi2Span")
        }
        set(value) {
            setInt("rsi2Span", value = value)
        }
    var rsi3Span: Int
        get() {
            return getInt("rsi3Span")
        }
        set(value) {
            setInt("rsi3Span", value = value)
        }
    var rsi1On: Boolean
        get() {
            return getBool("rsi1On")
        }
        set(value) {
            setBool("rsi1On", value = value)
        }
    var rsi2On: Boolean
        get() {
            return getBool("rsi2On")
        }
        set(value) {
            setBool("rsi2On", value = value)
        }
    var rsi3On: Boolean
        get() {
            return getBool("rsi3On")
        }
        set(value) {
            setBool("rsi3On", value = value)
        }

    // endregion

    // region -> DMI/ADX

    var dmiAverageSpan: Int
        get() {
            return getInt("dmiAverageSpan")
        }
        set(value) {
            setInt("dmiAverageSpan", value = value)
        }
    var dmiAdxSpan: Int
        get() {
            return getInt("dmiAdxSpan")
        }
        set(value) {
            setInt("dmiAdxSpan", value = value)
        }
    var dmiAdxrSpan: Int
        get() {
            return getInt("dmiAdxrSpan")
        }
        set(value) {
            setInt("dmiAdxrSpan", value = value)
        }
    var dmiDiOn: Boolean
        get() {
            return getBool("dmiDiOn")
        }
        set(value) {
            setBool("dmiDiOn", value = value)
        }
    var dmiAdxOn: Boolean
        get() {
            return getBool("dmiAdxOn")
        }
        set(value) {
            setBool("dmiAdxOn", value = value)
        }
    var dmiAdxrOn: Boolean
        get() {
            return getBool("dmiAdxrOn")
        }
        set(value) {
            setBool("dmiAdxrOn", value = value)
        }

    // endregion

    // region -> ストキャスティクス

    var stochastKSpan: Int
        get() {
            return getInt("stochastKSpan")
        }
        set(value) {
            setInt("stochastKSpan", value = value)
        }
    var stochastDSpan: Int
        get() {
            return getInt("stochastDSpan")
        }
        set(value) {
            setInt("stochastDSpan", value = value)
        }
    var stochastSDSpan: Int
        get() {
            return getInt("stochastSDSpan")
        }
        set(value) {
            setInt("stochastSDSpan", value = value)
        }
    var stochastKOn: Boolean
        get() {
            return getBool("stochastKOn")
        }
        set(value) {
            setBool("stochastKOn", value = value)
        }
    var stochastDOn: Boolean
        get() {
            return getBool("stochastDOn")
        }
        set(value) {
            setBool("stochastDOn", value = value)
        }
    var stochastSDOn: Boolean
        get() {
            return getBool("stochastSDOn")
        }
        set(value) {
            setBool("stochastSDOn", value = value)
        }

    // endregion

    // region -> RCI

    var rci1Span: Int
        get() {
            return getInt("rci1Span")
        }
        set(value) {
            setInt("rci1Span", value = value)
        }
    var rci2Span: Int
        get() {
            return getInt("rci2Span")
        }
        set(value) {
            setInt("rci2Span", value = value)
        }
    var rci3Span: Int
        get() {
            return getInt("rci3Span")
        }
        set(value) {
            setInt("rci3Span", value = value)
        }
    var rci1On: Boolean
        get() {
            return getBool("rci1On")
        }
        set(value) {
            setBool("rci1On", value = value)
        }
    var rci2On: Boolean
        get() {
            return getBool("rci2On")
        }
        set(value) {
            setBool("rci2On", value = value)
        }
    var rci3On: Boolean
        get() {
            return getBool("rci3On")
        }
        set(value) {
            setBool("rci3On", value = value)
        }

    // endregion

    // region -> サイコロジカル

//    var psychoSpan: Int
//        get() {
//            return getInt("psychoSpan")
//        }
//        set(value) {
//            setInt("psychoSpan", value = value)
//        }


    fun toDefault(type: ChartItem, ashi: ChartAshiType) {

        // ON / OFF の設定
        when (type) {
            MainChartItem.WMA -> {
                wma1On = true
                wma2On = true
                wma3On = true
            }
            MainChartItem.EMA -> {
                ema1On = true
                ema2On = true
                ema3On = true
            }
            MainChartItem.SMA -> {
                sma1On = true
                sma2On = true
                sma3On = true
            }
            MainChartItem.BOLLINGER_BAND -> {
                bbSmaOn = true
                bbSigma1On = false
                bbSigma2On = true
                bbSigma3On = false
            }
            MainChartItem.ICHIMOKU -> {
                ichimokuKijunOn = true
                ichimokuTenkanOn = true
                ichimokuSenkoChikoOn = true
            }
            SubChartItem.MACD -> macdSignalOn = true
            SubChartItem.DMI_ADX -> {
                dmiDiOn = true
                dmiAdxOn = true
                dmiAdxrOn = false
            }
            SubChartItem.RSI -> {
                rsi1On = false
                rsi2On = true
                rsi3On = false
            }
            SubChartItem.RCI -> {
                rci1On = false
                rci2On = true
                rci3On = false
            }
            SubChartItem.STOCHASTICS -> {
                stochastKOn = true
                stochastDOn = true
                stochastSDOn = false
            }
            else -> return
        }
        when (type) {
            MainChartItem.SMA -> {
                when (ashi) {
                    ChartAshiType.minute -> {
                        sma1Span = 5
                        sma2Span = 25
                        sma3Span = 75
                    }
                    ChartAshiType.day -> {
                        sma1Span = 25
                        sma2Span = 50
                        sma3Span = 75
                    }
                    ChartAshiType.week -> {
                        sma1Span = 13
                        sma2Span = 26
                        sma3Span = 52
                    }
                    ChartAshiType.month -> {
                        sma1Span = 9
                        sma2Span = 24
                        sma3Span = 60
                    }
                }
                return
            }
            MainChartItem.EMA -> {
                when (ashi) {
                    ChartAshiType.minute -> {
                        ema1Span = 5
                        ema2Span = 25
                        ema3Span = 75
                    }
                    ChartAshiType.day -> {
                        ema1Span = 25
                        ema2Span = 50
                        ema3Span = 75
                    }
                    ChartAshiType.week -> {
                        ema1Span = 13
                        ema2Span = 26
                        ema3Span = 52
                    }
                    ChartAshiType.month -> {
                        ema1Span = 9
                        ema2Span = 24
                        ema3Span = 60
                    }
                }
                return
            }
            MainChartItem.WMA -> {
                when (ashi) {
                    ChartAshiType.minute -> {
                        wma1Span = 5
                        wma2Span = 25
                        wma3Span = 75
                    }
                    ChartAshiType.day -> {
                        wma1Span = 25
                        wma2Span = 50
                        wma3Span = 75
                    }
                    ChartAshiType.week -> {
                        wma1Span = 13
                        wma2Span = 26
                        wma3Span = 52
                    }
                    ChartAshiType.month -> {
                        wma1Span = 9
                        wma2Span = 24
                        wma3Span = 60
                    }
                }
                return
            }
            MainChartItem.BOLLINGER_BAND -> {
                bbSpan = when (ashi) {
                    ChartAshiType.minute -> 25
                    ChartAshiType.day -> 25
                    ChartAshiType.week -> 26
                    ChartAshiType.month -> 24
                }
                return
            }
            MainChartItem.ICHIMOKU -> {
                ichimokuTenkanSpan = 9
                ichimokuKijunSpan = 26
                ichimokuSpan = 26
            }
            SubChartItem.MACD -> {
                macdShortSpan = 12
                macdLongSpan = 26
                macdSignalSpan = 9
            }
            SubChartItem.STOCHASTICS -> {
                stochastKSpan = 5
                stochastDSpan = 3
                stochastSDSpan = 3
            }
            SubChartItem.RSI -> {
                rsi1Span = 9
                rsi2Span = 14
                rsi3Span = 22
            }
            SubChartItem.RCI -> {
                rci1Span = 5
                rci2Span = 9
                rci3Span = 13
            }
            SubChartItem.DMI_ADX -> {
                dmiAverageSpan = 14
                dmiAdxSpan = 9
                dmiAdxrSpan = 9
            }
            else -> return
        }
    }
}