package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.chart.ios.IntEnumDefault

enum class ChartDataType: IntEnumDefault {
    // 始値
    OPEN
    // 高値
    ,HIGH
    // 安値
    ,LOW
    // 終値
    ,CLOSE
    // 移動平均1
    ,SMA1
    // 移動平均2
    ,SMA2
    // 移動平均3
    ,SMA3
    // 指数平滑移動平均1
    ,EMA1
    // 指数平滑移動平均2
    ,EMA2
    // 指数平滑移動平均3
    ,EMA3
    // 加重移動平均1
    ,WMA1
    // 加重移動平均2
    ,WMA2
    // 加重移動平均3
    ,WMA3
    // エンベロープ 終値SMA
    ,ENVELOPE_CLOSE_SMA
    // エンベロープ 高値SMA
    ,ENVELOPE_HIGH_SMA
    // エンベロープ 低値SMA
    ,ENVELOPE_LOW_SMA
    // ボリンジャーバンド SMA
    ,BOLLINGER_BAND_SMA
    // ボリンジャーバンド +1σ
    ,BOLLINGER_BAND_PLUS1_SIGMA
    // ボリンジャーバンド +2σ
    ,BOLLINGER_BAND_PLUS2_SIGMA
    // ボリンジャーバンド +3σ
    ,BOLLINGER_BAND_PLUS3_SIGMA
    // ボリンジャーバンド -1σ
    ,BOLLINGER_BAND_MINUS1_SIGMA
    // ボリンジャーバンド -2σ
    ,BOLLINGER_BAND_MINUS2_SIGMA
    // ボリンジャーバンド -3σ
    ,BOLLINGER_BAND_MINUS3_SIGMA
    // 一目均衡表 転換線
    ,ICHIMOKU_TENKAN
    // 一目均衡表 基準線
    ,ICHIMOKU_KIJUN
    // 一目均衡表 遅行線
    ,ICHIMOKU_CHIKO
    // 一目均衡表 先行スパン1
    ,ICHIMOKU_SENKO1
    // 一目均衡表 先行スパン2
    ,ICHIMOKU_SENKO2
    // パラボリックSAR
    ,PARABOLIC_SAR
    // MACD
    ,MACD
    // MACD シグナル
    ,MACD_SIGNAL
    // MACD オシレーター
    ,MACD_OSC
    // RSI
    ,RSI1
    ,RSI2
    ,RSI3
    // RCI
    ,RCI1
    ,RCI2
    ,RCI3
    // DMI/ADX +DI
    ,DMI_PLUS_DI
    // DMI/ADX -DI
    ,DMI_MINUS_DI
    // DMI/ADX -DI
    ,DMI_ADX
    // DMI/ADX -DI
    ,DMI_ADXR
    // ストキャスティクス %K
    ,STOCHASTICS_K
    // ストキャスティクス %D
    ,STOCHASTICS_D
    // ストキャスティクス Slow%D
    ,STOCHASTICS_SLOW_D
    // ヒストリカル・ボラティリティ
    ,HISTORICAL_VOLATILITY
    // サイコロジカル
    ,PSYCHOLOGICAL
    // 出来高
    ,VOLUME
    // VWAP
    ,VWAP
    ;

}
