package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.chart.ui.model.item.ChartTechnicalParam

class ChartParamSet {

    companion object {
        private var sInstance: ChartParamSet = ChartParamSet()
        val instance: ChartParamSet
            get() = sInstance
    }

    private var params: MutableMap<ChartAshiType, ChartTechnicalParam> = mutableMapOf()

    private constructor() {
        ChartAshiType.values().forEach { ashiType  ->
            params[ashiType] = ChartTechnicalParam(ashiType)
        }
    }

    operator fun get(type: ChartAshiType): ChartTechnicalParam? {
        return params[type]
    }

    operator fun get(type: ChartAshiTypeUnit): ChartTechnicalParam? {
        return params[type.ashiType]
    }

    fun overwrite(other: ChartParamSet) {
        other.params.forEach { params[it.key]?.overwriteItems(other = it.value) }
    }
    val copy: ChartParamSet
        get() {
            val copy = ChartParamSet()
            params.forEach { copy.params[it.key] = it.value.copy() }
            return copy
        }

    fun save() {
        params.values.forEach { it.save() }
    }
}
