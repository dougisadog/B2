package jp.co.sbibits.base.db.realm

import io.realm.RealmModel
import jp.co.sbibits.base.db.dao.BaseDao
import kotlin.reflect.KClass

class RealmBaseDao<T : RealmEntity<RE>, RE : RealmModel>(
    clazz: KClass<T>,
    realmClazz: KClass<RE>
) : BaseDao<T> by RealmImpl<T, RE>(clazz, realmClazz)


