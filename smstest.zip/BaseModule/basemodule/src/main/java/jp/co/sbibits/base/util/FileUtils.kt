package jp.co.sbibits.base.util

import android.annotation.SuppressLint
import android.os.Environment
import android.text.TextUtils
import jp.co.sbibits.base.ContextManager
import jp.co.sbibits.base.extension.copyInputStreamToFile
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.*

/**
 * ファイル管理ツール
 */
object FileUtils {

    /**
     * ルートディレクトリを取得する
     */
    fun getRootDir(): String {
        val externalFilesDir = ContextManager.getContext()?.filesDir
        return externalFilesDir?.path!!
    }

    /**
     * フォルダを作成できます
     *
     * @param dirPath フォルダ名
     */
    fun mkDir(dirPath: String) {
        val dirArray = dirPath.split("/".toRegex())
        var pathTemp = ""
        for (i in 1 until dirArray.size) {
            pathTemp = "$pathTemp/${dirArray[i]}"
            val newF = File("${dirArray[0]}$pathTemp")
            if (!newF.exists()) {
                val cheatDir: Boolean = newF.mkdir()
                println(cheatDir)
            }
        }
    }

    /**
     * ファイルを作成する
     *
     * @param dirPath フォルダ名
     * @param fileName ファイル名
     */
    fun createFile(dirPath: String = getRootDir(), fileName: String) {
        val file = File("$dirPath/$fileName")
        createFile(file)
    }

    /**
     * ファイルを作成する
     *
     * @param file ファイル
     */
    fun createFile(file: File) {
        if (!file.exists()) {
            val type = file.createNewFile()
            LogUtils.d("FileUtils","CreateFile::$type  path::$file")
        }
    }

    /**
     * ファイルを削除する
     *
     * @param dirPath フォルダ名
     * @param fileName ファイル名
     */
    fun deleteFile(dirPath: String = getRootDir(), fileName: String): Boolean {
        val file = File("$dirPath/$fileName")
        return deleteFile(file)
    }

    /**
     * ファイルを削除する
     *
     * @param file ファイル
     */
    fun deleteFile(file: File): Boolean {
        if (file.checkFile()) {
            return false
        }
        return file.delete()
    }

    /**
     * フォルダを削除する
     *
     * @param dirPath フォルダ名
     */
    fun deleteDir(dirPath: String) {
        val dir = File(dirPath)
        deleteDirWithFile(dir)
    }

    /**
     * フォルダを削除する
     *
     * @param dir フォルダ
     */
    fun deleteDirWithFile(dir: File?) {
        if (dir!!.checkFile())
            return
        for (file in dir.listFiles()) {
            if (file.isFile)
                file.delete()
            else if (file.isDirectory)
                deleteDirWithFile(file)
        }
        dir.delete()
    }

    private fun File.checkFile(): Boolean {
        return !this.exists() || this.isDirectory
    }

    /**
     * ファイルを読み取り
     *
     * @param file ファイル
     * @return ファイルの内容（テキスト）
     */
    fun readFile(file: File): String? {
        return if (!file.isFile) {
            null
        } else {
            file.readText()
        }
    }

    /**
     * ファイルを読み取り
     *
     * @param file ファイル
     * @return ファイルの内容（テキスト）
     */
    fun readFileByText(file: File): String? {
        return if (!file.isFile) {
            null
        } else {
            file.readText()
        }
    }

    /**
     * ファイルを読み取り
     *
     * @param file ファイル
     * @return ファイルの内容（バイト）
     */
    fun readFileByBytes(file: File): ByteArray? {
        return if (!file.isFile) {
            null
        } else {
            file.readBytes()
        }
    }

    /**
     * ファイルに文字列を書き込む
     *
     * @param file ファイル
     * @param content データ（文字列）
     */
    fun writeText(file: File, content: String) {
        createFile(file)
        file.writeText(content)
    }

    /**
     * ファイルにバイトを書き込む
     *
     * @param file ファイル
     * @param content データ（バイト）
     */
    fun writeBytes(file: File, content: ByteArray) {
        createFile(file)
        file.appendBytes(content)
    }

    /**
     * ファイルに文字列を追記
     *
     * @param file ファイル
     * @param context データ（文字列）
     */
    fun appendText(file: File, content: String) {
        createFile(file)
        file.appendText(content)
    }

    /**
     * ファイルにバイトを追記
     *
     * @param file ファイル
     * @param content データ（バイト）
     */
    fun appendBytes(file: File, content: ByteArray) {
        createFile(file)
        file.appendBytes(content)
    }

    /**
     * IOを閉じる
     *
     * @param closeables closeables
     */
    fun closeIO(vararg closeables: Closeable) {
        closeables
            .forEach {
                try {
                    it.close()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
    }

    /**
     * default
     */
    var DEFAULT_DIR = sdCardPath + File.separator + "default"
    /**
     * picture
     */
    var PICTURE_DIR = sdCardPath + File.separator + "picture"
    /**
     * sound
     */
    var SOUND_DIR = sdCardPath + File.separator + "sound"
    /**
     * sound
     */
    var VIDEO_DIR = sdCardPath + File.separator + "video"
    /**
     * log
     */
    private var LOG_DIR = sdCardPath + File.separator + "log"

    val defaultDir: String
        get() {
            if (!isExternalStorageMounted) {
                return ""
            }
            val path = DEFAULT_DIR
            if (!File(path).exists()) {
                File(path).mkdirs()
            }
            return path
        }

    val logDir: String
        get() {
            if (!isExternalStorageMounted) {
                return ""
            }
            val path = LOG_DIR
            if (!File(path).exists()) {
                File(path).mkdirs()
            }
            return path
        }

    val pictureDir: String
        get() {
            if (!isExternalStorageMounted) {
                return ""
            }
            val path = PICTURE_DIR
            if (!File(path).exists()) {
                File(path).mkdirs()
            }
            return path
        }

    val soundDir: String
        get() {
            if (!isExternalStorageMounted) {
                return ""
            }
            val path = SOUND_DIR
            if (!File(path).exists()) {
                File(path).mkdirs()
            }
            return path
        }
    /**
     * SD Card project root dictionary(android/data/${project_name}/cache)
     *
     * @return
     */
    val sdCardPath: String
        get() {
            if (isExternalStorageMounted) {
                val path = ContextManager.getContext()!!.externalCacheDir
                if (path != null) {
                    return path.absolutePath
                }
            }
            return ""
        }

    /**
     * getExternalStoragePublicDirectory(String type) Get a top-level public
     * external storage directory for placing files of a particular type.
     */
    val isExternalStorageMounted: Boolean
        get() {
            val canRead = Environment.getExternalStorageDirectory().canRead()
            val onlyRead =
                Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED_READ_ONLY
            val unMounted = Environment.getExternalStorageState() == Environment.MEDIA_UNMOUNTED

            val mounted = !(!canRead || onlyRead || unMounted)
            if (!mounted) {
                LogUtils.i("FileUtils","can not achieve external storage directory")
            }
            return mounted
        }

    /**
     * get assert file
     * @return
     */

    fun getAssertFile(filePath: String): InputStream {
        return ContextManager.getContext()!!.resources.assets.open(filePath)
    }

    /**
     * add error log
     * @param errMessage
     */
    fun writeErr(
        errMessage: String,
        fileName: String = getDefaultLogName(),
        logDir: String = FileUtils.logDir
    ) {
        try {
            if (TextUtils.isEmpty(logDir)) {
                return
            }
            val path = logDir + File.separator + fileName + ".log"
            val f = File(path)
            if (!f.exists()) {
                f.createNewFile()
            }
            f.copyInputStreamToFile(errMessage.byteInputStream())
        } catch (e: Exception) {
            LogUtils.e("FileUtils","error :" + e.message)
        }
    }

    @SuppressLint("SimpleDateFormat")
    private fun getDefaultLogName(): String {
        val format = java.text.SimpleDateFormat("yyyy-MM-dd_hh-mm-ss")
        return format.format(Date())
    }
}

