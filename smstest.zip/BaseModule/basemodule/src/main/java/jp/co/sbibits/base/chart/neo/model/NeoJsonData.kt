package jp.co.sbibits.base.chart.neo.model

import java.util.*

data class NeoJsonData(val diff:List<List<Double>>, val series:List<List<Double>>) {

    fun createNeoData():NeoData {
        val neoData = NeoData()

        val diffDatas = arrayListOf<Pair<Date, Double>>()
        diff.forEach {
            val date = Date(it[0].toLong())
            val value = it[1]
            diffDatas.add(Pair(date, value))
        }
        val seriesDatas = arrayListOf<Pair<Date, Double>>()
        series.forEach {
            val date = Date(it[0].toLong())
            val value = it[1]
            seriesDatas.add(Pair(date, value))
        }
        neoData.diff = diffDatas
        neoData.series = seriesDatas
        return neoData
    }
}