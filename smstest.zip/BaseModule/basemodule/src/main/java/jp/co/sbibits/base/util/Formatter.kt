import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.NSDecimalNumber
import jp.co.sbibits.base.extension.*

object Formatter {

    val percent = "%"

    val emptyMark = "--"

    data class TrimmedSignValue(var number: String, var sign: String? = null)

    @Suppress("NAME_SHADOWING")
    fun nullValue(str: String?, nullValue: String = emptyMark): String {
        val str: String? = str
        if (str != null && !str.isEmpty()) {
            return str
        }
        return nullValue
    }


    @Suppress("UnnecessaryVariable", "NAME_SHADOWING")
    fun nullZeroValue(str: String?, nullValue: String = emptyMark): String {
        val str = str
        if (str != null && !str.isEmpty() && str.doubleValue != 0.0) {
            return str
        }
        return nullValue
    }

    fun price(str: String?, nullValue: String = emptyMark, prefix: String? = null, suffix: String? = null): String {
        val value = nullZeroValue(str?.removeDotZero())
        return number(value, nullValue = nullValue, prefix = prefix, suffix = suffix)
    }

    /**
     * 数値の先頭または末尾に文字列を含んだ状態でカンマ制御する場合に使用する
     */
    fun numberAndText(str: String?, nullValue: String = emptyMark, suffix: String? = null): String {
        var findNumber = false
        var prefixEndIndex = 0
        var numberEndIndex = str.count
        for (i in 0 until str.count) {
            val value = str?.get(i).toString()
            if (findNumber) {
                if (!value.isNumber) {
                    numberEndIndex = i
                    break
                }
            } else {
                if (value.isNumber) {
                    findNumber = true
                    prefixEndIndex = i
                }
            }
        }
        val extractPrefix = str?.substring(0, prefixEndIndex)
        val extractNumber = str?.substring(prefixEndIndex, numberEndIndex)
        val extractSuffix = str?.substring(numberEndIndex, str.count)
        return number(str = extractNumber, nullValue = nullValue, prefix = extractPrefix, suffix = if (extractSuffix.isEmpty) suffix else extractSuffix)
    }

    fun number(str: String?, nullValue: String = emptyMark, prefix: String? = null, suffix: String? = null): String {
        val number = str
        if (number == null || str.isEmpty()) {
            return nullValue
        }
        return format(number, sign = false, prefix = prefix, suffix = suffix)
    }

    fun number(value: Int?, suffix: String? = null): String {
        return number(value?.toLong(), suffix = suffix)
    }

    fun number(value: Long?, suffix: String? = null): String {
        val number = value?.toString()
        if (number == null || number.isEmpty()) {
            return emptyMark
        }
        return format(number, sign = false, suffix = suffix)
    }


    fun decimal(decimalNumber: NSDecimalNumber, decimalLength: Int): String {
        return String.format(format = "%.${decimalLength}f", args = *arrayOf(decimalNumber.roundPlain(decimalLength).doubleValue))
    }

    fun number(float: CGFloat?, decimalLength: Int = 0): String {
        if (null == float) return emptyMark
        if (float.isNaN()) return emptyMark
        val decimalNumber = NSDecimalNumber(value = float)
        return number(decimalNumber = decimalNumber, decimalLength = decimalLength)
    }

    fun number(decimalNumber: NSDecimalNumber, decimalLength: Int): String {
        val text = decimal(decimalNumber = decimalNumber, decimalLength = decimalLength)
        return format(text, sign = false)
    }

    fun numberWithParentheses(str: String?, nullValue: String = emptyMark, suffix: String? = null): String {
        val values = str?.split("(")
        if (values != null && 1 < values.size) {
            return Formatter.number(values[0], suffix = suffix) + "(" + values[1]
        }
        return nullValue
    }

    fun signedNumber(str: String?, suffix: String? = null): String {
        val number = str
        if (number == null || number.isEmpty()) {
            return emptyMark
        }
        return format(number, sign = true, suffix = suffix)
    }

    @Suppress("NAME_SHADOWING")
    fun securityCode(code: String?): String {
        val code: String? = code
        if (code != null && !code.isEmpty()) {
            return "(${code})"
        }
        return emptyMark
    }

    fun priceChange(change: String?): String {
        val value = if ((change == "+0")) change.removePrefix("+") else change
        return Formatter.signedNumber(value)
    }

    fun changePercentage(change: String?, decimalLength: Int = 2): String {
        if (change == emptyMark || change == null) {
            return emptyMark
        }
        var value = if ((change == "+0")) change.removePrefix("+") else change
        value = value.removeSuffix(percent)
        value = decimal(decimalNumber = NSDecimalNumber(string = value), decimalLength = decimalLength)
        return Formatter.signedNumber(value, suffix = percent)
    }

    private fun format(number: String, sign: Boolean = true, @Suppress("UNUSED_PARAMETER") decimalLength: Int = 0, prefix: String? = null, suffix: String? = null): String {
        val commedValue = addComma(number, prefix = prefix, suffix = suffix) + (suffix ?: "")
        return (prefix ?: "") + (if (sign) addSign(commedValue) else commedValue)
    }

    private fun addSign(number: String): String =
            if (isPlus(number) && !number.hasPrefix("+")) "+${number}" else number

    private fun addComma(number: String, prefix: String? = null, suffix: String? = null): String {

        var text = number

        // prefix, suffixは取り除く
        if (prefix != null) {
            text = number.removePrefix(prefix)
        }
        if (suffix != null) {
            text = text.removeSuffix(suffix)
        }
        // +-はいったん取り除いて後で復元
        var sign: String? = null
        if (text.hasPrefix("+")) {
            sign = "+"
            text = text.removePrefix("+")
        } else if (text.hasPrefix("-")) {
            sign = "-"
            text = text.removePrefix("-")
        }

        val numbers = text.split(".")
        @Suppress("NAME_SHADOWING")
        val number = numbers[0]
        val decimal = if (1 < numbers.count) numbers[1] else null

        val builder = StringBuilder(20)
        var numberIndex = -1
        number.reversed().forEach { c ->
            if (c.isDigit()) {
                numberIndex++
            } else {
                numberIndex = -1
            }
            if (0 < numberIndex && numberIndex % 3 == 0) {
                builder.append(",")
            }
            builder.append(c)
        }
        builder.reverse()

        if (sign != null) {
            builder.insert(0, sign)
        }

        if (decimal != null) {
            builder.append(".")
            builder.append(decimal)
        }

        return builder.toString()
    }

    private fun trimSign(number: String): TrimmedSignValue {
        if (number.hasPrefix("+")) {
            return TrimmedSignValue(number[1 until number.count], number[0 until 1])
        }
        return TrimmedSignValue(number, null)
    }

    @Suppress("NAME_SHADOWING")
    private fun trimSuffix(number: String, suffix: String? = null): String {
        val suffix: String? = suffix
        if (suffix != null) {
            return number.removeLast(suffix)
        }
        return number
    }

    @Suppress("NAME_SHADOWING")
    private fun trimPrefix(number: String, prefix: String? = null): String {
        val prefix: String? = prefix
        if (prefix != null) {
            return number.removePrefix(prefix)
        }
        return number
    }

    private fun isPlus(value: String): Boolean =
            !value.hasPrefix("-") && value.doubleValue != 0.0

    fun padRight(str: String, size: Int, spacer: String): String {
        if (str.isEmpty()) {
            return str
        }
        var result = str
        val add = size - str.size
        if (0 < add) {
            (0 until add).forEach { _ ->
                result += spacer
            }
        }
        return result
    }

    private val stringLiteralConversion = mapOf(
            "\r" to "",
            "\n" to "\\n",
            "\"" to "\\\"",
            "\'" to "\\'",
            "\t" to "\\t"
    )

    // escape
    fun escapeForStringLiteral(src: String): String {
        var result = src
        stringLiteralConversion.forEach { (key, value) ->
            result = result.replacingOccurrences(of = key, with = value)
        }
        return result
    }
}
