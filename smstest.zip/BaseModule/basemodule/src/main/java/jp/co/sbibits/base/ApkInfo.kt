package jp.co.sbibits.base

import android.content.Context
import android.content.pm.PackageInfo
import jp.co.sbibits.base.extension.getVersionCode

/**
 * アプリ情報
 */
object ApkInfo {

    var packageName: String
    var programName: String
    var versionCode: Long = 0
    var versionName: String = "0"

    init {
        val context: Context = ContextManager.getContext()!!
        val applicationInfo = context.applicationInfo
        packageName = applicationInfo.packageName
        programName = context.resources
            .getText(applicationInfo.labelRes).toString()
        val packageInfo: PackageInfo?
        packageInfo = context.packageManager.getPackageInfo(
            packageName, 0
        )
        versionCode = packageInfo.getVersionCode()
        versionName = packageInfo?.versionName?:""
    }
}