package jp.co.sbibits.base.http

abstract class TextHttpTask : HttpTask<String>() {

    final override val resultClass = String::class

    override fun parseResponse(data: String): String {
        return data
    }
}
