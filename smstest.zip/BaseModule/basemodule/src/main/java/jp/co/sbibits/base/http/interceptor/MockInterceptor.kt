package jp.co.sbibits.base.http.interceptor

import android.util.Log
import jp.co.sbibits.base.ContextManager
import okhttp3.*

/**
 * catch the mock request and return a response body with target file stream
 * @property mockName String? target file name
 */
open class MockInterceptor(var mockName: String?) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response? {
        if (null != mockName) {
            try {
                //get target file stream
                val inputStream = ContextManager.getContext()!!.assets.open("$mockName")
                val responseBuilder = Response.Builder()
                    .code(200)
                    .message("mock")
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_0)
                responseBuilder.body(
                    ResponseBody.create(
                        MediaType.parse("text/plain"),
                        inputStream.readBytes()
                    )
                )
                return responseBuilder.build()
            } catch (e: Exception) {
                Log.i("mock fail", "$mockName ${e.message}")
            }
        }
        return chain.proceed(chain.request())
    }
}