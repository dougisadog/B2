package jp.co.sbibits.base.extension

import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import jp.co.sbibits.base.chart.ios.CGRect

var View.intTag: Int
    get() = tag as? Int ?: 0
    set(value) {
        tag = value
    }

var View.isHidden: Boolean
    get() = visibility == View.INVISIBLE || visibility == View.GONE
    set(value) {
        visibility = if (value) View.INVISIBLE else View.VISIBLE
    }

var View.isGone: Boolean
    get() = visibility == View.GONE
    set(value) {
        visibility = if (value) View.GONE else View.VISIBLE
    }

fun View.animate(withDuration: Long, toAlpha: Float) {
    var alphaAnimate = AlphaAnimation(this.alpha, toAlpha)
    alphaAnimate.duration = withDuration
    alphaAnimate.fillAfter = true
    startAnimation(alphaAnimate)
}

fun View.removeFromSuperview() {
    (parent as? ViewGroup)?.removeView(this)
}

val View.frame: CGRect
    get() = CGRect(0.0, 0.0, width = width.toDouble(), height = height.toDouble())
