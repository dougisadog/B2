package jp.co.sbibits.base.chart.fx

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.View
import jp.co.sbibits.base.chart.fx.drawer.PieChartDrawer
import jp.co.sbibits.base.chart.fx.model.PieChartData

class PieChart : View {

    private val config = FxChartConfig()

    private var pieChartData:PieChartData = PieChartData(arrayListOf())

    private var innerData:PieChartData = PieChartData(arrayListOf())

    constructor(context: Context) : super(context) {
        defaultInit()
    }
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        defaultInit()
    }
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        defaultInit()
    }

    private fun defaultInit() {

    }

    fun initPie(pieChartData:PieChartData, innnerData:PieChartData) {
        this.pieChartData = pieChartData
        this.innerData = innnerData
        invalidate()
    }

    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        if (null == canvas) return
        val drawer = PieChartDrawer(canvas)

        var outR = config.pieOutterRadius
        if (null == outR) {
            outR = width.toDouble()/2 - 100
        }
        drawer.r = outR.toInt()
        drawer.draw(pieChartData)

        var inR = config.pieInnerRadius
        if (null == inR) {
            inR = drawer.r.toDouble()/5 * 3
        }
        drawer.r = inR.toInt()
        drawer.draw(innerData)
    }

}