package jp.co.sbibits.base.extension

val Boolean?.check: Boolean
    get() {
        return this ?: false
    }