package jp.co.sbibits.base.chart.fx.drawer

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.ios.CGRect
import jp.co.sbibits.base.chart.ios.CGSize
import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.fx.AssetChart
import jp.co.sbibits.base.chart.fx.model.AssetChartData
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.extension.size

class AssetChartDrawer : FxChartDrawer() {

    // 吹き出しの矢印の長さ
    val arrowLength = config.size(10.0) // マージン含む長さ

    val fukiPercent = 6.0

    var maxData:AssetChartData = AssetChartData("", 0xffffff, arrayListOf())

    var data = arrayListOf<AssetChartData>()
    set(value) {
        field = value
        maxData = value[value.size - 1]
    }

    /** 吹き出し */
    fun drawRoundRect(point:CGPoint, width:CGFloat, height:CGFloat, curveOffset:CGFloat, newestPoint:CGPoint) {

        // 左辺上部の丸みの終わる部分から反時計回り
        context.beginPath()
        context.move(CGPoint(point.x, point.y + curveOffset))
        context.addLine(CGPoint(point.x, point.y + height - curveOffset))
        context.quadraticCurveTo(CGPoint(point.x, point.y + height), CGPoint(point.x + curveOffset, point.y + height))

    //吹き出しの矢 start
        context.addLine(CGPoint(point.x + width * (0.5 - 1/fukiPercent/2), point.y + height))
        context.addLine(newestPoint)
        context.addLine(CGPoint(point.x + width * (0.5 + 1/fukiPercent/2), point.y + height))
    //吹き出しの矢 end

        context.addLine(CGPoint(point.x + width - curveOffset, point.y + height))
        context.quadraticCurveTo(CGPoint(point.x+ width, point.y + height), CGPoint(point.x+ width, point.y + height - curveOffset))

        context.addLine(CGPoint(point.x + width , point.y + curveOffset))
        context.quadraticCurveTo(CGPoint(point.x+ width, point.y), CGPoint(point.x+ width- curveOffset, point.y))

        context.addLine(CGPoint(point.x + curveOffset , point.y ))
        context.quadraticCurveTo(CGPoint(point.x, point.y), CGPoint(point.x, point.y+ curveOffset))
//        context.setLineDash(phase = 0, lengths = listOf(config.lineDashSize, config.lineDashSize))
        context.setLineWidth(config.size(2.0))
        context.setStroke(config.cloudLineColor)
        context.strokePath()
        context.setFill(config.cloudBackgroundColor)
        context.fillPath()

    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        range.update(0.0)
        maxData.dataArray.forEach {number ->
            range.update(number)
        }
    }

    var axisNameArray = listOf<String>()
    var axisIndexFilter = listOf<Int>()


    fun setAxisArray(axisNameArray:List<String>, axisIndexFilter:List<Int>) {
        this.axisNameArray = axisNameArray
        this.axisIndexFilter = axisIndexFilter
    }

    override fun draw() {
        config.frameBorderColor = UIColor(rgbValue = 0xcdcdcd)
        config.lineWidth = config.size(3.0)
        drawFrame()
        drawYScales(4, true)
        val timeList = arrayListOf<String>()
        axisNameArray.forEach {
            timeList.add(it)
        }
        if (config.isTimeAreaEnabled) {
            config.gridColor = UIColor(rgbValue = 0xAAAAAA)
            drawXScales(timeList = timeList, axisIndexes = axisIndexFilter, adjustBottom = true)
        }

        data.forEachIndexed { index, dataByCategory ->
            var dataType1 = AssetChart.zeroDataName
            if (0 < index) {
                // 一つ前のデータ
                dataType1 = data[index - 1].categoryName
            }

            val type1 = ValueArray()
            val type2 = ValueArray()

            chartData.recordTable[dataType1]?.forEach {
                type1.append(it)
            }
            chartData.recordTable[dataByCategory.categoryName]?.forEach {
                type2.append(it)
            }
            val color = dataByCategory.color
            if (null != color) {
                fillArea(type1, type2, UIColor(rgbValue = color, alpha = 0.8))
            }

        }

        val textY = "(円)"
        val font = config.draggingNumberFont
        val textSize = textY.size(font)

        val point = CGPoint(x = config.yScaleAreaWidth - textSize.width, y = config.topMargin - textSize.height)

        context.drawText(textY, point, font = font, color = config.scaleFontColor)

        // 右端のY
        val newest = newest()
        val newestYPosition = newest.y

        // 吹き出しのサイズ

        val newTextSize = newest.x.toString().size(config.legendFont)

        val padding = 20
        val balloonWidth = newTextSize.width + padding * 2
        val balloonHeight = newTextSize.height + padding * 2


        // 吹き出しの位置
        val xPosition = rect.width + rect.origin.x - balloonWidth * 2 / 3
        val yPosition = newestYPosition - balloonHeight - arrowLength

        val balloon = CGRect(CGPoint(xPosition,yPosition), CGSize(balloonWidth, balloonHeight))

        val x = balloon.minX +  padding
        val y = balloon.minY + padding

        val curveOffset = Math.min(balloonWidth, balloonHeight) * 0.3
        drawRoundRect(balloon.origin, balloon.width, balloon.height, curveOffset, CGPoint(rect.maxX,newestYPosition))
        context.drawText(newest.x.toString(), CGPoint(x,y), config.legendFont, UIColor(rgbValue = 0x333))

        context.saveGState()
    }


    private fun newest() :CGPoint{
        val valToHeight = rect.size.height / range.width
        val chartBottom = rect.origin.y + rect.size.height
        val maxDataArray = maxData.dataArray

        // 右端の値
        var newestValue = 0.0
        if (maxDataArray.size > 0) {
            newestValue = maxDataArray[maxDataArray.size - 1]
        }
        // 右端の位置
        val newestYPosition = chartBottom - ( newestValue - range.min ) * valToHeight
        return CGPoint(newestValue, newestYPosition)
    }

}