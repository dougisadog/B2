package jp.co.sbibits.base.chart.ui

import jp.co.sbibits.base.chart.ios.UIColor

/**
 * アプリ共通定数
 */
object ChartBaseConfig {

    //出来高
    var volunmeBarColor = UIColor.yellow

    var volunmePerPriceBarAmount = 12
    var volunmePerPriceBarColor = UIColor(rgbValue = 0xffd700, alpha = 0.35)

    //turnPoint
    var turnPointBackgoundColor = UIColor.yellow
    var turnPointTextColor = UIColor.white
    var turnPointSpan = 10

    //DMI/ADX
    var DMI_diPlusColor = UIColor(red = 0.91, green = 0.30, blue = 0.33, alpha = 1.0)
    var DMI_diMinusColor = UIColor(red = 0.20, green = 0.60, blue = 0.86, alpha = 1.0)
    var DMI_adxColor = UIColor.yellow
    var DMI_adxrColor = UIColor(red = 0.60, green = 0.98, blue = 0.60, alpha = 1.0)

    //RSI
    var RSI_rsi1Color = UIColor.yellow
    var RSI_rsi2Color = UIColor.red
    var RSI_rsi3Color = UIColor.cyan

    //BollingerBand
    var BollingerBand_bb0Color = UIColor.gray
    var BollingerBand_bb1Color = UIColor(red = 0.32, green = 0.56, blue = 1.00, alpha = 1.0)
    var BollingerBand_bb2Color = UIColor(red = 0.50, green = 1.00, blue = 0.83, alpha = 1.0)
    var BollingerBand_bb3Color = UIColor(red = 0.78, green = 1.00, blue = 0.24, alpha = 1.0)

    //MACD
    var MACD_macdColor = UIColor(red = 0.24, green = 0.80, blue = 0.44, alpha = 1.0)
    var MACD_signalColor = UIColor(rgbValue = 0xe6bd45)
    var MACD_oscPlusColor = UIColor(red = 0.91, green = 0.30, blue = 0.33, alpha = 1.0)
    var MACD_oscMinusColor = UIColor(red = 0.20, green = 0.60, blue = 0.86, alpha = 1.0)
    var MACD_yScaleDecimalLength: Int = 0

    //Stochastics
    var Stochastics_kColor = UIColor(red = 1.0, green = 0.27, blue = 0.00, alpha = 1.0)
    var Stochastics_dColor = UIColor(red = 0.53, green = 0.81, blue = 0.98, alpha = 1.0)
    var Stochastics_sdColor = UIColor(red = 1.0, green = 0.84, blue = 0.00, alpha = 1.0)

    //Ichimoku
    var Ichimoku_kijunColor = UIColor.green
    var Ichimoku_tenkanColor = UIColor.red
    var Ichimoku_senko1Color = UIColor.orange
    var Ichimoku_senko2Color = UIColor(red = 1.00, green = 0.41, blue = 0.71, alpha = 1.0)
    var Ichimoku_kumoColor = UIColor(white = 1.0, alpha = 0.3)
    var Ichimoku_chikoColor = UIColor(red = 1.00, green = 0.83, blue = 0.0, alpha = 1.0)

    //Comparison
    var comparisonBaseColor = UIColor(rgbValue = 0xF7D94C)
    var comparisonColor = UIColor(rgbValue = 0xE03C8A)

    var legendBackgroundColor = UIColor(red = 23.0 / 255, green = 26.0 / 255, blue = 38.0 / 255, alpha = 0.5)

    var priceMarkerPurple = 0 //touched horizontal price line marker
    var priceMarkerOrange = 0 //selected horizontal price line marker
    var priceMarkerGray = 0 //unselected horizontal price line marker
    var timeMarkerPurple = 0 //touched vertical time line marker
    var timeMarkerOrange = 0 //selected vertical time line marker
    var timeMarkerGray = 0 //unselected vertical time line marker
}