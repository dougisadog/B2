package jp.co.sbibits.base.http.util

import jp.co.sbibits.base.extension.joined
import java.net.URLEncoder

object QueryUtils {

    fun makeQueryString(items: List<Pair<String, String?>>, encoder: ((String) -> (String))? = null): String? {
        if (items.isNotEmpty()) {

            val queries = items.map {
                if (encoder != null) {
                    encoder(it.first) + "=" + encoder(it.second ?: "")
                } else {
                    urlEncode(it.first) + "=" + urlEncode(
                        it.second
                            ?: ""
                    )
                }
            }

            return queries.joined(separator = "&")
        }
        return null
    }

    fun urlEncode(str: String): String {
        return URLEncoder.encode(str, "UTF-8")
    }
}
