package jp.co.sbibits.base.environment

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import jp.co.sbibits.base.extension.append

/**
 * テストサーバ選択画面
 */
open class EnvironmentSelectActivity : Activity() {

    private var environmentItems: MutableList<EnvironmentItem> = mutableListOf()
    private var settingSpinners: MutableList<Spinner> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addData()

        val contentLayout = buildMainLayout()

        val headerLabel = buildHeader()
        contentLayout.addView(headerLabel)

        val scrollLayout = buildContentLayout()
        val scrollView = buildScrollView()
        scrollView.addView(scrollLayout)
        contentLayout.addView(scrollView)

        val okButton = buildButton()
        contentLayout.addView(okButton)
        setContentView(contentLayout)
    }

    private fun buildMainLayout(): LinearLayout {
        val contentLayout = LinearLayout(this)
        contentLayout.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        )
        contentLayout.orientation = LinearLayout.VERTICAL
        return contentLayout
    }

    private fun buildHeader(): TextView {
        val headerLabel = TextView(this)
        headerLabel.layoutParams =
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 140)
        headerLabel.gravity = Gravity.CENTER
        headerLabel.setBackgroundColor(Color.BLACK)
        headerLabel.setTextColor(Color.WHITE)
        val headContent = "Please select server"
        headerLabel.text = headContent
        return headerLabel
    }

    private fun buildContentLayout(): LinearLayout {
        val scrollLayout = LinearLayout(this)
        scrollLayout.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        )
        scrollLayout.orientation = LinearLayout.VERTICAL

        for (item in environmentItems) {

            val layout = LinearLayout(this)
            layout.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                140
            )
            layout.setPadding(50,0,50,0)

            val textView = TextView(this)
            textView.layoutParams =
                LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    1f
                )
            textView.gravity = Gravity.CENTER_VERTICAL
            textView.text = item.settingLabel
            layout.addView(textView)

            val spinner = Spinner(this)
            spinner.gravity = Gravity.CENTER
            spinner.layoutParams =
                LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    3f
                )

            val adapter = getSpinnerAdapter()
            adapter.addAll(item.settingItemKeys)
            spinner.adapter = adapter
            layout.addView(spinner)

            settingSpinners.add(spinner)

            scrollLayout.addView(layout)
        }
        return scrollLayout
    }

    private fun getSpinnerAdapter(): ArrayAdapter<String> {
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        return adapter
    }

    private fun buildScrollView(): ScrollView {
        val scrollView = ScrollView(this)
        scrollView.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        return scrollView
    }

    private fun buildButton(): Button {
        val okButton = Button(this)
        okButton.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        val buttonText = "OK"
        okButton.text = buttonText
        okButton.setOnClickListener {
            onEnvironmentResultLoaded(getEnvironmentResult())
        }
        return okButton
    }

    fun addItem(label: String, name: String, items: LinkedHashMap<String, String>) {
        environmentItems.append(EnvironmentItem(label, name, items))
    }

    open fun addData() {}

    private fun getEnvironmentResult(): LinkedHashMap<String, String> {
        val selectedItems: LinkedHashMap<String, String> = linkedMapOf()
        environmentItems.forEachIndexed { index, item ->
            val selectKey = settingSpinners[index].selectedItem
            val selectValue = item.settingItems[selectKey]
            selectedItems[item.settingName] = selectValue!!
        }
        return selectedItems
    }

    /**
     *  Environments selected callback
     */
    open fun onEnvironmentResultLoaded(items: LinkedHashMap<String, String>) {
    }
}