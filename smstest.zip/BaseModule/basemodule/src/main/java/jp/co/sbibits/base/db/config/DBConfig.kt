package jp.co.sbibits.base.db.config

import jp.co.sbibits.base.db.config.classloader.BaseEntityClassLoader
import jp.co.sbibits.base.db.entity.BaseEntity
import jp.co.sbibits.base.db.realm.RealmConfig
import jp.co.sbibits.base.db.sqlite.SQLiteConfig
import kotlin.reflect.KClass

/**
 * base config for DB
 * @param name the DB name
 * @param version the DB version
 * @param clazzes the classes that need to init
 */
class DBConfig private constructor(
    val name: String,
    val version: Int,
    val clazzes: MutableList<KClass<out BaseEntity>>
) {
    //
    var defaultDBType: DBType = DBType.SQLite

    //won't init the SQLite if it's null
    var sqliteConfig: SQLiteConfig? = null

    //won't init the Realm if it's null
    var realmConfig: RealmConfig? = null

    var onError: (() -> Unit)? = null

    class Builder private constructor(private val dbConfig: DBConfig) {

        companion object {
            fun create(name: String, version: Int): Builder {
                return Builder(DBConfig(name, version, mutableListOf()))
            }
        }

        fun appendDefaultDBType(type: DBType): Builder {
            dbConfig.defaultDBType = type
            return this
        }

        fun appendSQLiteConfig(sqliteConfig: SQLiteConfig): Builder {
            dbConfig.sqliteConfig = sqliteConfig
            return this
        }

        fun appendRealmConfig(realmConfig: RealmConfig): Builder {
            dbConfig.realmConfig = realmConfig
            return this
        }

        fun classesLoader(loader: BaseEntityClassLoader): Builder {
            dbConfig.clazzes.clear()
            dbConfig.clazzes.addAll(loader.load())
            return this
        }

        fun appendInitError(onError: (() -> Unit)): Builder {
            dbConfig.onError = onError
            return this
        }

        fun build(): DBConfig {
            return dbConfig
        }
    }


}