package jp.co.sbibits.base.db.dao

import io.realm.RealmModel
import jp.co.sbibits.base.db.config.DBType
import jp.co.sbibits.base.db.entity.BaseEntity
import jp.co.sbibits.base.db.extension.getTableName
import jp.co.sbibits.base.db.realm.RealmBaseDao
import jp.co.sbibits.base.db.realm.RealmEntity
import jp.co.sbibits.base.db.sqlite.SQLiteEntity
import jp.co.sbibits.base.db.sqlite.SQLiteImpl
import kotlin.reflect.KClass
import kotlin.reflect.full.createInstance

object DaoCache {

    private val cacheDao = hashMapOf<String, BaseDao<out BaseEntity>>()

    /**
     * get dao by cache / create dao
     */
    fun <T : BaseEntity> get(type: DBType, clazz: KClass<T>): BaseDao<T> {
        val key = type.name + "_" + clazz.getTableName()
        return cacheDao.getOrPut(key, {
            createDao(type, clazz)
        }) as BaseDao<T>
    }

    /**
     * create dao impl
     */
    private fun <T : BaseEntity> createDao(dbType: DBType, clazz: KClass<T>): BaseDao<T> {
        val entity = clazz.createInstance()
        if (entity is SQLiteEntity && dbType == DBType.SQLite) {
            return SQLiteImpl(entity::class as KClass<SQLiteEntity>) as BaseDao<T>
        }
        if (entity is RealmEntity<*> && dbType == DBType.Realm) {
            return RealmBaseDao(
                entity::class as KClass<RealmEntity<RealmModel>>,
                entity.getRealmClass() as KClass<RealmModel>
            ) as BaseDao<T>
        }
        throw Exception("no implementation!")
    }
}