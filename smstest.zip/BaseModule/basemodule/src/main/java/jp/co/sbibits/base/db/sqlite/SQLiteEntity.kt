package jp.co.sbibits.base.db.sqlite

import android.provider.BaseColumns
import jp.co.sbibits.base.db.entity.BaseEntity

interface SQLiteEntity : BaseColumns, BaseEntity {

    fun initByQuery() {}

}