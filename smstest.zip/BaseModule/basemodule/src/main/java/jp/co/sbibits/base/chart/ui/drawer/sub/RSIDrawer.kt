package jp.co.sbibits.base.chart.ui.drawer.sub

import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.ChartDataType
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.extension.append

/**
 * RSI
 */
class RSIDrawer: ChartDrawer() {
    private val rsi1Color = ChartBaseConfig.RSI_rsi1Color
    private val rsi2Color = ChartBaseConfig.RSI_rsi2Color
    private val rsi3Color = ChartBaseConfig.RSI_rsi3Color

    override fun calculate() {
        val chartData = chartData ?: return
        val span1 = technicalParam.rsi1Span
        val span2 = technicalParam.rsi2Span
        val span3 = technicalParam.rsi3Span
        chartData[ChartDataType.RSI1] = makeRSIList(span = span1)
        chartData[ChartDataType.RSI2] = makeRSIList(span = span2)
        chartData[ChartDataType.RSI3] = makeRSIList(span = span3)
    }

    fun makeRSIList(span: Int) : ValueArray {
        val result = ValueArray()
        val chartData = chartData ?: return result
        val closeList = chartData[ChartDataType.CLOSE]
        var preValue: CGFloat? = null
        var gainSum: CGFloat = 0.0
        var lossSum: CGFloat = 0.0
        var gains: MutableList<CGFloat> = mutableListOf()
        var losses: MutableList<CGFloat> = mutableListOf()
        for (i in closeList.indicies) {
            var rsi: CGFloat? = null
            val value = closeList[i]
            var gain: CGFloat = 0.0
            var loss: CGFloat = 0.0
            if (value != null && preValue != null) {
                gain = Math.max(0.0, value - preValue)
                loss = Math.max(0.0, preValue - value)
            }
            if (i <= span) {
                gainSum += gain
                lossSum += loss
            } else {
                gainSum += (gain - gains[i - span])
                lossSum += (loss - losses[i - span])
            }
            if (span <= i) {
                val d = gainSum + lossSum
                if (d != 0.0) {
                    rsi = (gainSum / d) * 100
                }
            }
            result.append(rsi)
            gains.append(gain)
            losses.append(loss)
            preValue = value
        }
        return result
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        range.update(0.0)
        range.update(105.0)
    }

    override fun draw() {
        if (technicalParam.rsi1On) {
            drawLineChart(dataType = ChartDataType.RSI1, color = rsi1Color)
        }
        if (technicalParam.rsi2On) {
            drawLineChart(dataType = ChartDataType.RSI2, color = rsi2Color)
        }
        if (technicalParam.rsi3On) {
            drawLineChart(dataType = ChartDataType.RSI3, color = rsi3Color)
        }
    }

    override fun addLegend() {
        if (technicalParam.rsi1On) {
            addLegendValue(title = "短期", dataType = ChartDataType.RSI1, color = rsi1Color, decimalLength = 0)
        }
        if (technicalParam.rsi2On) {
            addLegendValue(title = "中期", dataType = ChartDataType.RSI2, color = rsi2Color, decimalLength = 0)
        }
        if (technicalParam.rsi3On) {
            addLegendValue(title = "長期", dataType = ChartDataType.RSI3, color = rsi3Color, decimalLength = 0)
        }
    }
}
