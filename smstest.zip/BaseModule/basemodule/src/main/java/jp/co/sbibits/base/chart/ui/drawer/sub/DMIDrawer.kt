package jp.co.sbibits.base.chart.ui.drawer.sub

import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.ChartDataType
import jp.co.sbibits.base.chart.ui.model.ValueArray
import jp.co.sbibits.base.chart.ui.model.ValueRange
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil
import jp.co.sbibits.base.CGFloat

/**
 * DMI/ADX
 */
class DMIDrawer: ChartDrawer() {
    private val diPlusColor = ChartBaseConfig.DMI_diPlusColor
    private val diMinusColor = ChartBaseConfig.DMI_diMinusColor
    private val adxColor = ChartBaseConfig.DMI_adxColor
    private val adxrColor = ChartBaseConfig.DMI_adxrColor

    override fun calculate() {
        val chartData = chartData ?: return
        val averageSpan = technicalParam.dmiAverageSpan
        val highList = chartData[ChartDataType.HIGH]
        val lowList = chartData[ChartDataType.LOW]
        val closeList = chartData[ChartDataType.CLOSE]
        val plusDMList = ValueArray()
        val minusDMList = ValueArray()
        val trList = ValueArray()
        for (i in 0 until highList.size) {
            var plusDM: CGFloat? = null
            var minusDM: CGFloat? = null
            var tr: CGFloat? = null
            val high = highList[i]
            val low = lowList[i]
            val lastHigh = highList[i - 1]
            val lastLow = lowList[i - 1]
            val lastClose = closeList[i - 1]
            if (0 < i && high != null && low != null && lastHigh != null && lastLow != null && lastClose != null) {
                var plusDMVal = Math.max(high - lastHigh, 0.0)
                var minusDMVal = Math.max(lastLow - low, 0.0)
                if (plusDMVal <= minusDMVal) {
                    plusDMVal = 0.0
                }
                if (minusDMVal <= plusDMVal) {
                    minusDMVal = 0.0
                }
                plusDM = plusDMVal
                minusDM = minusDMVal
                tr = Math.max(high - low, high - lastClose)
                tr = Math.max(tr, lastClose - low)
            }
            plusDMList.append(plusDM)
            minusDMList.append(minusDM)
            trList.append(tr)
        }
        val avPDMList = ChartMathUtil.calcSMA(src = plusDMList, span = averageSpan)
        val avMDMList = ChartMathUtil.calcSMA(src = minusDMList, span = averageSpan)
        val avTrList = ChartMathUtil.calcSMA(src = trList, span = averageSpan)
        val plusDIList = ValueArray()
        val minusDIList = ValueArray()
        val dxList = ValueArray()
        for (i in 0 until avTrList.size) {
            var plusDI: CGFloat? = null
            var minusDI: CGFloat? = null
            val avPlusDM = avPDMList[i]
            val avMinusDM = avMDMList[i]
            val avTR = avTrList[i]
            if (avPlusDM != null && avMinusDM != null && avTR != null) {
                if (avTR != 0.0) {
                    plusDI = 100.0 * avPlusDM / avTR
                    minusDI = 100.0 * avMinusDM / avTR
                } else {
                    plusDI = 0.0
                    minusDI = 0.0
                }
            }
            plusDIList.append(plusDI)
            minusDIList.append(minusDI)
            var dx: CGFloat? = null
            if (plusDI != null && minusDI != null) {
                val dx1 = Math.abs(plusDI - minusDI)
                val dx2 = plusDI + minusDI
                if (dx2 != 0.0) {
                    dx = 100.0 * dx1 / dx2
                } else {
                    dx = 0.0
                }
            }
            dxList.append(dx)
        }
        val adxList = ChartMathUtil.calcSMA(src = dxList, span = technicalParam.dmiAdxSpan)
        val adxrList = ChartMathUtil.calcSMA(src = adxList, span = technicalParam.dmiAdxrSpan)
        chartData[ChartDataType.DMI_PLUS_DI] = plusDIList
        chartData[ChartDataType.DMI_MINUS_DI] = minusDIList
        chartData[ChartDataType.DMI_ADX] = adxList
        chartData[ChartDataType.DMI_ADXR] = adxrList
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        range.update(105.0)
        range.update(0.0)
    }

    override fun draw() {
        if (technicalParam.dmiDiOn) {
            drawLineChart(dataType = ChartDataType.DMI_PLUS_DI, color = diPlusColor)
            drawLineChart(dataType = ChartDataType.DMI_MINUS_DI, color = diMinusColor)
        }
        if (technicalParam.dmiAdxOn) {
            drawLineChart(dataType = ChartDataType.DMI_ADX, color = adxColor)
        }
        if (technicalParam.dmiAdxrOn) {
            drawLineChart(dataType = ChartDataType.DMI_ADXR, color = adxrColor)
        }
    }

    override fun addLegend() {
        if (technicalParam.dmiDiOn) {
            addLegendValue(title = "+DI", dataType = ChartDataType.DMI_PLUS_DI, color = diPlusColor, decimalLength = 0)
            addLegendValue(title = "-DI", dataType = ChartDataType.DMI_MINUS_DI, color = diMinusColor, decimalLength = 0)
        }
        if (technicalParam.dmiAdxOn) {
            addLegendValue(title = "ADX", dataType = ChartDataType.DMI_ADX, color = adxColor, decimalLength = 0)
        }
        if (technicalParam.dmiAdxrOn) {
            addLegendValue(title = "ADXR", dataType = ChartDataType.DMI_ADXR, color = adxrColor, decimalLength = 0)
        }
    }
}
