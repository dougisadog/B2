package jp.co.sbibits.base.chart.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import jp.co.sbibits.base.ContextManager

object ChartImageHolder {

    val priceMarkerPurple = imageLiteral(resourceId = ChartBaseConfig.priceMarkerPurple)
    val priceMarkerOrange = imageLiteral(resourceId = ChartBaseConfig.priceMarkerOrange)
    val priceMarkerGray = imageLiteral(resourceId = ChartBaseConfig.priceMarkerGray)
    val timeMarkerPurple = imageLiteral(resourceId = ChartBaseConfig.timeMarkerPurple)
    val timeMarkerOrange = imageLiteral(resourceId = ChartBaseConfig.timeMarkerOrange)
    val timeMarkerGray = imageLiteral(resourceId = ChartBaseConfig.timeMarkerGray)

    private fun imageLiteral(resourceId: Int): Bitmap {
        return BitmapFactory.decodeResource(ContextManager.getContext()?.resources, resourceId)
    }

}