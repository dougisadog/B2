package jp.co.sbibits.base.chart.ui.drawer.custom_line

import jp.co.sbibits.base.chart.ui.model.ChartPoint
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil
import jp.co.sbibits.base.extension.integerValue
import jp.co.sbibits.base.chart.ios.IntEnumDefault
import jp.co.sbibits.base.chart.ios.value
import jp.co.sbibits.base.chart.ui.model.ChartDataType

open class TrendLine : CustomLine() {

    enum class TrendLineState : IntEnumDefault {
        moveStartPoint,       // 始点移動
        waitEndPoint,         // 終点タップ待ち
        moveEndPoint,         // 終点移動
        moveStartPointOnly,  // ライン確定後の始点移動
        moveLine;              // ライン移動
    }

    private var trendLineState: TrendLineState?
        get() {
            val stateCode = stateCode
            if (stateCode != null) {
                return TrendLineState::class.value(stateCode)
            }
            return null
        }
        set(value) {
            stateCode = value?.rawValue
        }

    var startPoint: ChartPoint? = null
    var endPoint: ChartPoint? = null
    var timeSpan: Int? = null

    var moveOriginTouchPoint: ChartPoint? = null
    var moveOriginStartPoint: ChartPoint? = null
    var moveOriginEndPoint: ChartPoint? = null

    // タイムスパンが不正か（ハイブリッド版からのデータ引き継ぎバグで発生）
    val isTimeSpanBroken: Boolean
        get() = startPoint != null && endPoint != null
                && (timeSpan == 0) && (startPoint?.time != endPoint?.time)

    override fun touchesBegan(point: ChartPoint) {
        if (isInitialState) {
            startPoint = point
            trendLineState = TrendLineState.moveStartPoint
        } else if (trendLineState == TrendLineState.waitEndPoint) {
            endPoint = point
            trendLineState = TrendLineState.moveEndPoint
            updateSpan()
        }
    }

    override fun touchesMoved(point: ChartPoint) {
        super.touchesMoved(point)
        if (trendLineState == TrendLineState.moveStartPoint || trendLineState == TrendLineState.moveStartPointOnly) {
            startPoint = point
        } else if (trendLineState == TrendLineState.moveEndPoint) {
            endPoint = point
        } else if (trendLineState == TrendLineState.moveLine) {
            moveLine(point = point)
        }
        updateSpan()
    }

    private fun moveLine(point: ChartPoint) {
        val chartData = chartData ?: return
        val moveOriginTouchPoint = moveOriginTouchPoint ?: return
        val moveOriginStartPoint = moveOriginStartPoint ?: return
        val moveOriginEndPoint = moveOriginEndPoint ?: return

        val originTouchIndex = coordinate.index(time = moveOriginTouchPoint.time)
        val originStartIndex = coordinate.index(time = moveOriginStartPoint.time)
        val originEndIndex = coordinate.index(time = moveOriginEndPoint.time)
        val pointIndex = coordinate.index(time = point.time)
        if (originTouchIndex == null || originStartIndex == null || originEndIndex == null || pointIndex == null) {
            return
        }

        // 日時を移動
        val maxIndex = chartData.count - 1
        var indexDiff = pointIndex - originTouchIndex
        val originHighIndex = Math.max(originStartIndex, originEndIndex)
        val originLowIndex = Math.min(originStartIndex, originEndIndex)

        if (maxIndex < originHighIndex + indexDiff) {
            indexDiff -= (originHighIndex + indexDiff) - maxIndex
        } else if (originLowIndex + indexDiff < 0) {
            indexDiff -= (originLowIndex + indexDiff) - 0
        }

        val newStartTime = coordinate.time(index = originStartIndex + indexDiff)
        val newEndTime = coordinate.time(index = originEndIndex + indexDiff)
        if (newStartTime == null || newEndTime == null) {
            return
        }

        startPoint?.time = newStartTime
        endPoint?.time = newEndTime

        // レートを移動
        var rateDif = point.value - moveOriginTouchPoint.value
        val rateHighBase = Math.max(moveOriginStartPoint.value, moveOriginEndPoint.value)
        val rateLowBase = Math.min(moveOriginStartPoint.value, moveOriginEndPoint.value)

        if (range.max < rateHighBase + rateDif) {
            rateDif -= (rateHighBase + rateDif) - range.max
        } else if (rateLowBase + rateDif < range.min) {
            rateDif -= (rateLowBase + rateDif) - range.min
        }

        startPoint?.value = moveOriginStartPoint.value + rateDif
        endPoint?.value = moveOriginEndPoint.value + rateDif
    }

    fun updateSpan() {
        val startIndex = coordinate.index(time = startPoint?.time)
        val endIndex = coordinate.index(time = endPoint?.time)
        if (isCompleted && startIndex != null && endIndex != null) {
            timeSpan = endIndex - startIndex
        } else {
            timeSpan = null
        }
    }

    override fun touchesEnded(point: ChartPoint) {
        if (trendLineState == TrendLineState.moveStartPoint) {
            trendLineState = TrendLineState.waitEndPoint
        } else if (trendLineState == TrendLineState.moveEndPoint
                || trendLineState == TrendLineState.moveStartPointOnly
                || trendLineState == TrendLineState.moveLine) {
            trendLineState = null
        }
    }

    override fun draw() {
        context.saveGState()
        val startPos = coordinate.location(chartPoint = startPoint) ?: return
        val endPos = coordinate.location(chartPoint = endPoint)
        if (endPos != null) {
            drawHalfLine(start = startPos, end = endPos, isSelected = isSelected)
            if (isDrawingEnabled()) {
                drawPoint(endPos, isSelected = isSelected)
            }
        }
        if (isDrawingEnabled()) {
            drawPoint(startPos, isSelected = isSelected)
        }
        context.restoreGState()
    }

    override fun selectItem(point: ChartPoint) : Boolean {
        val touchPos = coordinate.location(chartPoint = point)
        val startPos = coordinate.location(chartPoint = startPoint)
        if (touchPos == null || startPos == null) {
            return false
        }
        if (ChartMathUtil.isNearPoints(point1 = touchPos, point2 = startPos, range = config.pointTouchRange)) {
            trendLineState = TrendLineState.moveStartPointOnly
                    return true
        }
        val endPoint = endPoint
        val endPos = coordinate.location(chartPoint = endPoint)
        if (endPoint != null && endPos != null) {
            if (ChartMathUtil.isNearPoints(point1 = touchPos, point2 = endPos, range = config.pointTouchRange)) {
                trendLineState = TrendLineState.moveEndPoint
                        return true
            }
            val distance = ChartMathUtil.distanceFromLine(lineStart = startPos, lineEnd = endPos, point = touchPos)
            if (distance <= config.lineTouchRange) {
                moveOriginTouchPoint = point.copy()
                moveOriginStartPoint = startPoint?.copy()
                moveOriginEndPoint = endPoint.copy()
                trendLineState = TrendLineState.moveLine
                        return true
            }
        }
        return false
    }

    override fun validateTime() : Boolean {
        val chartData = chartData ?: return true
        val oldestTime = chartData.axisValue(0)
        if (oldestTime == null) {
            return true
        }
        val startPoint = startPoint ?: return false
        val startOK = isValidTime(startPoint.time)
        val endPoint = endPoint ?: return startOK
        val timeSpan = timeSpan ?: return false
        val endOK = isValidTime(endPoint.time)
        if (startOK && endOK) {
            return true
        } else if (!startOK && !endOK) {
            return false
        }

        val p1: ChartPoint
        val p2: ChartPoint
        if (endOK) {
            p1 = startPoint
            p2 = endPoint
        } else {
            p1 = endPoint
            p2 = startPoint
        }
        val valueRange = p2.value - p1.value
        val newInterval = coordinate.index(time = p2.time) ?: return false
        val span = Math.abs(timeSpan)
        p1.value = p1.value + valueRange * (1.0 - newInterval.toDouble() / span)
        p1.time = oldestTime
        if (endOK) {
            this.startPoint = p1
        } else {
            this.endPoint = p1
        }
        updateSpan()
        return true
    }
    override val paramDictionary: MutableMap<String, String>
        get() {
            return mutableMapOf("startPoint" to (startPoint?.stringValue ?: ""),
                    "endPoint" to (endPoint?.stringValue ?: ""),
                    "timeSpan" to (timeSpan?.toString() ?: ""))
        }

    override fun importParam(param: Map<String, String>) {
        startPoint = ChartPoint.create(string = param["startPoint"])
        endPoint = ChartPoint.create(string = param["endPoint"])
        timeSpan = param["timeSpan"]?.integerValue
    }


    override fun importHybridParam(param: Map<String, *>) {
        startPoint = ChartPoint.createFromNative(param["startPoint"])
        endPoint = ChartPoint.createFromNative(param["endPoint"])
        timeSpan = (param["timeInterval"] as? Double)?.toInt()
    }

    override val isCompleted: Boolean
        get() {
            return (startPoint != null && endPoint != null)
        }

}