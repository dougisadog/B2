package jp.co.sbibits.base.db.config.classloader

import jp.co.sbibits.base.db.entity.BaseEntity
import kotlin.reflect.KClass

interface BaseEntityClassLoader {
    fun <T : KClass<out BaseEntity>> load(): MutableList<T>
}