package jp.co.sbibits.base.chart.ui

import Formatter
import android.graphics.Bitmap
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.chart.ui.model.item.ChartLegendItem
import jp.co.sbibits.base.chart.ui.model.item.ChartTechnicalParam
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil
import jp.co.sbibits.base.chart.ui.utils.ChartUtil
import jp.co.sbibits.base.extension.*
import jp.co.sbibits.base.chart.ios.*
import java.math.BigDecimal


open class ChartDrawer {
    var chartData: ChartData? = null
    lateinit var setting: ChartSetting

    lateinit var config: ChartConfig
    lateinit var technicalParam: ChartTechnicalParam
    lateinit var context: CGContext
    lateinit var state: ChartState
    lateinit var coordinate: ChartCoordinateService

    lateinit var range: ValueRange
    val isRangeInitialized: Boolean
        get() = ::range.isInitialized

    lateinit var rect: CGRect
    lateinit var fullGraphArea: CGRect

    var needsCalculation = true
    var decimalLength = 0
    val legendLines: MutableList<MutableList<ChartLegendItem>> = mutableListOf()
    var selectedRecordIndex: Int? = null
        set(value) {
            field = value
            resetLegends()
        }

    data class BarConfig(
            var color: UIColor,
            var widthRatio: CGFloat
    ) {}

    enum class DrawCondition {
        stay,
        up,
        down,
        all
    }

    fun prepare() {
        if (needsCalculation) {
            calculate()
            resetLegends()
            needsCalculation = false
        }
    }

    open fun calculate() {}

    open fun updateRange(range: ValueRange) {}

    open fun draw() {}

    // 棒グラフを描画する
    fun drawBar(baseValues: ValueArray, endValues: ValueArray, drawFlags: List<Boolean>? = null, color: UIColor,
                widthScale: CGFloat, condition: DrawCondition = DrawCondition.all) {

        context.saveGState()
        context.clip(to = rect)

        context.setFill(color)

        val valToHeight = rect.size.height / range.width
        val chartBottom = rect.origin.y + rect.size.height
        val barW = state.recordInterval * widthScale
        val xOffset = (state.recordInterval - barW) / 2.0

        context.beginPath()
        var x = state.offsetX
        for (i in state.startIndex..state.endIndex) {
            val base = baseValues[i]
            val end = endValues[i]
            if (base != null && end != null) {
                val flag = drawFlags?.get(i) ?: true
                if (flag &&
                        ((condition == DrawCondition.all) ||
                                (condition == DrawCondition.up && base < end) ||
                                (condition == DrawCondition.down && end < base) ||
                                (condition == DrawCondition.stay && base == end))) {
                    val top = chartBottom - (end - range.min) * valToHeight
                    val bottom = chartBottom - (base - range.min) * valToHeight
                    var height = bottom - top
                    if (height == 0.0) {
                        height = config.lineWidth
                    }
                    context.addRect(CGRect(x = x + xOffset, y = top, width = barW, height = height))
                }
            }

            x += state.recordInterval
        }

        context.fillPath()
        context.restoreGState()
    }

    fun drawStick(baseValues: ValueArray, endValues: ValueArray, openValues: ValueArray, closeValues: ValueArray,
                  drawFlags: List<Boolean>? = null, color: UIColor, condition: DrawCondition = DrawCondition.all) {
        context.saveGState()
        context.clip(to = rect)
        context.setStroke(color)
        val valToHeight = rect.size.height / range.width
        val chartBottom = rect.origin.y + rect.size.height
        val halfInterval = state.recordInterval / 2.0
        val points: MutableList<CGPoint> = mutableListOf()

        var width = config.highLowStickWidth
        width = Math.min(width, state.recordInterval * config.candleWidthRate * 0.5)

        context.setLineWidth(width)

        context.beginPath()
        var x = state.offsetX
        for (i in state.startIndex..state.endIndex) {
            val base = baseValues[i]
            val end = endValues[i]
            val open = openValues[i]
            val close = closeValues[i]
            if (base != null && end != null && open != null && close != null) {
                val flag = drawFlags?.get(i) ?: true
                if (flag && ((condition == DrawCondition.all) ||
                                (condition == DrawCondition.up && open < close) ||
                                (condition == DrawCondition.down && close < open) ||
                                (condition == DrawCondition.stay && close == open))) {
                    val top = chartBottom - (end - range.min) * valToHeight
                    val bottom = chartBottom - (base - range.min) * valToHeight

                    val stickX = x + halfInterval
                    points += listOf(CGPoint(x = stickX, y = top))
                    points += listOf(CGPoint(x = stickX, y = bottom))

                    context.addLines(between = points)
                    points.removeAll()
                }
            }
            x += state.recordInterval
        }
        context.strokePath()
        context.restoreGState()
    }

    fun drawLineChart(dataType: ChartDataType, color: UIColor) {
        val chartData = chartData ?: return
        drawLineChart(dataList = chartData[dataType], color = color)
    }

    fun drawLineChart(dataList: ValueArray, color: UIColor) {
        val valueToHeight = rect.height / range.width
        context.saveGState()
        context.setShouldAntialias(true)
        context.clip(to = rect)
        context.setLineWidth(config.lineChartWidth)
        context.setStroke(color)
        context.beginPath()
        var x = state.offsetX + state.recordInterval / 2.0
        val points: MutableList<CGPoint> = mutableListOf()
        for (i in state.startIndex..state.endIndex + 1) {
            val value = dataList[i]
            if (value != null && !value.isNaN()) {
                val y = rect.maxY - (value - range.min) * valueToHeight
                points += listOf(CGPoint(x = x, y = y))
            } else if (0 < points.size) {
                context.addLines(between = points)
                points.removeAll()
            }
            x += state.recordInterval
        }
        if (2 <= points.size) {
            context.addLines(between = points)
        }
        context.strokePath()
        context.restoreGState()
    }

    fun drawPriceNowLine(price: CGFloat?) {
        drawPriceLine(price = price, color = config.currentPriceLineColor, isDot = true, markerImage = ChartImageHolder.priceMarkerOrange, dragging = false)
    }

    fun drawSelectedPriceLine(price: CGFloat?, dragging: Boolean = false) {
        drawPriceLine(price = price, color = config.indicatorLineColor, isDot = false, markerImage = ChartImageHolder.priceMarkerPurple, dragging = dragging)
    }

    fun drawPriceLine(price: CGFloat?, color: UIColor, isDot: Boolean, markerImage: Bitmap?, dragging: Boolean) {
        if (null == price) return
        if (!range.contains(value = price)) {
            return
        }

        context.saveGState()
        val y = coordinate.yPosition(price = price) ?: return
        val x = rect.size.width + config.leftMargin
        if (rect.minY <= y && y <= rect.maxY) {
            context.setLineWidth(config.lineWidth)
            context.setStroke(color)
            if (isDot) {
                context.setLineDash(phase = 0, lengths = listOf(config.lineDashSize, config.lineDashSize))
            }
            context.beginPath()
            context.move(to = CGPoint(x = rect.minX, y = y))
            context.addLine(to = CGPoint(x = rect.maxX + 1, y = y))
            context.strokePath()
            val text = Formatter.number(price, decimalLength = decimalLength)
            val font = if ((8 < text.size)) config.yScaleSmallFont else config.yScaleFont

            val fontHeight = text.size(font).height
            val fontHeightHalf = fontHeight / 2.0
            if (markerImage != null) {
                val imageWidth = config.yScaleAreaWidth
                val imageHeight = imageWidth * markerImage.height / markerImage.width
                context.drawImage(markerImage, rect = CGRect(x = x, y = y - imageHeight / 2, width = imageWidth, height = imageHeight))
            }
            context.drawTextInRect(text = text, rect = CGRect(x = rect.maxX + config.yScaleFontPadding, y = y - fontHeightHalf, width = config.yScaleAreaWidth, height = fontHeight),
                    font = font, color = config.scaleFontColor)
            if (dragging) {
                val dragFont = config.draggingNumberFont
                val textSize = text.size(dragFont)
                val dragFontHeightHalf = textSize.height / 2.0
                val centerX = rect.size.width / 2.0
                val fontX = centerX - textSize.width / 2.0
                val fontY = y - dragFontHeightHalf
                context.drawText(text = text, point = CGPoint(x = fontX, y = fontY), font = dragFont, color = config.scaleFontColor)
            }
        }
        context.restoreGState()
    }

    fun drawHorizontalLine(price: CGFloat?, color: UIColor) {
        if (price == null) {
            return
        }
        val y = coordinate.yPosition(price = price) ?: return
        context.saveGState()
        if (rect.minY <= y && y <= rect.maxY) {
            context.setLineWidth(config.lineWidth)
            context.setStroke(color)
            context.beginPath()
            context.move(to = CGPoint(x = rect.minX, y = y))
            context.addLine(to = CGPoint(x = rect.maxX + 1, y = y))
            context.strokePath()
        }
        context.restoreGState()
    }

    fun drawSelectedTimeLine(index: Int?, dragging: Boolean, timeList: List<String?>?) {
        drawTimeLine(index = index, color = config.indicatorLineColor, markerImage = ChartImageHolder.timeMarkerPurple, dragging = dragging, timeList = timeList)
    }

    fun drawTimeLine(index: Int?, color: UIColor, markerImage: Bitmap, dragging: Boolean = false, timeList: List<String?>? = null) {
        val chartData = chartData
        if (index == null || chartData == null) {
            return
        }
        if (index < state.startIndex || state.endIndex < index) {
            return
        }
        val x = coordinate.xPosition(index = index) ?: return

        val rect = fullGraphArea
        if (x < rect.minX || rect.maxX < x) {
            return
        }
        context.saveGState()
        context.setLineWidth(config.lineWidth)
        context.setStroke(color)
        context.beginPath()
        context.move(to = CGPoint(x = x, y = rect.minY))
        context.addLine(to = CGPoint(x = x, y = rect.maxY))
        context.strokePath()
        val height = config.xScaleAreaHeight
        val width = height * markerImage.width / markerImage.height
        context.drawImage(markerImage, rect = CGRect(x = x - width / 2, y = rect.maxY, width = width, height = height))
        var timeString: String? = null
        if (timeList != null) {
            if (0 <= index && index < timeList.size) {
                timeString = timeList[index]
            }
        } else {
            timeString = chartData.axisValue(index)
        }
        if (timeString != null) {
            val timeText = ChartUtil.timeToString(timeString, ashi = setting.ashiType)
            val font = config.xScaleFont
            val textSize = timeText.size(font)
            val fontMargin = (config.xScaleAreaHeight - textSize.height) / 2
            context.drawTextInRect(timeText, rect = CGRect(x = x - (textSize.width / 2.0), y = rect.maxY + fontMargin, width = textSize.width, height = textSize.height),
                    font = font, color = config.scaleFontColor)
            if (dragging) {
                val dragTimeText = ChartUtil.detailedTimeString(timeString, ashi = setting.ashiType)
                val dragFont = config.draggingNumberFont
                val dragTextSize = dragTimeText.size(dragFont)
                context.drawText(dragTimeText, point = CGPoint(x = x - (dragTextSize.width / 2), y = rect.maxY / 2), font = dragFont, color = config.scaleFontColor)
            }
        }
        context.restoreGState()
    }

    fun drawHorizontalLine(price: CGFloat, color: UIColor, caption: String?) {
        val valueToHeight = rect.height / range.width
        context.saveGState()
        context.setShouldAntialias(false)
        context.clip(to = rect)
        context.setLineWidth(config.lineWidth)
        context.setStroke(color)
        val y = rect.maxY - (price - range.min) * valueToHeight
        context.move(to = CGPoint(x = rect.minX, y = y))
        context.addLine(to = CGPoint(x = rect.maxX, y = y))
        context.strokePath()
        if (caption != null) {
            context.setShouldAntialias(true)
            val font = config.lineCaptionFont
            val textSize = caption.size(font)
            context.drawText(caption, CGPoint(x = rect.maxX - textSize.width, y = y), font = font, color = config.scaleFontColor)
        }
        context.restoreGState()
    }

    // 線グラフを塗りつぶす
    fun fillArea(dataList1: ValueArray, dataList2: ValueArray, color: UIColor) {

        val valueToHeight = rect.height / range.width

        context.saveGState()
        context.setShouldAntialias(true)
        context.clip(to = rect)
        context.setFill(color)

        // 描画開始
        context.beginPath()

        var x = state.offsetX + state.recordInterval / 2.0
        var points: List<CGPoint> = listOf()
        val indicies = state.startIndex .. state.endIndex + 1
        for (i in indicies) { // 右端足の一つ先まで描画する必要がある
            val value1 = dataList1[i]
            if (value1 != null && dataList2[i] != null) {
                val y = rect.maxY - (value1 - range.min) * valueToHeight
                points += listOf(CGPoint(x = x, y = y))
            }

            x += state.recordInterval
        }

        x -= state.recordInterval

        for (i in indicies.reversed()) { // 右端足の一つ先まで描画する必要がある
            val value2 = dataList2[i]
            if (value2 != null && dataList1[i] != null) {
                val y = rect.maxY - (value2 - range.min) * valueToHeight
                points += listOf(CGPoint(x = x, y = y))
            }

            x -= state.recordInterval
        }

        // 塗りつぶし
        if (2 <= points.size) {
            context.addLines(between = points)
            context.fillPath()
        }

        context.restoreGState()
    }

    fun drawDots(dataList: ValueArray, color: UIColor) {
        val valueToHeight = rect.height / range.width
        context.saveGState()
        context.setShouldAntialias(true)
        context.clip(to = rect)
        context.setFill(color)
        context.beginPath()
        var x = state.offsetX + state.recordInterval / 2.0
        var points: List<CGPoint> = listOf()
        for (i in state.startIndex..state.endIndex) {
            val value = dataList[i]
            if (value != null) {
                val y = rect.maxY - (value - range.min) * valueToHeight
                context.addEllipse(rect = CGRect(x = x - 1, y = y - 1, width = 2.0, height = 2.0))
                points += listOf(CGPoint(x = x, y = y))
            }
            x += state.recordInterval
        }
        context.fillPath()
        context.restoreGState()
    }

    fun drawPoint(point: CGPoint, isSelected: Boolean) {
        val size: CGFloat = config.pointSize
        context.saveGState()
        context.clip(to = rect)
        context.beginPath()
        val colors: MutableList<UIColor> = mutableListOf(config.pointInsideColor)
        if (isSelected) {
            colors.append(UIColor(red = 1.0, green = 1.0, blue = 0.39, alpha = 1.0))
            colors.append(config.pointOutsideColor)
        } else {
            colors.append(UIColor(red = 0.39, green = 0.39, blue = 0.39, alpha = 1.0))
            colors.append(config.pointOutsideColor2)
        }
        context.drawRadialGradient(colors, center = point, radius = size)
        context.restoreGState()
    }

    fun drawHalfLine(start: CGPoint, end: CGPoint, isSelected: Boolean) {
        context.saveGState()
        context.setShouldAntialias(true)
        context.beginPath()
        context.clip(to = rect)
        if (isSelected) {
            context.setStroke(config.selectedCustomLineColor)
        } else {
            context.setStroke(config.customLineColor)
        }
        context.setLineWidth(config.lineWidth)
        context.beginPath()
        context.move(to = start)
        context.addLine(to = end)
        context.strokePath()
        if (start.x != end.x || start.y != end.y) {
            val dashEndPos = ChartMathUtil.lineContactPoint(start = start, end = end, rect = rect)
            context.setLineDash(phase = 0, lengths = listOf(config.lineDashSize, config.lineDashSize))
            context.beginPath()
            context.move(to = end)
            context.addLine(to = dashEndPos)
            context.strokePath()
        }
        context.restoreGState()
    }

    fun drawXScales(timeList: List<String>?) {
        if (null == timeList) return
        context.saveGState()
        context.setShouldAntialias(true)
        context.setLineWidth(config.gridLineWidth)
        context.beginPath()
        var preDate: String? = timeList.safeGet(state.startIndex - 1)
        val indexList = (state.startIndex..state.endIndex).map { index ->
            var result: Int? = null
            var time: String? = null
            if (0 <= index && index < timeList.size) {
                time = timeList[index]
            }
            if (time != null && ChartUtil.isEnableAxis(ashiType = setting.ashiType, date = time, preDate = preDate)) {
                result = index
            }
            preDate = time
            return@map result
        }.filterNotNull()

        val baseX = state.offsetX + state.recordInterval / 2
        var preIndex: Int? = null
        indexList.reversed().forEach { index ->
            val x = baseX + (index - state.startIndex) * state.recordInterval

            if (x <= rect.maxX) {
                val points = listOf(CGPoint(x = x, y = rect.minY), CGPoint(x = x, y = rect.maxY))
                context.addLines(between = points)
                var time: String? = null
                if (0 <= index && index < timeList.size) {
                    time = timeList[index]
                }

                val timeText = ChartUtil.timeToString(time, ashi = setting.ashiType)
                val textSize = timeText.size(config.xScaleFont)
                if (preIndex == null || (textSize.width * 1.15 < (preIndex!! - index) * state.recordInterval)) {
                    val fontX = x - textSize.width / 2.0
                    val fontY = rect.maxY + (config.xScaleAreaHeight - textSize.height) / 2
                    context.drawText(timeText, CGPoint(x = fontX, y = fontY), font = config.xScaleFont, color = config.scaleFontColor)
                    preIndex = index
                }
            }
        }
        context.setStroke(config.gridColor)
        context.strokePath()
        context.restoreGState()
    }

    open fun drawYScales(minLineNumber: Int, adjustTopFont: Boolean = false, adjustBottomFont: Boolean = false): Int {
        if (!range.isValid) return 0

        context.saveGState()
        context.setShouldAntialias(true)
        context.setLineWidth(config.gridLineWidth)

        // 目盛間隔を計算
        val interval = ChartMathUtil.calcScaleInterval(range = range, minLineNumber = minLineNumber)
        // 一番下のライン位置を計算
        val minRemainder = BigDecimal.valueOf(range.min).remainder(BigDecimal.valueOf(interval))
        var gridMin = BigDecimal(range.min) - minRemainder
        if (BigDecimal.ZERO < minRemainder) {
            gridMin += BigDecimal.valueOf(interval)
        }

        val decimalLength = ChartMathUtil.scaleDecimalLength(interval = interval)
        val valToHeight = rect.height / range.width

        context.setFill(config.scaleFontColor)
        context.beginPath()

        var max = gridMin.toDouble()
        while (max <= range.max) {
            max += interval
        }
        val maxText = Formatter.number(max, decimalLength = decimalLength)
        var font = config.yScaleFont
        var width = maxText.size(font).width
        while (config.yScaleAreaWidth - config.yScaleFontPadding < width) {
            font = font.withSize(font.size - 1.0)
            width = maxText.size(font).width
            if (font.size <= 5) {
                break
            }
        }

        val points: MutableList<CGPoint> = mutableListOf()
        var value = gridMin.toDouble()
        var isBottom = true
        while (value <= range.max) {
            val isTop = (range.max < value + interval)
            val y = rect.maxY - (value - range.min) * valToHeight
            points.append(CGPoint(x = rect.minX, y = y))
            points.append(CGPoint(x = rect.maxX, y = y))
            context.addLines(between = points)

            if (rect.minY <= y && y <= rect.maxY) {
                val text = Formatter.number(value, decimalLength = decimalLength)
                val fontSize = text.size(font)
                val fontY: CGFloat
                if (isTop && adjustTopFont) {
                    fontY = y
                } else if (isBottom && adjustBottomFont) {
                    fontY = y - fontSize.height
                } else {
                    fontY = y - fontSize.height / 2
                }

                context.drawText(text = text, point = CGPoint(x = rect.maxX + config.yScaleFontPadding, y = fontY), font = font, color = config.scaleFontColor)
            }
            points.removeAll()
            value += interval
            isBottom = false
        }

        context.setStroke(config.gridColor)
        context.strokePath()
        context.restoreGState()
        return decimalLength
    }

    fun drawFrame() {
        context.saveGState()
        context.setLineWidth(config.lineWidth)
        context.setShouldAntialias(false)
        context.beginPath()
        context.setStroke(config.frameBorderColor)
        val points: MutableList<CGPoint> = mutableListOf()
        points.append(CGPoint(x = rect.minX, y = rect.minY))
        points.append(CGPoint(x = rect.maxX, y = rect.minY))
        points.append(CGPoint(x = rect.maxX, y = rect.maxY))
        points.append(CGPoint(x = rect.minX, y = rect.maxY))
        context.addLines(between = points)
        context.strokePath()
        context.restoreGState()
    }

    fun drawTopBorder() {
        context.saveGState()
        context.setLineWidth(config.lineWidth)
        context.setShouldAntialias(false)
        context.beginPath()
        context.setStroke(config.frameBorderColor)
        val points: MutableList<CGPoint> = mutableListOf()
        points.append(CGPoint(x = rect.minX, y = rect.minY))
        points.append(CGPoint(x = rect.maxX, y = rect.minY))
        context.addLines(between = points)
        context.strokePath()
        context.restoreGState()
    }

    open fun addLegend() {}

    fun addLegendValue(title: String, dataType: ChartDataType, color: UIColor, decimalLength: Int? = null) {
        val chartData = chartData ?: return
        val values = chartData[dataType]
        val index = selectedRecordIndex ?: chartData.count - 1
        var text = config.emptyMark
        val value = values[index]
        if (value != null) {
            text = Formatter.number(value, decimalLength = decimalLength ?: this.decimalLength)
        }
        addLegendItem(text = "${title}:${text}", color = color)
    }

    fun addLegendItem(text: String, color: UIColor) {
        if (legendLines.size == 0) {
            addLegendLine()
        }
        val item = ChartLegendItem(text = text, color = color)
        legendLines[legendLines.size - 1].append(item)
    }

    fun addLegendLine() {
        legendLines.append(mutableListOf<ChartLegendItem>())
    }

    fun resetLegends() {
        legendLines.removeAll()
        addLegend()
    }

}
