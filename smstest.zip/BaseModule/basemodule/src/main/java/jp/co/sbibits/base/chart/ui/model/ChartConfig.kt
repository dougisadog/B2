package jp.co.sbibits.base.chart.ui.model

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.ios.UIFont
import jp.co.sbibits.base.util.DeviceUtils

class ChartConfig {
    var topMargin: CGFloat = 0.0
    var bottomMargin: CGFloat = 0.0
    var leftMargin: CGFloat = 0.0
    var rightMargin: CGFloat = 0.0
    var defaultRecordInterval: CGFloat = size(4.85)
    var minRecordInterval: CGFloat = size(3.0)
    var maxRecordInterval: CGFloat = size(60.0)
    var yScaleAreaWidth: CGFloat = size(52.0)
    var xScaleAreaHeight: CGFloat = size(19.0)
    var yScaleFontPadding: CGFloat = size(5.0)
    var subChartHeightRate: CGFloat = 0.2
    var fontName = "HelveticaNeue"
    var xScaleFontSize: CGFloat = size(11.0)
    var yScaleFontSize: CGFloat = size(11.0)
    var yScaleFontSmallSize: CGFloat = size(8.0)
    var turningPointFontSize: CGFloat = size(11.0)
    var legendFontSize: CGFloat = size(11.0)
    var draggingNumberFontSize: CGFloat = size(20.0)
    var lineCaptionFontSize: CGFloat = size(11.0)
    var pointTouchRange: CGFloat = size(20.0)
    var lineTouchRange: CGFloat = size(10.0)
    var horizontalLineTouchRange: CGFloat = size(15.0)
    var magnetTouchRange: CGFloat = size(20.0)

    var isLegendEnabled = true
    var scrollMargin: CGFloat = size(60.0)
    var initialScrollOffset: CGFloat = 100.0
    var emptyMark: String = "--"
    var legendMargin: CGFloat = size(5.0)
    var isDrawingItemEnabled = true
    var isScrollEnabled = true
    var isTouchIndicatorEnabled = true
    var isTimeAreaEnabled = true
    var isScaleAreaEnabled = true
    var isChartFillEnabled = false
    var isCandleEnabled = true
    var isLineChartEnabled = false
    var mainLegendLeftMargin: CGFloat = size(25.0)
    var subLegendLeftMargin: CGFloat = size(25.0)
    var isVolumeLessCandleEnabled: Boolean = true
    var timeLineTouchMargin: CGFloat = size(10.0)
    var swipeAreaHeightRate: CGFloat = 0.33
    var swipeSideWidth: CGFloat = size(25.0)
    var gridLineWidth: CGFloat = size(0.5)
    var lineChartWidth: CGFloat = size(1.0)
    var lineWidth: CGFloat = size(1.0)
    var highLowStickWidth: CGFloat = size(2.0)
    var lineDashSize: CGFloat = size(5.0)
    // ローソク足の幅の割合
    var candleWidthRate: CGFloat = 0.8
    // メインチャートY軸の最低本数
    var mainYScaleMinLineNumber = 3
    // サブチャートY軸の最低本数
    var subYScaleMinLineNumber = 2

    var pointSize: CGFloat = size(8.0)
    var pointInsideColor = UIColor.white
    var pointOutsideColor = UIColor.orange
    var pointOutsideColor2 = UIColor.gray
    // MARK: - Colors
    var backgroundColor = UIColor.black
    var graphAreaBackgroundColor = UIColor(rgbValue = 0x171a26)
//    var graphAreaBackgroundColor = UIColor.white

    var scaleFontColor: UIColor = UIColor.white
    var currentPriceLineColor = UIColor(rgbValue = 0xEEBB02)
    var frameBorderColor = UIColor(rgbValue = 0x959595, alpha = 0.8)
    var gridColor = UIColor(rgbValue = 0x686868)
    var indicatorLineColor = UIColor(rgbValue = 0x9c00e9)
    var customLineColor = UIColor(rgbValue = 0xffffff)
    var selectedCustomLineColor = UIColor(rgbValue = 0xffa500)

    val animeTime = 3000.0
    var animeEnable = false
    var animeFramesPerSecond = 120

    /**
     * task state
     */
    enum class AnimeState {
        START,
        RUNNING,
        FINISH;
    }

    // MARK: - Fonts
    val xScaleFont: UIFont
        get() {
            return makeFont(name = fontName, size = xScaleFontSize)
        }
    val yScaleFont: UIFont
        get() {
            return makeFont(name = fontName, size = yScaleFontSize)
        }
    val yScaleSmallFont: UIFont
        get() {
            return makeFont(name = fontName, size = yScaleFontSmallSize)
        }
    val turningPointFont: UIFont
        get() {
            return makeFont(name = fontName, size = turningPointFontSize)
        }
    val legendFont: UIFont
        get() {
            return makeFont(name = fontName, size = legendFontSize)
        }
    val draggingNumberFont: UIFont
        get() {
            return makeFont(name = fontName, size = draggingNumberFontSize)
        }
    val lineCaptionFont: UIFont
        get() {
            return makeFont(name = fontName, size = lineCaptionFontSize)
        }

    fun size(value: Double): CGFloat {
        return DeviceUtils.toPx(value).toDouble()
    }

    fun makeFont(name: String, size: CGFloat): UIFont {
        return UIFont(name = name, size = size)
    }
}
