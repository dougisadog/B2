package jp.co.sbibits.base.chart.ui.drawer.main

import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil

/**
 * 移動平均線
 */
class SMADrawer : ChartDrawer() {
    private val sma1Color = UIColor(rgbValue = 0xe5e645)
    private val sma2Color = UIColor(rgbValue = 0xe66d45)
    private val sma3Color = UIColor(rgbValue = 0x17e693)


    override fun calculate() {
        val chartData = chartData ?: return
        val closeList = chartData[ChartDataType.CLOSE]
        if (technicalParam.sma1On) {
            val span = technicalParam.sma1Span
            val smaList = ChartMathUtil.calcSMA(src = closeList, span = span)
            chartData[ChartDataType.SMA1] = smaList
        }
        if (technicalParam.sma2On) {
            val span = technicalParam.sma2Span
            val smaList = ChartMathUtil.calcSMA(src = closeList, span = span)
            chartData[ChartDataType.SMA2] = smaList
        }
        if (technicalParam.sma3On) {
            val span = technicalParam.sma3Span
            val smaList = ChartMathUtil.calcSMA(src = closeList, span = span)
            chartData[ChartDataType.SMA3] = smaList
        }
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        val chartData = chartData ?: return
        val sma1On = technicalParam.sma1On
        val sma2On = technicalParam.sma2On
        val sma3On = technicalParam.sma3On
        for (i in state.indices) {
            if (sma1On) {
                range.update(chartData[ChartDataType.SMA1][i])
            }
            if (sma2On) {
                range.update(chartData[ChartDataType.SMA2][i])
            }
            if (sma3On) {
                range.update(chartData[ChartDataType.SMA3][i])
            }
        }
    }

    override fun draw() {
        if (technicalParam.sma1On) {
            drawLineChart(dataType = ChartDataType.SMA1, color = sma1Color)
        }
        if (technicalParam.sma2On) {
            drawLineChart(dataType = ChartDataType.SMA2, color = sma2Color)
        }
        if (technicalParam.sma3On) {
            drawLineChart(dataType = ChartDataType.SMA3, color = sma3Color)
        }
    }

    override fun addLegend() {
        if (technicalParam.sma1On) {
            addLegendValue(title = "短期", dataType = ChartDataType.SMA1, color = sma1Color)
        }
        if (technicalParam.sma2On) {
            addLegendValue(title = "中期", dataType = ChartDataType.SMA2, color = sma2Color)
        }
        if (technicalParam.sma3On) {
            addLegendValue(title = "長期", dataType = ChartDataType.SMA3, color = sma3Color)
        }
    }

}