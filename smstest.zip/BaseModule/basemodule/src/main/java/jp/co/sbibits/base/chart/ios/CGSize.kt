package jp.co.sbibits.base.chart.ios

import jp.co.sbibits.base.CGFloat

data class CGSize(var width: CGFloat, var height: CGFloat) {
    companion object {
        val zero: CGSize get() = CGSize(0.0, 0.0)
    }
}