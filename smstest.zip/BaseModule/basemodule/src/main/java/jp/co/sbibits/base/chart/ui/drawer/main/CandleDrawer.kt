package jp.co.sbibits.base.chart.ui.drawer.main

import jp.co.sbibits.base.chart.ios.UIColor
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.*

// ローソク足
class CandleDrawer: ChartDrawer() {

    private val upColor = UIColor(rgbValue = 0xfe3301)
    private val downColor = UIColor(rgbValue = 0x00cc02)
    private val stayColor = UIColor.white
    private val fillColor = UIColor(white = 1.0, alpha = 0.4)

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        val chartData = chartData ?: return
        val lastIndex = chartData.lastIndex ?: return

        val indices = if (setting.isVolumePerPriceEnabled) (0 .. lastIndex) else state.indices
        for (i in indices) {
            range.update(chartData[ChartDataType.HIGH][i])
        }
        for (i in indices) {
            range.update(chartData[ChartDataType.LOW][i])
        }
    }

    override fun draw() {
        val chartData = chartData ?: return
        val open = chartData[ChartDataType.OPEN]
        val close = chartData[ChartDataType.CLOSE]
        val high = chartData[ChartDataType.HIGH]
        val low = chartData[ChartDataType.LOW]

        var drawFlags: List<Boolean>? = null
        if (!config.isVolumeLessCandleEnabled) {
            drawFlags = chartData[ChartDataType.VOLUME].map { (0 < (it ?: 0.0)) }
        }

        // 上昇
        drawStick(baseValues = high, endValues = low, openValues = open, closeValues = close, drawFlags = drawFlags, color = upColor, condition = DrawCondition.up)
        drawBar(baseValues = open, endValues = close, drawFlags = drawFlags, color = upColor, widthScale = config.candleWidthRate, condition = DrawCondition.up)

        // 下降
        drawStick(baseValues = high, endValues = low, openValues = open, closeValues = close, drawFlags = drawFlags, color = downColor, condition = DrawCondition.down)
        drawBar(baseValues = open, endValues = close, drawFlags = drawFlags, color = downColor, widthScale = config.candleWidthRate, condition = DrawCondition.down)

        // 変わらず
        drawStick(baseValues = high, endValues = low, openValues = open, closeValues = close, drawFlags = drawFlags, color = stayColor, condition = DrawCondition.stay)
        drawBar(baseValues = open, endValues = close, drawFlags = drawFlags, color = stayColor, widthScale = config.candleWidthRate, condition = DrawCondition.stay)
    }

    fun fillLine() {
        val chartData = chartData ?: return
        val close = chartData[ChartDataType.CLOSE]
        val zeroList = ValueArray(array = close.indicies.map { _  ->
            range.min
        }.toMutableList())
        fillArea(dataList1 = close, dataList2 = zeroList, color = fillColor)
    }
}
