package jp.co.sbibits.base.db

import android.content.Context
import android.util.Log
import jp.co.sbibits.base.db.config.DBConfig
import jp.co.sbibits.base.db.config.DBType
import jp.co.sbibits.base.db.dao.DaoCache
import jp.co.sbibits.base.db.entity.BaseEntity
import jp.co.sbibits.base.db.extension.getSQLColumn
import jp.co.sbibits.base.db.extension.getTableName
import jp.co.sbibits.base.db.realm.RealmManager
import jp.co.sbibits.base.db.sqlite.SQLiteDbHelper
import kotlin.reflect.KClass
import kotlin.reflect.KProperty1
import kotlin.reflect.full.createInstance


object DBManger {
    const val DATABASE_ORIGIN_VERSION = 1

    // If you change the database schema, you must increment the database version.
    var DATABASE_VERSION = DATABASE_ORIGIN_VERSION
    var DATABASE_NAME = ""

    //cache all table class
    val entityClass = mutableListOf<KClass<out BaseEntity>>()

    //cache all column  map by table name
    val cacheProperties = hashMapOf<String, List<KProperty1<*, *>>>()

    const val TAG = "DB"

    const val EXCEPTION_STACK = true

    lateinit var DB_TYPE: DBType

    fun printStack(e: Exception) {
        if (EXCEPTION_STACK) {
            e.printStackTrace()
        }
    }

    fun log(message: String) {
        Log.e(TAG, message)
    }

    fun init(context: Context, config: DBConfig) {
        DATABASE_NAME = config.name
        DATABASE_VERSION = config.version
        DB_TYPE = config.defaultDBType
        config.clazzes.forEach { clazz ->
            entityClass.add(clazz)
            cacheProperties[clazz.getTableName()] = clazz.getSQLColumn()
        }
        config.sqliteConfig?.let {
            SQLiteDbHelper.init(context, config)
        }
        config.realmConfig?.let {
            RealmManager.init(context, it.module, config)
        }
    }

    /**
     * move the data between different DBType
     */
    fun moveData(source: DBType, target: DBType) {
        if (source == target) {
            log("move the data failed when source and target DBType are the same:${source.name}")
            return
        }
        try {
            entityClass.forEach {
                val clazz = it as KClass<BaseEntity>
                val sourceDao = DaoCache.get(source, clazz)
                val targetDao = DaoCache.get(target, clazz)
                val data = sourceDao.query(clazz.createInstance())
                targetDao.async({
                    targetDao.runTransaction {
                        targetDao.save(data)
                        true
                    }
                })
            }
        } catch (e: Exception) {
            log("move the data failed from ${source.name} to ${target.name} error:${e.message}")
        }
    }

}

/**
 * default error catcher
 * @param errorMessage default error message as if there's any exception
 */
fun <T> tryBlock(errorMessage: String, finalBlock: (() -> Unit)? = null, block: () -> T): T? {
    return try {
        block.invoke()
    } catch (e: Exception) {
        DBManger.printStack(e)
        DBManger.log(errorMessage + " error:${e.message}")
        null
    } finally {
        finalBlock?.invoke()
    }
}