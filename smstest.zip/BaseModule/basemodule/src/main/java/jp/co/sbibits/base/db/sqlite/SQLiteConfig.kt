package jp.co.sbibits.base.db.sqlite

class SQLiteConfig