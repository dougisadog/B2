package jp.co.sbibits.base.chart.ui.drawer.sub

import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ui.ChartBaseConfig
import jp.co.sbibits.base.chart.ui.ChartDrawer
import jp.co.sbibits.base.chart.ui.model.*
import jp.co.sbibits.base.chart.ui.utils.ChartMathUtil

/**
 * MACD
 */
class MACDDrawer: ChartDrawer() {
    private val macdColor = ChartBaseConfig.MACD_macdColor
    private val signalColor = ChartBaseConfig.MACD_signalColor
    private val oscPlusColor = ChartBaseConfig.MACD_oscPlusColor
    private val oscMinusColor = ChartBaseConfig.MACD_oscMinusColor
    private var yScaleDecimalLength: Int = ChartBaseConfig.MACD_yScaleDecimalLength

    override fun calculate() {
        val chartData = chartData ?: return
        val shortSpan = technicalParam.macdShortSpan
        val longSpan = technicalParam.macdLongSpan
        val closeList = chartData[ChartDataType.CLOSE]
        val emaShortList = ChartMathUtil.calcEMA(src = closeList, span = shortSpan)
        val emaLongList = ChartMathUtil.calcEMA(src = closeList, span = longSpan)
        val macdList = ValueArray()
        for (i in emaShortList.indicies) {
            var macd: CGFloat? = null
            val emaShort = emaShortList[i]
            val emaLong = emaLongList[i]
            if (emaShort != null && emaLong != null) {
                macd = emaShort - emaLong
            }
            macdList.append(macd)
        }
        chartData[ChartDataType.MACD] = macdList
        val signalSpan = technicalParam.macdSignalSpan
        val signalList = ChartMathUtil.calcEMA(src = macdList, span = signalSpan)
        chartData[ChartDataType.MACD_SIGNAL] = signalList
        val oscList = ValueArray()
        for (i in macdList.indicies) {
            var osc: CGFloat? = null
            val macd = macdList[i]
            val signal = signalList[i]
            if (macd != null && signal != null) {
                osc = macd - signal
            }
            oscList.append(osc)
        }
        chartData[ChartDataType.MACD_OSC] = oscList
    }

    override fun updateRange(range: ValueRange) {
        super.updateRange(range)
        val chartData = chartData ?: return
        range.update(0.0)
        val macd = chartData[ChartDataType.MACD]
        val macdOsc = chartData[ChartDataType.MACD_OSC]
        val macdSignal = chartData[ChartDataType.MACD_SIGNAL]
        val signalOn = technicalParam.macdSignalOn
        for (i in state.indices) {
            range.update(macd[i])
            range.update(macdOsc[i])
            if (signalOn) {
                range.update(macdSignal[i])
            }
        }
        range.scale(1.2)
    }

    override fun draw() {
        val chartData = chartData ?: return
        drawLineChart(dataType = ChartDataType.MACD, color = macdColor)
        if (technicalParam.macdSignalOn) {
            drawLineChart(dataType = ChartDataType.MACD_SIGNAL, color = signalColor)
        }
        val oscList = chartData[ChartDataType.MACD_OSC]
        val zeroList = ValueArray(array = oscList.indicies.map { _  ->
            0.0
        }.toMutableList())
        drawBar(baseValues = zeroList, endValues = oscList, color = oscPlusColor, widthScale = 0.6, condition = DrawCondition.up)
        drawBar(baseValues = zeroList, endValues = oscList, color = oscMinusColor, widthScale = 0.6, condition = DrawCondition.down)
    }

    override fun drawYScales(minLineNumber: Int, adjustTopFont: Boolean, adjustBottomFont: Boolean) : Int {
        yScaleDecimalLength = super.drawYScales(minLineNumber = minLineNumber, adjustTopFont = adjustTopFont, adjustBottomFont = adjustBottomFont)
        // Y軸目盛の小数桁数により凡例の小数桁数が変わるので、凡例を再設定する
        resetLegends()
        return yScaleDecimalLength
    }

    override fun addLegend() {
        val decimalLength = legendDecimalNumber()

        addLegendValue(title = "MACD", dataType = ChartDataType.MACD, color = macdColor, decimalLength = decimalLength)
        if (technicalParam.macdSignalOn) {
            addLegendValue(title = "シグナル", dataType = ChartDataType.MACD_SIGNAL, color = signalColor, decimalLength = decimalLength)
        }
    }

    // 凡例の小数桁数
    private fun legendDecimalNumber(): Int {
        if (!isRangeInitialized || !range.isValid) {
            return 0
        }
        if (2 <= yScaleDecimalLength) {
            return yScaleDecimalLength
        }

        val interval = ChartMathUtil.calcScaleInterval(range = range, minLineNumber = config.subYScaleMinLineNumber)

        if (100 <= interval) {
            return 0
        } else if (10 <= interval) {
            return 1
        } else {
            return 2
        }
    }
}
