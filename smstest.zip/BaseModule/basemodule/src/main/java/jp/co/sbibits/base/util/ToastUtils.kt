package jp.co.sbibits.base.util

import android.content.Context
import android.widget.Toast
import jp.co.sbibits.base.ContextManager

/**
 * トースト表示
 */
object ToastUtils {

    /**
     * トーストを短時間表示する
     * @param context コンテキスト
     * @param msg 表示メッセージ
     */
    fun showShortMessage(context: Context, msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    /**
     * トーストを長時間表示する
     * @param context コンテキスト
     * @param msg 表示メッセージ
     */
    fun showLongMessage(context: Context, msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
    }

    /**
     * トーストを表示する
     * @param msg 表示メッセージ
     */
    fun showMessage(msg: String) {
        if (ContextManager.getContext() == null) return
        Toast.makeText(ContextManager.getContext(), msg, Toast.LENGTH_SHORT).show()
    }

}