package jp.co.sbibits.base.db.realm

import io.realm.RealmModel
import io.realm.RealmQuery
import jp.co.sbibits.base.db.DBManger
import kotlin.reflect.KProperty1

/**
 * property type helper for Realm
 */
class RealmTypeHelper<RE : RealmModel>(val p: KProperty1<*, *>) {

    private var queryTask: ((RealmQuery<RE>, Any) -> RealmQuery<RE>)? = null

    init {
        when (p.returnType.classifier) {
            String::class -> {
                queryTask = { realmQuery, value ->
                    realmQuery.equalTo(p.name, value.toString())
                }
            }
            Integer::class -> {
                queryTask = { realmQuery, value ->
                    realmQuery.equalTo(p.name, value as Int)
                }
            }
            Long::class -> {
                queryTask = { realmQuery, value ->
                    realmQuery.equalTo(p.name, value as Long)
                }
            }
            Double::class -> {
                queryTask = { realmQuery, value ->
                    realmQuery.equalTo(p.name, value as Double)
                }
            }
        }
    }

    fun equalTo(query: RealmQuery<RE>, value: Any): RealmQuery<RE>? {
        try {
            return queryTask?.invoke(query, value)
        } catch (e: Exception) {
            DBManger.log("equalTo failed ${p.name} ${e.message}")
        }
        return null
    }


}