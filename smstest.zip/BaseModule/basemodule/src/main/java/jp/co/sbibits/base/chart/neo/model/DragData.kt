package jp.co.sbibits.base.chart.neo.model

import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.ui.model.ValueArray

 class DragData(var color: Int, var label: String, var data: ValueArray):Comparable<DragData> {

     var width = 0.0 //cloud width
     var height = 0.0 //cloud height
     var position = CGPoint(0.0,0.0)
     var r  = 0.0 //dot radius
     var cloudConnectPosition = CGPoint(0.0,0.0) //position of the right/left line of the cloud
     var value = 0.0 //the value of select data


     override fun compareTo(other: DragData): Int {
         return position.y.compareTo(other.position.y)
     }
}