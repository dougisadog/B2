package jp.co.sbibits.base.util

import android.annotation.SuppressLint
import android.content.Context
import java.util.*
import javax.security.auth.x500.X500Principal
import android.text.TextUtils
import android.security.KeyPairGeneratorSpec
import java.math.BigInteger
import java.security.*
import javax.crypto.Cipher

class KeyStoreUtils {
    private var keyStore: KeyStore = KeyStore.getInstance("AndroidKeyStore")
    private var x500Principal: X500Principal? = null
    private val CIPHER_TRANSFORMATION = "RSA/ECB/PKCS1Padding"
    private var mContext: Context? = null
    private val defaultAlias = "defaultAlias"

    private constructor()

    private constructor(context: Context) {
        mContext = context
        keyStore.load(null)
        /**
         * CN      commonName
         * O       organizationName
         * OU      organizationalUnitName
         * C       countryName
         */
        x500Principal = X500Principal("CN=sbibits, OU=sbibits, O=sbibits, C=JP");
    }

    companion object {
        @SuppressLint("StaticFieldLeak")
        private var INSTANCE: KeyStoreUtils? = null

        fun getInstance(context: Context): KeyStoreUtils {
            if (INSTANCE == null) {
                synchronized(KeyStoreUtils::class) {
                    if (INSTANCE == null) {
                        INSTANCE = KeyStoreUtils(
                            context
                        )
                    }
                }
            }
            return INSTANCE!!
        }
    }

    /**
     * すべてのエイリアスを取得する
     *
     * @return　すべてのエイリアス
     */
    fun getAliases(): Enumeration<String>? {
        try {
            return keyStore.aliases()
        } catch (e: KeyStoreException) {
            LogUtils.w(KeyStoreUtils::class.java.simpleName, e)
        }

        return null
    }

    /**
     * エイリアスの存在性チェック
     *
     * @param alias キーストアのエイリアス
     * @return チェック結果
     */
    fun containsAlias(alias: String): Boolean {
        if (TextUtils.isEmpty(alias)) {
            return false
        }

        var contains = false
        try {
            contains = keyStore.containsAlias(alias)
        } catch (e: Exception) {
            LogUtils.w(KeyStoreUtils::class.java.simpleName, e)
        }

        return contains
    }

    /**
     * 新しい鍵を生成する
     *
     * @param alias キーストアのエイリアス
     * @return 新しい鍵
     */
    private fun generateKey(alias: String): KeyPair? {
        if (containsAlias(alias)) {
            return null
        }

        try {
            val endDate = Calendar.getInstance()
            endDate.add(Calendar.YEAR, 10)

            val spec = KeyPairGeneratorSpec.Builder(mContext!!)
                .setAlias(alias)
                .setSubject(x500Principal!!)
                .setSerialNumber(BigInteger.ONE)
                .setStartDate(Calendar.getInstance().time)
                .setEndDate(endDate.time)
                .build()
            val generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore")
            generator.initialize(spec)

            return generator.generateKeyPair()
        } catch (e: Exception) {
            LogUtils.w(KeyStoreUtils::class.java.simpleName, e)
        }

        return null
    }

    /**
     * エイリアスを削除する
     *
     * @param alias キーストアのエイリアス
     */
    fun deleteKey(alias: String) {
        try {
            keyStore.deleteEntry(alias)
        } catch (e: Exception) {
            LogUtils.w(KeyStoreUtils::class.java.simpleName, e)
        }
    }

    /**
     * 暗号化する
     *
     * @param data 暗号化前データ
     * @param alias キーストアのエイリアス(省略可)
     * @return 暗号化後データ
     */
    fun encryptByRSA(data: ByteArray, alias: String = defaultAlias): ByteArray? {
        try {
            if (TextUtils.isEmpty(alias)) {
                return null
            }
            generateKey(alias)
            val publicKey = keyStore.getCertificate(alias).publicKey

            val cipher = Cipher.getInstance(CIPHER_TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, publicKey)
            return cipher.doFinal(data)
        } catch (e: Exception) {
            LogUtils.w(KeyStoreUtils::class.java.simpleName, e)
        }

        return null
    }

    /**
     * 複合化する
     *
     * @param data 復号化前のデータ
     * @param alias キーストアのエイリアス(省略可)
     * @return 複合化後のデータ
     */
    fun decryptByRSA(data: ByteArray, alias: String = defaultAlias): ByteArray? {
        try {
            if (TextUtils.isEmpty(alias)) {
                return null
            }
            generateKey(alias)
            val privateKey = keyStore.getKey(alias, null) as PrivateKey

            val cipher = Cipher.getInstance(CIPHER_TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, privateKey)
            return cipher.doFinal(data)
        } catch (e: Exception) {
            LogUtils.w(KeyStoreUtils::class.java.simpleName, e)
        }
        return null
    }

}