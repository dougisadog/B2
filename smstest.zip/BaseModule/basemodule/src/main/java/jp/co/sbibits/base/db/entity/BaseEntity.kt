package jp.co.sbibits.base.db.entity

import jp.co.sbibits.base.db.extension.getPrimary
import jp.co.sbibits.base.db.extension.getTableName

interface BaseEntity {

    /**
     * @return the table name
     */
    fun getTableName(): String {
        return this::class.getTableName()
    }

    /**
     * @return the primary id
     */
    fun getPrimaryId(): Any? {
        return this::class.getPrimary().getter.call(this)
    }

}