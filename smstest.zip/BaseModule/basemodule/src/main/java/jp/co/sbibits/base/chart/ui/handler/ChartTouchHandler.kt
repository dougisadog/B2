package jp.co.sbibits.base.chart.ui.handler

import android.view.MotionEvent
import jp.co.sbibits.base.CGFloat
import jp.co.sbibits.base.chart.ios.CGPoint
import jp.co.sbibits.base.chart.ios.UITouch
import jp.co.sbibits.base.extension.frame
import jp.co.sbibits.base.chart.ui.ChartCoordinateService
import jp.co.sbibits.base.chart.ui.ChartView

class ChartTouchHandler {
    enum class State {
        none,
        pinching,
        draggingTime,
        draggingPrice
    }

    var chartView: ChartView
    var coordinate: ChartCoordinateService
    var state: State = State.none
    var startPoints: List<CGPoint>? = null
    var pinchStartRecordInterval: CGFloat = 0.0
    var pinchStartScrollOffset: CGFloat = 0.0

    val isOperating: Boolean
        get() = state != State.none

    constructor(chartView: ChartView, coordinate: ChartCoordinateService) {
        this.chartView = chartView
        this.coordinate = coordinate
    }

    fun touchesBegan(touches: List<UITouch>, event: MotionEvent) {
        val touch = touches.firstOrNull() ?: return
        startPoints = coordinate.locationsInChart(touches = touches)
        val point = coordinate.locationInChart(touch = touch)

        state = State.none

        if (touches.size == 1) {
            var rightX = chartView.frame.size.width
            if (chartView.canSwipe()) {
                rightX -= chartView.config.swipeSideWidth
            }

            if (chartView.yScaleX < point.x && point.x < rightX && point.y <= chartView.mainGraphArea.height) {
                if (touch.tapCount <= 1) {
                    state = State.draggingPrice
                    chartView.selectedPrice = coordinate.price(yPosition = point.y)
                } else {
                    chartView.selectedPrice = null
                }
            } else if (chartView.timeLineTouchAreaTopY <= point.y) {
                if (touch.tapCount <= 1) {
                    state = State.draggingTime
                    chartView.selectedRecordIndex = coordinate.index(x = point.x)
                } else {
                    chartView.selectedRecordIndex = null
                }
            }
        }

        if (touches.size == 2) {
            state = State.pinching
            pinchStartRecordInterval = chartView.state.recordInterval
            pinchStartScrollOffset = chartView.scrollOffset
        }
    }

    fun touchesMoved(touches: List<UITouch>, event: MotionEvent) {
        val touch = touches.firstOrNull() ?: return
        val point = coordinate.locationInChart(touch = touch)
        if (state == State.draggingPrice) {
            chartView.selectedPrice = coordinate.price(yPosition = point.y)
        } else if (state == State.draggingTime) {
            chartView.selectedRecordIndex = coordinate.index(x = point.x)
        } else if (touches.size == 2) {
            state = State.pinching
            val points = coordinate.locationsInChart(touches = touches)
            val startPoints = startPoints
            if (startPoints != null && startPoints.size == 2) {
                val oldXs = startPoints.map { it.x }
                val newXs = points.map { it.x }
                val oldWidth = Math.max(1.0, Math.abs(oldXs[0] - oldXs[1]))
                val newWidth = Math.abs(newXs[0] - newXs[1])
                val newInterval = pinchStartRecordInterval * (newWidth / oldWidth)
                chartView.setRecordInterval(newInterval)
                val intervalRatio = chartView.state.recordInterval / pinchStartRecordInterval
                chartView.scrollOffset = (pinchStartScrollOffset * intervalRatio) /* スクロール位置を等比拡大 */ + (chartView.fullGraphArea.width * (intervalRatio - 1.0)) /* 右端位置の拡大分を調整 */
            } else {
                this.startPoints = points
                pinchStartRecordInterval = chartView.state.recordInterval
                pinchStartScrollOffset = chartView.scrollOffset
            }
        }
    }

    fun touchesEnded(touches: List<UITouch>, event: MotionEvent) {
        state = State.none
        startPoints = null
    }
}
